# models

This folder holds the opponent-skill estimator used by the uccchess bot.

`scripts/export_tournament_bot.py` copies the trained `estimator.pt` here and references it from `../tournament_config.json` as `models/estimator.pt`.

The repository ships without a trained estimator. Until one is exported, the bot plays StrangeFish2's default settings in every game.
