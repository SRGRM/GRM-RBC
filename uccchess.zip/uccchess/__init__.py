"""
uccchess: tournament package of the GRM agent for Reconnaissance Blind Chess.

    uccchess_bot.py           the agent (UCCChess) and its configuration loader
    tournament_config.json    hyperparameters and GRM table used in tournaments
    models/                   estimator checkpoint referenced by the configuration
    play_local_game.py        local game against a reconchess baseline bot
    connect_server.py         play on https://rbc.jhuapl.edu

Importing the agent requires the STOCKFISH_EXECUTABLE environment variable,
because StrangeFish2 checks it when it is imported.
"""

import os
import sys

# Allow "import uccchess" from the repository root and from inside this folder.
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from uccchess.uccchess_bot import UCCChess, load_tournament_config  # noqa: E402

__all__ = ["UCCChess", "load_tournament_config"]
