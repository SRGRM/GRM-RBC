"""
uccchess: the tournament agent built with a Generative Reward Machine.

This is the bot entered as "uccchess" in the NeurIPS 2022 Reconnaissance
Blind Chess tournament (Gardner et al., PMLR 220:119-132, 2023,
https://proceedings.mlr.press/v220/gardner23a.html), packaged for play.

What it does during a game
--------------------------
1. Board tracking, sensing and move choice come from StrangeFish2: the bot
   keeps every board consistent with its observations and scores sense and
   move options across that set with Stockfish and RBC heuristics.
2. Every turn it records the size of that board set. After a warm-up the
   opponent-skill estimator (a bank of autoencoders, one per opponent class)
   reads this record and names the opponent class it fits best.
3. The Generative Reward Machine maps the estimated class to the strategic
   personality that scored best against that class during training, and the
   bot switches its StrangeFish2 hyperparameters to that personality once the
   estimate has been confirmed.

Everything that defines the tournament behaviour lives in
``tournament_config.json`` next to this file: the estimator checkpoint, the
full hyperparameter vector of every personality, the class -> personality
table learned by the GRM, the switching rules and the engine settings.
``scripts/export_tournament_bot.py`` writes that file from a training run;
the bot itself contains no hard-coded strategy.

Usage
-----
    from uccchess import UCCChess
    bot = UCCChess()                                 # reads uccchess/tournament_config.json
    bot = UCCChess(config_path="my_config.json")     # or another configuration

The Stockfish binary is located through the STOCKFISH_EXECUTABLE environment
variable, as in StrangeFish2.
"""

import math
import os
from typing import Dict, List, Optional

from grm_rbc.common import load_json
from grm_rbc.grm import GRMPolicy, RuntimeGRMConfig
from grm_rbc.grm_bot import GRMStrangeFish
from grm_rbc.personalities import Personality

BOT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CONFIG_PATH = os.path.join(BOT_DIR, "tournament_config.json")
CONFIG_FORMAT_VERSION = 1


# ---------------------------------------------------------------------------
# Tournament configuration
# ---------------------------------------------------------------------------

def load_tournament_config(path: str = DEFAULT_CONFIG_PATH) -> Dict:
    """Read and check a tournament configuration file.

    Relative paths inside the file (the estimator checkpoint) are resolved
    against the folder that contains the configuration, so the bot folder can
    be copied anywhere as a unit.

    :param path: tournament_config.json to read
    :return: the configuration with an absolute ``estimator`` path (or None)
    :raises FileNotFoundError: if the file or the referenced estimator is missing
    :raises ValueError: if required sections are missing or inconsistent
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Tournament configuration not found: {path}")
    cfg = load_json(path)

    if cfg.get("format_version") != CONFIG_FORMAT_VERSION:
        raise ValueError(f"{path}: unsupported format_version {cfg.get('format_version')!r} "
                         f"(expected {CONFIG_FORMAT_VERSION})")
    for key in ("levels", "default_personality", "personalities", "class_policy", "runtime", "engine"):
        if key not in cfg:
            raise ValueError(f"{path}: missing section '{key}'")

    personalities = cfg["personalities"]
    if cfg["default_personality"] not in personalities:
        raise ValueError(f"{path}: default personality '{cfg['default_personality']}' is not defined")
    for level in cfg["levels"]:
        chosen = cfg["class_policy"].get(str(level))
        if chosen is None:
            raise ValueError(f"{path}: class_policy has no entry for level {level}")
        if chosen not in personalities:
            raise ValueError(f"{path}: level {level} uses undefined personality '{chosen}'")

    if cfg.get("estimator"):
        est = cfg["estimator"]
        est = est if os.path.isabs(est) else os.path.join(os.path.dirname(os.path.abspath(path)), est)
        if not os.path.isfile(est):
            raise FileNotFoundError(f"Estimator checkpoint referenced by {path} not found: {est}")
        cfg["estimator"] = est
    else:
        cfg["estimator"] = None
    return cfg


def personalities_from_config(cfg: Dict) -> List[Personality]:
    """Build the personality objects defined in the configuration.

    The default personality is placed first; the others follow in file order.
    Each entry carries explicit values for the sense, move and time settings
    and the score settings that differ from StrangeFish2's defaults.
    """
    out = []
    for name, spec in cfg["personalities"].items():
        p = Personality.from_dict({"name": name, **spec})
        out.append(p)
    out.sort(key=lambda p: p.name != cfg["default_personality"])
    return out


class TournamentPolicy(GRMPolicy):
    """GRM policy read from the tournament configuration.

    The class -> personality table in the configuration is authoritative:
    ``greedy_action`` returns exactly that table, so a hand-edited entry is
    played as written. The learned Q-values, when present, are kept so that
    the run-time switching rule (``switch_margin``) can compare personalities.
    """

    def __init__(self, cfg: Dict, actions: List[str]):
        """Fill the table from ``cfg['class_policy']`` and ``cfg['q_values']``.

        :param cfg: tournament configuration (see :func:`load_tournament_config`)
        :param actions: personality names, default first
        """
        super().__init__(cfg["levels"], actions, default_action=cfg["default_personality"])
        self.class_policy = {int(k): v for k, v in cfg["class_policy"].items()}
        q_values = cfg.get("q_values") or {}
        for s, level in enumerate(self.levels):
            for a, action in enumerate(self.actions):
                value = (q_values.get(str(level)) or {}).get(action)
                if value is not None and not (isinstance(value, float) and math.isnan(value)):
                    self.q[s, a] = float(value)
                    self.n[s, a] = 1

    def greedy_action(self, s: int) -> str:
        """Personality assigned to class ``s`` in the configuration."""
        return self.class_policy[self.levels[s]]


# ---------------------------------------------------------------------------
# The agent
# ---------------------------------------------------------------------------

class UCCChess(GRMStrangeFish):
    """
    The uccchess agent: StrangeFish2 whose hyperparameters are chosen by a GRM.

    The parent class :class:`grm_rbc.grm_bot.GRMStrangeFish` provides the
    mechanics (belief recording, estimator calls, the run-time state machine
    and safe hyperparameter switching). This class only turns the tournament
    configuration into those components, so that the tournament behaviour is
    fully described by ``tournament_config.json``.

    If the configuration has no estimator (for example before any training),
    the bot plays its default personality for the whole game, which with the
    shipped configuration is exactly StrangeFish2's tournament setting.
    """

    def __init__(
        self,
        config_path: str = DEFAULT_CONFIG_PATH,
        game_id=None,
        log_to_file: bool = True,
        quiet: bool = False,
        rc_disable_pbar: bool = True,
    ):
        """
        Construct an instance of the uccchess agent.

        :param config_path: tournament configuration (defaults to the file next to this module)
        :param game_id: any printable identifier for logging (typically the server's game number)
        :param log_to_file: write the per-game StrangeFish2 log to game_logs/game_<game_id>.log
        :param quiet: suppress the per-game console log
        :param rc_disable_pbar: hide StrangeFish2's tqdm progress bars
        """
        cfg = load_tournament_config(config_path)
        self.tournament_config = cfg
        self.config_path = os.path.abspath(config_path)

        space = personalities_from_config(cfg)
        names = [p.name for p in space]
        sf_options = dict(cfg.get("strangefish", {}))
        common = dict(
            action_space=space,
            runtime_config=RuntimeGRMConfig(**cfg["runtime"]),
            base_overrides=cfg.get("base_overrides") or {},
            engine_threads=int(cfg["engine"]["threads"]),
            engine_hash_mb=int(cfg["engine"]["hash_mb"]),
            game_id=game_id,
            log_to_file=log_to_file,
            quiet=quiet,
            rc_disable_pbar=rc_disable_pbar,
            load_score_cache=bool(sf_options.pop("load_score_cache", False)),
            load_opening_book=bool(sf_options.pop("load_opening_book", False)),
            **sf_options,
        )

        if cfg["estimator"] is None:
            # No trained estimator: play the default personality throughout.
            default = space[0]
            super().__init__(mode="fixed", fixed_personality=default, **common)
            self.logger.warning("No estimator in the tournament configuration; "
                                f"playing personality '{default.name}' for the whole game.")
        else:
            policy = TournamentPolicy(cfg, names)
            super().__init__(mode="grm", policy=policy, estimator=cfg["estimator"], **common)

    def describe(self) -> str:
        """Human-readable summary of the loaded tournament behaviour."""
        cfg = self.tournament_config
        lines = [
            f"uccchess ({'GRM' if self.mode == 'grm' else 'fixed default personality'})",
            f"  configuration : {self.config_path}",
            f"  estimator     : {cfg['estimator'] or 'none'}",
            f"  engine        : {cfg['engine']['threads']} threads, {cfg['engine']['hash_mb']} MB hash",
            f"  run-time rules: {cfg['runtime']}",
            "  class -> personality:",
        ]
        for level in cfg["levels"]:
            lines.append(f"    level {level:>2}: {cfg['class_policy'][str(level)]}")
        return "\n".join(lines)

    def personality_table(self) -> Optional[Dict[str, Dict]]:
        """The full hyperparameter vector of every personality, as loaded."""
        return {name: dict(spec) for name, spec in self.tournament_config["personalities"].items()}
