"""
Play a local game between uccchess and one of the reconchess baseline bots.

The equivalent of StrangeFish2's ``scripts/example_game.py``: it is the
quickest way to check that the tournament configuration, the estimator and
Stockfish all load and play together.

    export STOCKFISH_EXECUTABLE=/absolute/path/to/stockfish
    python uccchess/play_local_game.py                       # uccchess (white) vs TroutBot
    python uccchess/play_local_game.py --opponent random --color black
    python uccchess/play_local_game.py --seconds 300 --replay
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import click
import chess

OPPONENTS = ("trout", "random", "attacker")


def make_opponent(name: str):
    """Instantiate a reconchess baseline bot by short name."""
    if name == "trout":
        from reconchess.bots.trout_bot import TroutBot
        return TroutBot()
    if name == "random":
        from reconchess.bots.random_bot import RandomBot
        return RandomBot()
    if name == "attacker":
        from reconchess.bots.attacker_bot import AttackerBot
        return AttackerBot()
    raise click.BadParameter(f"unknown opponent '{name}'")


@click.command()
@click.option("--opponent", type=click.Choice(OPPONENTS), default="trout", help="Baseline bot to play against.")
@click.option("--color", type=click.Choice(["white", "black"]), default="white", help="Colour of uccchess.")
@click.option("--seconds", type=float, default=900, help="Clock per player in seconds (tournament: 900).")
@click.option("--config", "config_path", default=None, help="Tournament configuration (default: uccchess/tournament_config.json).")
@click.option("--history", "history_path", default="uccchess_local_game.json", help="Where to save the game history.")
@click.option("--replay", is_flag=True, help="Open the reconchess replay window after the game.")
def main(opponent, color, seconds, config_path, history_path, replay):
    """Play one game and report the result and every personality switch."""
    if "STOCKFISH_EXECUTABLE" not in os.environ:
        raise click.UsageError("Set STOCKFISH_EXECUTABLE to the path of the Stockfish binary.")

    from reconchess import LocalGame, play_local_game
    from uccchess import UCCChess
    from uccchess.uccchess_bot import DEFAULT_CONFIG_PATH

    bot = UCCChess(config_path=config_path or DEFAULT_CONFIG_PATH, game_id="LOCAL", log_to_file=True)
    print(bot.describe())

    other = make_opponent(opponent)
    white, black = (bot, other) if color == "white" else (other, bot)
    winner, reason, history = play_local_game(white, black, game=LocalGame(seconds_per_player=seconds))

    ours = chess.WHITE if color == "white" else chess.BLACK
    result = "draw" if winner is None else ("win" if winner == ours else "loss")
    print(f"\nResult for uccchess: {result} ({getattr(reason, 'name', reason)}) after {len(bot.trace)} turns")
    for entry in bot.personality_history:
        print(f"  turn {entry['turn']:>3}: personality '{entry['personality']}' ({entry['reason']})")
    if bot.estimates:
        last = bot.estimates[-1]
        print(f"  final estimate: opponent level {last['level']} (margin {last['margin']:.5f})")

    history.save(history_path)
    print(f"Game history saved to {history_path}")
    if replay:
        from reconchess import GameHistory
        from reconchess.scripts.rc_replay import ReplayWindow
        window = ReplayWindow(GameHistory.from_file(history_path))
        while True:  # the window exits the program when it is closed
            window.update()
            window.draw()


if __name__ == "__main__":
    main()
