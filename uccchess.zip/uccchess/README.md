# uccchess: the tournament bot

This folder is everything needed to play **uccchess**, the Reconnaissance Blind Chess bot that the Generative Reward Machine produces. uccchess was entered in the [NeurIPS 2022 RBC tournament](https://proceedings.mlr.press/v220/gardner23a.html).

```
uccchess/
├── uccchess_bot.py          the agent (class UCCChess) and the configuration loader
├── tournament_config.json   all tournament settings: hyperparameters, GRM table, run-time rules, engine
├── models/                  estimator checkpoint referenced by the configuration
├── play_local_game.py       one local game against a reconchess baseline bot
└── connect_server.py        play on https://rbc.jhuapl.edu
```

## How the bot plays

uccchess is StrangeFish2 with one difference: its strategic hyperparameters are not fixed but chosen by the GRM during the game.

1. **Tracking and scoring are StrangeFish2's.** The bot keeps every board consistent with what it has observed. It senses and moves by scoring options across that set with Stockfish and RBC-specific heuristics.
2. **It records its own uncertainty.** For every turn it stores the size of the board set: at the start of the turn, after sensing, and after moving.
3. **It estimates the opponent.** After `runtime.warmup_turns`, the estimator reads that record and names the opponent class it matches best. The estimator is a bank of autoencoders, one per opponent class, and the class is the one whose autoencoder reconstructs the record with the lowest error.
4. **It applies the GRM decision.** Once the same class has been estimated `confirm_turns` times in a row, the bot switches to the personality listed for that class in `class_policy`. A personality is one full set of StrangeFish2 hyperparameters.
5. **It stops switching under time pressure.** When fewer than 60 seconds remain, StrangeFish2 switches to its emergency plan and the personality is no longer changed.

## The tournament configuration

`tournament_config.json` fully defines the tournament behaviour; nothing strategic is hard-coded in the bot. Its sections are:

| Key | Meaning |
|---|---|
| `estimator` | Path of the estimator checkpoint, relative to this folder. `null` means the bot plays `default_personality` all game. |
| `levels` | Opponent classes. They must equal the estimator's classes. |
| `class_policy` | The table learned by the GRM: opponent class → personality name. |
| `q_values` | Learned value of every personality in every class. These are used by `switch_margin`. |
| `personalities` | The full hyperparameter vector of every personality used, in four sections:<br>• `sense`: StrangeFish2 `SenseConfig`<br>• `move`: `MoveConfig`<br>• `time`: `TimeConfig`<br>• `score`: only the `ScoreConfig` values that differ from StrangeFish2's defaults, because StrangeFish2 adjusts some score values for particular opponents at game start. |
| `runtime` | Switching rules: `warmup_turns`, `estimate_every`, `confirm_turns`, `switch_margin`, `allow_reswitch`, `min_estimator_margin`. |
| `engine` | Stockfish threads and hash for tournament games (StrangeFish2 values: 3 threads, 2048 MB). |
| `strangefish` | StrangeFish2 options: score cache, opening book, look-ahead during the opponent's turn, board weighting. |
| `base_overrides` | Settings applied under every personality. Empty means the tournament search depth. |

The configuration that ships with the repository is untrained. Every class uses `default`, which is exactly StrangeFish2's tournament setting, and there is no estimator.

After training, write the real configuration with:

```bash
python scripts/export_tournament_bot.py
```

Before running it, set `policy` (the GRM `policy.json`) and `estimator` (`estimator.pt`) in its CONFIG.

The export script:
- checks that the estimator and the policy use the same classes;
- copies the estimator into `models/`;
- writes every personality with explicit values.

You can review or hand-edit those values before a tournament. For example, you can change the personality of one class, or tighten `confirm_turns`. The bot validates the file when it loads it.

### Personality parameters

These are the hyperparameters that shape a personality's style most strongly. All of them appear explicitly in each personality entry.

| Section | Parameter | Effect |
|---|---|---|
| `move` | `max_score_factor` | Aggressiveness: weight of a move's best-case outcome |
| `move` | `min_score_factor` | Caution: weight of the worst-case outcome |
| `move` | `mean_score_factor` | Solidity: weight of the average outcome (the three factors sum to 1) |
| `move` | `threshold_score` | Unpredictability: any move within this many centipawns of the best may be played |
| `move` | `sampling_exploration_coef` | UCT bonus for evaluating rarely sampled moves |
| `sense` | `boards_per_centipawn` | Exchange rate between shrinking the board set and improving the next move |
| `sense` | `expected_outcome_coef`, `worst_outcome_coef` | Optimism and pessimism when choosing where to sense |
| `sense` | `outcome_variance_coef`, `score_variance_coef` | Risk aversion in sensing |
| `time` | `turns_to_plan_for`, `min_time_for_turn`, `max_time_for_turn` | Time management |
| `time` | `time_for_sense`, `time_for_move` | Split of a turn between sensing and moving |

## Running the bot

```bash
export STOCKFISH_EXECUTABLE=/absolute/path/to/stockfish

# local game against TroutBot (or --opponent random / attacker)
python uccchess/play_local_game.py
python uccchess/play_local_game.py --color black --seconds 300 --replay

# online
python uccchess/connect_server.py <username> <password>
python uccchess/connect_server.py <username> <password> --ranked --max-concurrent-games 2
```

Both scripts print the loaded configuration (classes, personalities, estimator and engine) before playing. The local game also prints every personality switch and the final estimate.

From Python:

```python
from uccchess import UCCChess

bot = UCCChess()                                  # uses uccchess/tournament_config.json
bot = UCCChess(config_path="my_config.json")      # or any other exported configuration
print(bot.describe())
```

`UCCChess` is a reconchess `Player`, so it works with `play_local_game`, `rc-connect` and the scripts in this folder.
