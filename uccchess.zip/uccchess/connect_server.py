"""
Connect uccchess to the public RBC server and play the games it is invited to.

Works like StrangeFish2's ``scripts/modified_rc_connect.py``: every accepted
invitation is played in its own process, and the bot keeps expanding its
board set while the opponent is thinking. All playing behaviour comes from
the tournament configuration.

    export STOCKFISH_EXECUTABLE=/absolute/path/to/stockfish
    python uccchess/connect_server.py <username> <password>
    python uccchess/connect_server.py <username> <password> --max-concurrent-games 2 --ranked
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import functools
import logging
from datetime import datetime

import click


def make_bot(game_id, config_path):
    """Create a uccchess instance for one server game (runs in the game's process)."""
    from uccchess import UCCChess
    return UCCChess(config_path=config_path, game_id=game_id, log_to_file=True, quiet=False)


@click.command()
@click.argument("username")
@click.argument("password")
@click.option("--server-url", default="https://rbc.jhuapl.edu", help="URL of the server.")
@click.option("--max-concurrent-games", type=int, default=1, help="Maximum games to play at once.")
@click.option("--limit-games", type=int, default=None, help="Stop after joining this many games.")
@click.option("--ranked", is_flag=True, help="Play for leaderboard Elo.")
@click.option("--config", "config_path", default=None, help="Tournament configuration (default: uccchess/tournament_config.json).")
def main(username, password, server_url, max_concurrent_games, limit_games, ranked, config_path):
    """Check the configuration once, then accept invitations until interrupted."""
    if "STOCKFISH_EXECUTABLE" not in os.environ:
        raise click.UsageError("Set STOCKFISH_EXECUTABLE to the path of the Stockfish binary.")

    from grm_rbc.remote import listen_for_invitations
    from uccchess.uccchess_bot import DEFAULT_CONFIG_PATH

    config_path = os.path.abspath(config_path or DEFAULT_CONFIG_PATH)
    # Build one bot now so that configuration problems appear before any game starts.
    print(make_bot("config-check", config_path).describe())

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        handlers=[logging.StreamHandler(sys.stdout),
                  logging.FileHandler(f"uccchess_connect_{datetime.now():%Y%m%d_%H%M%S}.log")],
    )
    listen_for_invitations(
        server_url,
        (username, password),
        functools.partial(make_bot, config_path=config_path),
        max_concurrent_games=max_concurrent_games,
        ranked=ranked,
        limit_games=limit_games,
    )


if __name__ == "__main__":
    main()
