"""
Generative Reward Machines for Reconnaissance Blind Chess.

The package adds an opponent-skill estimator and a Generative Reward Machine
(GRM) on top of the StrangeFish2 multiple-hypothesis-tracking bot. The GRM
chooses a strategic "personality" (a vector of StrangeFish2 hyperparameters)
for the opponent class that the estimator recognises during the game.

Modules
-------
common         small shared helpers (seeding, Stockfish setup, run folders, I/O)
personalities  the discrete action space: named or grid personalities
openings       predefined opening lines used by the Q-learning baseline
opponents      opponent bots, including Stockfish skill-level opponents
belief         belief-state-size traces and their tensor encoding
estimator      autoencoder bank used as the opponent-skill estimator
grm            Generative Reward Machine, batch reward machine and policies
grm_bot        the playing agent (StrangeFish2 subclass)
game_runner    parallel local game execution
remote         connection to the public RBC server
"""

__version__ = "1.0.0"
