"""
Opening lines for the Q-learning baseline (state = colour x opening).

In RBC a player only controls its own moves, so an "opening" is the sequence
of our own move requests for the first few turns. The opponent's replies are
unknown; a requested move that is not available (blocked, illegal, or the
piece has been captured) ends the line and normal play takes over.

Five lines are defined per colour. ``"other"`` means no forced line: the bot
plays its usual strategy from the first move.
"""

from typing import Dict, List

import chess

OTHER = "other"

WHITE_OPENINGS: Dict[str, List[str]] = {
    "queens_gambit": ["d2d4", "c2c4", "b1c3", "g1f3"],
    "italian": ["e2e4", "g1f3", "f1c4", "d2d3"],
    "ruy_lopez": ["e2e4", "g1f3", "f1b5", "e1g1"],
    "london": ["d2d4", "c1f4", "e2e3", "g1f3"],
    "english": ["c2c4", "b1c3", "g2g3", "f1g2"],
}

BLACK_OPENINGS: Dict[str, List[str]] = {
    "sicilian": ["c7c5", "d7d6", "g8f6", "b8c6"],
    "french": ["e7e6", "d7d5", "g8f6", "f8e7"],
    "caro_kann": ["c7c6", "d7d5", "c8f5", "e7e6"],
    "kings_indian": ["g8f6", "g7g6", "f8g7", "e8g8"],
    "scandinavian": ["d7d5", "g8f6", "c8f5", "e7e6"],
}


def openings_for(color: bool) -> Dict[str, List[str]]:
    """Opening table for a colour."""
    return WHITE_OPENINGS if color == chess.WHITE else BLACK_OPENINGS


def opening_names(color: bool, include_other: bool = True) -> List[str]:
    """Opening names for a colour, optionally followed by "other"."""
    names = list(openings_for(color).keys())
    if include_other:
        names.append(OTHER)
    return names


def opening_moves(color: bool, name: str) -> List[chess.Move]:
    """Move list of an opening (empty for "other")."""
    if name == OTHER:
        return []
    table = openings_for(color)
    if name not in table:
        raise ValueError(f"Unknown opening '{name}' for {chess.COLOR_NAMES[color]}")
    return [chess.Move.from_uci(m) for m in table[name]]
