"""
Q-learning baseline (Algorithm 2 of the thesis, entered as "srcork" at
NeurIPS 2022).

State   s = (colour, opening) with five openings per colour plus "other",
        i.e. 2 x 6 = 12 states, fixed before the game starts.
Action  a personality (vector of StrangeFish2 hyperparameters).
Reward  +1 win, 0 draw, -1 loss for a single game.
Update  Q(s, a) <- Q(s, a) + alpha * (R - Q(s, a))

The GRM differs in two ways: its state comes from the opponent estimator
rather than from our own opening, and its reward is a batch average rather
than the outcome of one noisy game.
"""

import random
from typing import Dict, List, Optional, Sequence, Tuple

import chess
import numpy as np

from grm_rbc.openings import opening_names


def state_key(color: bool, opening: str) -> str:
    """Name of the (colour, opening) state, e.g. "white:italian"."""
    return f"{'white' if color == chess.WHITE else 'black'}:{opening}"


class OpeningQLearner:
    """Tabular Q-learning over (colour, opening) states with personalities as actions."""

    def __init__(self, actions: Sequence[str], alpha: float = 0.1, initial_q: float = 0.0,
                 default_action: str = "default"):
        """Create a zero-initialised Q-table.

        :param actions: personality names forming the action space
        :param alpha: learning rate of the incremental update
        :param initial_q: starting value of every Q entry
        :param default_action: personality used when nothing has been learned yet
        """
        self.actions = list(actions)
        self.alpha = alpha
        self.initial_q = initial_q
        self.default_action = default_action if default_action in self.actions else self.actions[0]
        self.states: List[str] = [state_key(c, o) for c in (chess.WHITE, chess.BLACK) for o in opening_names(c)]
        self.q = np.full((len(self.states), len(self.actions)), initial_q, dtype=np.float64)
        self.n = np.zeros_like(self.q, dtype=np.int64)

    def s_index(self, color: bool, opening: str) -> int:
        """Row of the Q-table for ``color`` and ``opening``."""
        return self.states.index(state_key(color, opening))

    def choose_opening(self, color: bool, rule: str, rng: random.Random, episode: int) -> str:
        """Pick the opening to play in the next training game.

        uniform  any opening (including "other") with equal probability
        cycle    openings in turn; consecutive games share an opening because
                 colours alternate
        """
        names = opening_names(color)
        if rule == "uniform":
            return rng.choice(names)
        if rule == "cycle":
            return names[(episode // 2) % len(names)]
        raise ValueError(f"Unknown opening selection rule '{rule}'")

    def choose_action(self, s: int, rng: random.Random, epsilon: float) -> int:
        """Epsilon-greedy choice of a personality in state ``s`` (ties broken at random)."""
        if rng.random() < epsilon:
            return rng.randrange(len(self.actions))
        best = np.flatnonzero(np.isclose(self.q[s], self.q[s].max()))
        return int(rng.choice(list(best)))

    def update(self, s: int, a: int, reward: float) -> float:
        """Apply Q(s, a) <- Q(s, a) + alpha (R - Q(s, a)) and return the new value."""
        self.q[s, a] += self.alpha * (reward - self.q[s, a])
        self.n[s, a] += 1
        return float(self.q[s, a])

    def best_for_color(self, color: bool) -> Tuple[str, str]:
        """Pick the (opening, personality) pair with the highest learned value."""
        best: Optional[Tuple[float, str, str]] = None
        for opening in opening_names(color):
            s = self.s_index(color, opening)
            if self.n[s].sum() == 0:
                continue
            q = np.where(self.n[s] > 0, self.q[s], -np.inf)
            a = int(np.argmax(q))
            if best is None or q[a] > best[0]:
                best = (float(q[a]), opening, self.actions[a])
        if best is None:
            return "other", self.default_action
        return best[1], best[2]

    def to_dict(self) -> Dict:
        """Serialisable state, including the greedy (opening, personality) per colour."""
        return {
            "kind": "qlearning",
            "actions": self.actions,
            "alpha": self.alpha,
            "initial_q": self.initial_q,
            "default_action": self.default_action,
            "states": self.states,
            "q": self.q.tolist(),
            "n": self.n.tolist(),
            "greedy_policy": {
                "white": dict(zip(("opening", "personality"), self.best_for_color(chess.WHITE))),
                "black": dict(zip(("opening", "personality"), self.best_for_color(chess.BLACK))),
            },
        }

    @staticmethod
    def from_dict(d: Dict) -> "OpeningQLearner":
        """Rebuild a learner saved with :meth:`to_dict`.

        Raises ValueError if the saved states do not match the current opening
        definitions, which would silently mix up rows of the table.
        """
        q = OpeningQLearner(d["actions"], d["alpha"], d.get("initial_q", 0.0), d.get("default_action", "default"))
        if d["states"] != q.states:
            raise ValueError("Saved Q-learning states do not match the current opening definitions")
        q.q = np.asarray(d["q"], dtype=np.float64)
        q.n = np.asarray(d["n"], dtype=np.int64)
        return q

    def table_rows(self) -> List[Dict]:
        """Q-table as a list of rows for CSV reports."""
        rows = []
        for i, s in enumerate(self.states):
            for j, a in enumerate(self.actions):
                rows.append({"state": s, "personality": a, "visits": int(self.n[i, j]),
                             "q": float(self.q[i, j])})
        return rows
