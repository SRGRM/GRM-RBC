"""
Belief-state traces.

The opponent-skill estimator observes how the size of the bot's belief state
(the number of boards consistent with everything seen so far) evolves during
a game. The size is a direct measure of the bot's uncertainty, and its
trajectory depends on how the opponent plays: how often it captures, how
predictable its moves are, how quickly it develops pieces, and so on.

For every turn of our bot three sizes are recorded:

    start       boards after the opponent's move has been expanded and filtered
    after_sense boards after filtering by our sense result
    after_move  boards after filtering by our move result

``backlog`` is the expected number of extra boards that StrangeFish2 has put
aside when the set grew past its working limit; adding it gives a better
estimate of the true uncertainty for very large sets.
"""

import math
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple

import numpy as np

FEATURE_MODES = {
    # name: (record keys, description)
    "start": (("start",), "board count at the start of each turn"),
    "start_sense": (("start", "after_sense"), "start and post-sense counts"),
    "start_sense_move": (("start", "after_sense", "after_move"), "all three counts per turn"),
}


@dataclass
class TurnRecord:
    """Belief-set sizes measured during one turn of our bot."""

    turn: int
    start: Optional[float] = None
    after_sense: Optional[float] = None
    after_move: Optional[float] = None
    backlog: float = 0.0


@dataclass
class BeliefTrace:
    """Per-game belief-size history, filled in by the bot as the game runs."""

    color: Optional[bool] = None
    turns: List[TurnRecord] = field(default_factory=list)

    def start_turn(self, turn: int, n_boards: int, backlog: float) -> None:
        """Open a new turn with the board count after the opponent's move was processed."""
        self.turns.append(TurnRecord(turn=turn, start=float(n_boards), backlog=float(backlog)))

    def record_sense(self, n_boards: int) -> None:
        """Store the board count after filtering by our sense result."""
        if self.turns:
            self.turns[-1].after_sense = float(n_boards)

    def record_move(self, n_boards: int) -> None:
        """Store the board count after filtering by our move result."""
        if self.turns:
            self.turns[-1].after_move = float(n_boards)

    def __len__(self) -> int:
        """Number of turns recorded so far."""
        return len(self.turns)

    def to_list(self) -> List[Dict]:
        """Turns as plain dictionaries (the form stored in trace files)."""
        return [asdict(t) for t in self.turns]

    @staticmethod
    def from_list(color: Optional[bool], rows: List[Dict]) -> "BeliefTrace":
        """Rebuild a trace from the dictionaries produced by :meth:`to_list`."""
        return BeliefTrace(color=color, turns=[TurnRecord(**r) for r in rows])


@dataclass
class EncodingSpec:
    """How a trace is turned into a fixed-size array for the autoencoders.

    Stored inside the estimator checkpoint so that training and play use the
    exact same encoding.
    """

    feature_mode: str = "start_sense_move"
    max_turns: int = 40
    include_backlog: bool = True
    include_color: bool = True
    norm_boards: float = 100_000.0  # log1p(count) / log1p(norm_boards) maps counts to roughly [0, 1]

    @property
    def keys(self) -> Tuple[str, ...]:
        """Record fields used as features for the selected ``feature_mode``."""
        if self.feature_mode not in FEATURE_MODES:
            raise ValueError(f"Unknown feature_mode '{self.feature_mode}'. Options: {list(FEATURE_MODES)}")
        return FEATURE_MODES[self.feature_mode][0]

    @property
    def n_features(self) -> int:
        """Features per turn: one per board count, plus the optional colour channel."""
        return len(self.keys) + (1 if self.include_color else 0)

    def to_dict(self) -> Dict:
        """Plain dictionary for checkpoints and JSON files."""
        return asdict(self)

    @staticmethod
    def from_dict(d: Dict) -> "EncodingSpec":
        """Inverse of :meth:`to_dict`."""
        return EncodingSpec(**d)


def encode_trace(turns: List[Dict], color: Optional[bool], spec: EncodingSpec,
                 prefix: Optional[int] = None) -> Tuple[np.ndarray, np.ndarray, int]:
    """Encode one trace.

    Returns ``(x, mask, length)`` where ``x`` has shape (max_turns, n_features),
    ``mask`` has shape (max_turns,) with ones on valid turns, and ``length`` is
    the number of valid turns. ``prefix`` keeps only the first turns, which is
    what the bot sees part-way through a game.
    """
    rows = turns if prefix is None else turns[:prefix]
    rows = rows[: spec.max_turns]
    x = np.zeros((spec.max_turns, spec.n_features), dtype=np.float32)
    mask = np.zeros((spec.max_turns,), dtype=np.float32)
    scale = math.log1p(spec.norm_boards)
    last = {k: 1.0 for k in spec.keys}
    for i, row in enumerate(rows):
        extra = float(row.get("backlog") or 0.0) if spec.include_backlog else 0.0
        for j, key in enumerate(spec.keys):
            value = row.get(key)
            # A missing value (e.g. the game ended before our move) repeats the
            # last known count of that stage.
            value = last[key] if value is None else float(value) + extra
            last[key] = value
            x[i, j] = math.log1p(max(value, 0.0)) / scale
        if spec.include_color:
            x[i, -1] = 1.0 if color else 0.0
        mask[i] = 1.0
    return x, mask, len(rows)


def encode_many(records: List[Dict], spec: EncodingSpec) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Encode a list of game records (as written by ``generate_traces.py``)."""
    xs, masks, lengths = [], [], []
    for rec in records:
        x, m, n = encode_trace(rec["turns"], rec["color"], spec)
        xs.append(x)
        masks.append(m)
        lengths.append(n)
    return np.stack(xs), np.stack(masks), np.asarray(lengths, dtype=np.int64)
