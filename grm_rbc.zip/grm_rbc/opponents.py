"""
Opponent bots used for training and evaluation.

The GRM state space is the opponent's skill class. Opponents of a known class
are produced with :class:`SkillTroutBot`, a TroutBot whose Stockfish engine is
weakened with the UCI option ``Skill Level`` (0 = weakest, 20 = strongest).
All skill levels share the same class name, so the bot under training cannot
read the level from the opponent name that reconchess passes at game start.

Opponents are described by small dictionaries so that they can be sent to
worker processes and written to reports:

    {"type": "skill_trout", "level": 12}
    {"type": "trout"}
    {"type": "random"}
    {"type": "attacker"}
    {"type": "strangefish2"}                       # StrangeFish2 defaults
    {"type": "strangefish2", "personality": "cautious"}
"""

import os
from typing import Dict, Optional

import chess
import chess.engine

from grm_rbc.common import STOCKFISH_ENV_VAR

SKILL_LEVEL_MIN = 0
SKILL_LEVEL_MAX = 20


def opponent_label(spec: Dict) -> str:
    """Short name of an opponent for logs and reports, e.g. "skill07"."""
    kind = spec["type"]
    if kind == "skill_trout":
        return f"skill{int(spec['level']):02d}"
    if kind == "strangefish2" and spec.get("personality"):
        return f"strangefish2[{spec['personality']}]"
    return kind


def _trout_base():
    # Imported lazily so the module can be imported before Stockfish is configured.
    """Return reconchess's TroutBot class."""
    from reconchess.bots.trout_bot import TroutBot
    return TroutBot


def make_skill_trout(level: int, move_time: float = 0.1, threads: int = 1, hash_mb: int = 16):
    """Create a TroutBot whose Stockfish engine plays at ``level``.

    :param level: Stockfish "Skill Level" in [0, 20]
    :param move_time: engine search time per move in seconds
    :param threads: engine threads
    :param hash_mb: engine hash size in MB
    """
    TroutBot = _trout_base()

    class SkillTroutBot(TroutBot):
        """TroutBot with a Stockfish engine limited to a fixed skill level."""

        def __init__(self):
            """Start the engine through TroutBot and apply the skill limit."""
            if not SKILL_LEVEL_MIN <= level <= SKILL_LEVEL_MAX:
                raise ValueError(f"Skill level must be in [{SKILL_LEVEL_MIN}, {SKILL_LEVEL_MAX}], got {level}")
            super().__init__()
            self.skill_level = level
            self.move_time = move_time
            self.engine.configure({"Skill Level": level, "Threads": threads, "Hash": hash_mb})

        def choose_move(self, move_actions, seconds_left):
            # Same logic as TroutBot.choose_move, with a configurable engine time limit.
            """Capture the king if possible, otherwise play Stockfish's move for the tracked board."""
            enemy_king_square = self.board.king(not self.color)
            if enemy_king_square:
                attackers = self.board.attackers(self.color, enemy_king_square)
                if attackers:
                    return chess.Move(attackers.pop(), enemy_king_square)
            try:
                self.board.turn = self.color
                self.board.clear_stack()
                result = self.engine.play(self.board, chess.engine.Limit(time=self.move_time))
                return result.move
            except (chess.engine.EngineTerminatedError, chess.engine.EngineError):
                return None

    # Keep a single, level-independent class name for every instance.
    SkillTroutBot.__name__ = "SkillTroutBot"
    SkillTroutBot.__qualname__ = "SkillTroutBot"
    return SkillTroutBot()


def make_opponent(spec: Dict, defaults: Optional[Dict] = None):
    """Instantiate an opponent from its specification dictionary.

    ``defaults`` holds engine settings shared by all opponents of a run
    (``move_time``, ``threads``, ``hash_mb``) and, for StrangeFish2-based
    opponents, the keyword arguments forwarded to :class:`GRMStrangeFish`.
    """
    if STOCKFISH_ENV_VAR not in os.environ:
        raise RuntimeError(f"{STOCKFISH_ENV_VAR} must be set before creating opponents")
    defaults = defaults or {}
    kind = spec["type"]

    if kind == "skill_trout":
        return make_skill_trout(
            level=int(spec["level"]),
            move_time=float(spec.get("move_time", defaults.get("move_time", 0.1))),
            threads=int(defaults.get("threads", 1)),
            hash_mb=int(defaults.get("hash_mb", 16)),
        )
    if kind == "trout":
        from reconchess.bots.trout_bot import TroutBot
        return TroutBot()
    if kind == "random":
        from reconchess.bots.random_bot import RandomBot
        return RandomBot()
    if kind == "attacker":
        from reconchess.bots.attacker_bot import AttackerBot
        return AttackerBot()
    if kind == "strangefish2":
        from grm_rbc.grm_bot import GRMStrangeFish
        from grm_rbc.personalities import build_action_space, personality_index
        kwargs = dict(defaults.get("strangefish_kwargs", {}))
        name = spec.get("personality")
        if name:
            space = personality_index(build_action_space("named") + build_action_space("grid"))
            if name not in space:
                raise ValueError(f"Unknown personality '{name}' for StrangeFish2 opponent")
            kwargs["fixed_personality"] = space[name]
        kwargs["mode"] = "fixed"
        return GRMStrangeFish(**kwargs)
    raise ValueError(f"Unknown opponent type '{kind}'")
