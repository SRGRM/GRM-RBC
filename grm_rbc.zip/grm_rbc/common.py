"""
Shared helpers used by the package and the scripts.

Nothing in this module imports torch or StrangeFish2, so it is safe to import
before the Stockfish environment variable has been set.
"""

import csv
import json
import os
import random
import sys
import time
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional

import numpy as np

STOCKFISH_ENV_VAR = "STOCKFISH_EXECUTABLE"


# ---------------------------------------------------------------------------
# Console output
# ---------------------------------------------------------------------------

def log(message: str) -> None:
    """Print a time-stamped progress line and flush immediately."""
    stamp = datetime.now().strftime("%H:%M:%S")
    print(f"[{stamp}] {message}", flush=True)


def fail(message: str, exit_code: int = 1) -> None:
    """Print an error and stop the program.

    Used whenever required input data cannot be loaded: the training scripts
    must never continue with missing or partial data.
    """
    print(f"\nERROR: {message}\n", file=sys.stderr, flush=True)
    sys.exit(exit_code)


class Tee:
    """Duplicate everything written to stdout into a log file."""

    def __init__(self, path: str):
        """Open (append mode) the log file that will receive a copy of stdout."""
        self.file = open(path, "a", encoding="utf-8")
        self.stdout = sys.stdout

    def write(self, data: str) -> None:
        """Write to the console and to the log file."""
        self.stdout.write(data)
        self.file.write(data)

    def flush(self) -> None:
        """Flush both outputs so progress lines appear immediately."""
        self.stdout.flush()
        self.file.flush()

    def isatty(self) -> bool:
        """Report a non-terminal stream so libraries do not emit control codes."""
        return False


# ---------------------------------------------------------------------------
# Reproducibility and environment
# ---------------------------------------------------------------------------

def set_seed(seed: int) -> None:
    """Seed Python, NumPy and (when installed) PyTorch random generators."""
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass


def configure_stockfish(path: Optional[str]) -> str:
    """Point StrangeFish2 and the reconchess bots at a Stockfish binary.

    Must be called before any module from ``strangefish`` is imported, because
    ``strangefish.utilities.stockfish`` validates the variable at import time.
    """
    if path:
        os.environ[STOCKFISH_ENV_VAR] = os.path.abspath(os.path.expanduser(path))
    resolved = os.environ.get(STOCKFISH_ENV_VAR)
    if not resolved:
        fail(f"Stockfish path is not set. Fill CONFIG['stockfish_path'] or export {STOCKFISH_ENV_VAR}.")
    if not os.path.isfile(resolved):
        fail(f"Stockfish executable not found at '{resolved}'.")
    if not os.access(resolved, os.X_OK):
        fail(f"Stockfish binary at '{resolved}' is not executable (chmod +x).")
    return resolved


def add_repo_to_path() -> str:
    """Make the repository root importable when a script is run directly."""
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if root not in sys.path:
        sys.path.insert(0, root)
    return root


# ---------------------------------------------------------------------------
# Run folders and files
# ---------------------------------------------------------------------------

def make_run_dir(base_dir: str, run_name: str) -> str:
    """Create ``base_dir/run_name_YYYYmmdd_HHMMSS`` and return its path."""
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(base_dir, f"{run_name}_{stamp}")
    os.makedirs(path, exist_ok=False)
    return path


def save_json(obj: Any, path: str) -> None:
    """Write ``obj`` as indented JSON through a temporary file.

    The rename at the end makes the write atomic, so a run stopped mid-save
    never leaves a half-written policy or report behind.
    """
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, default=_json_default)
    os.replace(tmp, path)


def load_json(path: str) -> Any:
    """Read a JSON file."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _json_default(obj: Any) -> Any:
    """Convert NumPy scalars, arrays and sets to JSON-compatible values."""
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, set):
        return sorted(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serialisable")


def append_jsonl(rows: Iterable[Dict], path: str) -> None:
    """Append each row as one JSON line (used for per-game records)."""
    with open(path, "a", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, default=_json_default) + "\n")


def read_jsonl(path: str) -> List[Dict]:
    """Read a JSON-lines file, skipping blank lines.

    Raises ValueError naming the file and line if a line is not valid JSON.
    """
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}: line {line_no} is not valid JSON ({exc})") from exc
    return rows


def append_csv_row(row: Dict, path: str) -> None:
    """Append one row to a CSV report, writing the header on first use."""
    new_file = not os.path.exists(path)
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if new_file:
            writer.writeheader()
        writer.writerow(row)


def write_csv(rows: List[Dict], path: str) -> None:
    """Write rows to a CSV file; the header is the union of all row keys."""
    if not rows:
        with open(path, "w", encoding="utf-8") as f:
            f.write("")
        return
    fields = list(rows[0].keys())
    for row in rows[1:]:
        for key in row:
            if key not in fields:
                fields.append(key)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


class Stopwatch:
    """Wall-clock timer used in progress messages."""

    def __init__(self):
        """Start timing now."""
        self.start = time.time()

    def elapsed(self) -> float:
        """Seconds since creation."""
        return time.time() - self.start

    def fmt(self) -> str:
        """Elapsed time as HH:MM:SS."""
        sec = int(self.elapsed())
        return f"{sec // 3600:02d}:{(sec % 3600) // 60:02d}:{sec % 60:02d}"
