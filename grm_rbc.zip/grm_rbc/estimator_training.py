"""
Data loading, training and evaluation routines for the autoencoder bank.

The two training scripts (CUDA 11.4 and CUDA 12.2) share this module and
differ only in how mixed precision and compilation are set up, which they
pass in as small factory functions.
"""

import os
import random
from collections import Counter, defaultdict
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler

from grm_rbc.belief import EncodingSpec, encode_many, encode_trace
from grm_rbc.common import fail, log, read_jsonl
from grm_rbc.estimator import bank_loss, decide, reconstruction_errors


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

def load_trace_records(files: Sequence[str], min_turns: int, drop_errors: bool = True) -> List[Dict]:
    """Read trace files written by ``generate_traces.py``.

    Stops the program if a file is missing, unreadable or empty, or if no
    usable game remains after filtering.
    """
    if not files:
        fail("CONFIG['trace_files'] is empty.")
    records: List[Dict] = []
    for path in files:
        if not os.path.isfile(path):
            fail(f"Trace file not found: {path}")
        log(f"Loading traces from {path}")
        try:
            rows = read_jsonl(path)
        except Exception as exc:
            fail(f"Could not read {path}: {exc}")
        if not rows:
            fail(f"Trace file is empty: {path}")
        log(f"  {len(rows)} game records read")
        records.extend(rows)

    kept, dropped = [], Counter()
    for r in records:
        if "level" not in r or "turns" not in r or "color" not in r:
            dropped["missing fields"] += 1
            continue
        if drop_errors and r.get("error"):
            dropped["game error"] += 1
            continue
        if len(r["turns"]) < min_turns:
            dropped[f"fewer than {min_turns} turns"] += 1
            continue
        kept.append(r)
    for reason, n in dropped.items():
        log(f"  dropped {n} records: {reason}")
    if not kept:
        fail("No usable game records after filtering.")
    log(f"Total usable games: {len(kept)}")
    return kept


def resolve_levels(records: List[Dict], levels_cfg) -> List[int]:
    """Return the class list: every level in the data ("auto") or the configured list.

    Stops the program if a configured level has no games at all.
    """
    present = sorted({int(r["level"]) for r in records})
    if levels_cfg == "auto":
        return present
    levels = [int(v) for v in levels_cfg]
    missing = [lv for lv in levels if lv not in present]
    if missing:
        fail(f"No training data for levels {missing}. Generate traces for them or remove them from CONFIG['levels'].")
    return levels


def split_records(records: List[Dict], levels: List[int], val_fraction: float, mode: str,
                  seed: int) -> Tuple[List[Dict], List[Dict]]:
    """Split by game. ``stratified`` keeps the class proportions in both parts."""
    rng = random.Random(seed)
    usable = [r for r in records if int(r["level"]) in levels]
    if mode == "random":
        rng.shuffle(usable)
        n_val = int(round(len(usable) * val_fraction))
        return usable[n_val:], usable[:n_val]
    if mode == "stratified":
        by_level = defaultdict(list)
        for r in usable:
            by_level[int(r["level"])].append(r)
        train, val = [], []
        for lv in levels:
            group = by_level[lv]
            rng.shuffle(group)
            n_val = int(round(len(group) * val_fraction))
            if val_fraction > 0 and len(group) > 1:
                n_val = max(1, n_val)
            val.extend(group[:n_val])
            train.extend(group[n_val:])
        return train, val
    raise ValueError(f"Unknown split mode '{mode}'")


def to_tensors(records: List[Dict], levels: List[int], spec: EncodingSpec):
    """Encode records into (x, mask, lengths, labels) tensors."""
    x, mask, lengths = encode_many(records, spec)
    level_to_idx = {lv: i for i, lv in enumerate(levels)}
    y = np.asarray([level_to_idx[int(r["level"])] for r in records], dtype=np.int64)
    return (torch.from_numpy(x), torch.from_numpy(mask), torch.from_numpy(lengths), torch.from_numpy(y))


def check_class_coverage(y: torch.Tensor, levels: List[int], name: str) -> None:
    """Stop the program if a class has no games in this split; print class counts."""
    counts = Counter(y.tolist())
    empty = [levels[i] for i in range(len(levels)) if counts.get(i, 0) == 0]
    if empty:
        fail(f"The {name} split has no games for levels {empty}; every autoencoder needs its own data.")
    log(f"  {name}: " + ", ".join(f"L{levels[i]}={counts[i]}" for i in range(len(levels))))


# ---------------------------------------------------------------------------
# Batching
# ---------------------------------------------------------------------------

def make_loader(tensors, batch_size: int, sampler: str, loader: str, num_workers: int, pin_memory: bool,
                seed: int):
    """Return an iterable of (x, mask, lengths, y) batches for one epoch.

    loader   "torch_dataloader"  standard DataLoader (supports workers and pinning)
             "tensor"            in-memory index shuffling; fastest for small sets
    sampler  "shuffle"           plain shuffling
             "balanced"          classes drawn with equal probability
    """
    x, mask, lengths, y = tensors
    n = len(y)
    if loader == "torch_dataloader":
        ds = TensorDataset(x, mask, lengths, y)
        g = torch.Generator()
        g.manual_seed(seed)
        if sampler == "balanced":
            counts = torch.bincount(y).float()
            weights = (1.0 / counts)[y]
            smp = WeightedRandomSampler(weights.double(), num_samples=n, replacement=True, generator=g)
            return DataLoader(ds, batch_size=batch_size, sampler=smp, num_workers=num_workers,
                              pin_memory=pin_memory, drop_last=False)
        if sampler == "shuffle":
            return DataLoader(ds, batch_size=batch_size, shuffle=True, generator=g, num_workers=num_workers,
                              pin_memory=pin_memory, drop_last=False)
        raise ValueError(f"Unknown sampler '{sampler}'")
    if loader == "tensor":
        rng = np.random.RandomState(seed)
        if sampler == "balanced":
            counts = np.bincount(y.numpy())
            p = (1.0 / counts)[y.numpy()]
            idx = rng.choice(n, size=n, replace=True, p=p / p.sum())
        elif sampler == "shuffle":
            idx = rng.permutation(n)
        else:
            raise ValueError(f"Unknown sampler '{sampler}'")
        idx = torch.from_numpy(idx)
        return [(x[b], mask[b], lengths[b], y[b]) for b in torch.split(idx, batch_size)]
    raise ValueError(f"Unknown loader '{loader}'")


def random_prefix(mask: torch.Tensor, lengths: torch.Tensor, min_prefix: int, gen: torch.Generator):
    """Truncate each sequence to a random prefix of at least ``min_prefix`` turns.

    The bot classifies partial games, so the autoencoders are trained on
    partial traces as well as complete ones.
    """
    lo = torch.clamp(lengths, max=min_prefix).float()
    hi = lengths.float()
    u = torch.rand(lengths.shape, generator=gen).to(lengths.device)
    new_len = torch.floor(lo + u * (hi - lo + 1)).long().clamp(min=1)
    new_len = torch.minimum(new_len, lengths.clamp(min=1))
    t = torch.arange(mask.shape[1], device=mask.device).unsqueeze(0)
    new_mask = (t < new_len.unsqueeze(1)).float() * mask
    return new_mask, new_len


# ---------------------------------------------------------------------------
# Training and evaluation
# ---------------------------------------------------------------------------

def train_one_epoch(model, batches, optimizer, device, autocast_fn: Callable, scaler, cfg: Dict,
                    gen: torch.Generator, epoch: int, n_batches: int) -> float:
    """Train the bank for one epoch and return the mean training loss.

    ``autocast_fn`` and ``scaler`` come from the calling script and encode
    the mixed-precision API of its PyTorch version (``scaler`` is None when
    no loss scaling is used).
    """
    model.train()
    total, count = 0.0, 0
    print_every = max(1, n_batches // max(1, cfg["print_batches_per_epoch"]))
    for step, (x, mask, lengths, y) in enumerate(batches, start=1):
        x = x.to(device, non_blocking=True)
        mask = mask.to(device, non_blocking=True)
        lengths = lengths.to(device, non_blocking=True)
        y = y.to(device, non_blocking=True)
        if cfg["prefix_augmentation"]:
            mask, lengths = random_prefix(mask, lengths, cfg["min_prefix"], gen)
            x = x * mask.unsqueeze(-1)
        optimizer.zero_grad(set_to_none=True)
        with autocast_fn():
            recon = model(x, mask, lengths)
        # The loss is computed in float32 for stability under mixed precision.
        errors = reconstruction_errors(recon.float(), x, mask)
        loss = bank_loss(errors, y, cfg["loss_type"], cfg["margin"], cfg["margin_weight"])
        if scaler is not None:
            scaler.scale(loss).backward()
            if cfg["grad_clip"] > 0:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["grad_clip"])
            scaler.step(optimizer)
            scaler.update()
        else:
            loss.backward()
            if cfg["grad_clip"] > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["grad_clip"])
            optimizer.step()
        total += float(loss.item()) * len(y)
        count += len(y)
        if step % print_every == 0 or step == n_batches:
            log(f"    epoch {epoch}  batch {step}/{n_batches}  loss {total / max(count, 1):.6f}")
    return total / max(count, 1)


@torch.no_grad()
def compute_errors(model, records: List[Dict], spec: EncodingSpec, device, batch_size: int,
                   prefix: Optional[int] = None) -> np.ndarray:
    """Error matrix (N, K) for every record, optionally on a prefix of each game."""
    model.eval()
    out = []
    for start in range(0, len(records), batch_size):
        chunk = records[start:start + batch_size]
        enc = [encode_trace(r["turns"], r["color"], spec, prefix=prefix) for r in chunk]
        x = torch.from_numpy(np.stack([e[0] for e in enc])).to(device)
        m = torch.from_numpy(np.stack([e[1] for e in enc])).to(device)
        ln = torch.tensor([max(e[2], 1) for e in enc], dtype=torch.long, device=device)
        out.append(reconstruction_errors(model(x, m, ln).float(), x, m).cpu().numpy())
    return np.concatenate(out, axis=0) if out else np.zeros((0, 0))


def calibration_stats(model, records: List[Dict], levels: List[int], spec: EncodingSpec, device,
                      batch_size: int) -> Dict:
    """Mean and std of each class model's error on its own training games."""
    err = compute_errors(model, records, spec, device, batch_size)
    idx = {lv: i for i, lv in enumerate(levels)}
    y = np.asarray([idx[int(r["level"])] for r in records])
    mean, std = [], []
    for k in range(len(levels)):
        own = err[y == k, k]
        mean.append(float(own.mean()) if len(own) else 0.0)
        std.append(float(own.std()) if len(own) > 1 else 1.0)
    return {"mean": mean, "std": std}


def evaluate(model, records: List[Dict], levels: List[int], spec: EncodingSpec, device, batch_size: int,
             prefixes: Sequence[Optional[int]], decision_rule: str, calibration: Optional[Dict], cfg: Dict):
    """Classification metrics on full games and on game prefixes.

    Returns (metrics, prediction rows, confusion matrix on full games).
    """
    idx = {lv: i for i, lv in enumerate(levels)}
    y = np.asarray([idx[int(r["level"])] for r in records])
    metrics: Dict = {}
    rows: List[Dict] = []
    confusion = np.zeros((len(levels), len(levels)), dtype=np.int64)
    for prefix in prefixes:
        err = compute_errors(model, records, spec, device, batch_size, prefix=prefix)
        pred = decide(err, decision_rule, calibration)
        tag = "full" if prefix is None else f"p{prefix}"
        acc = float((pred == y).mean()) if len(y) else 0.0
        within1 = float((np.abs(np.asarray(levels)[pred] - np.asarray(levels)[y]) <= 1).mean()) if len(y) else 0.0
        metrics[f"acc_{tag}"] = acc
        metrics[f"acc_within1_{tag}"] = within1
        if prefix is None:
            own = err[np.arange(len(y)), y]
            loss = float(own.mean()) if len(own) else 0.0
            if cfg["loss_type"] == "own_plus_margin" and len(y):
                hinge = np.maximum(cfg["margin"] - (err - own[:, None]), 0.0)
                hinge[np.arange(len(y)), y] = 0.0
                loss += cfg["margin_weight"] * float(hinge.sum(axis=1).mean()) / max(len(levels) - 1, 1)
            metrics["loss"] = loss
            for i, r in enumerate(records):
                confusion[y[i], pred[i]] += 1
                sorted_err = np.sort(err[i])
                rows.append({
                    "game_id": r.get("game_id"),
                    "true_level": levels[y[i]],
                    "pred_level": levels[pred[i]],
                    "correct": bool(pred[i] == y[i]),
                    "n_turns": len(r["turns"]),
                    "own_error": float(err[i, y[i]]),
                    "best_error": float(sorted_err[0]),
                    "margin": float(sorted_err[1] - sorted_err[0]) if len(sorted_err) > 1 else 0.0,
                })
    return metrics, rows, confusion
