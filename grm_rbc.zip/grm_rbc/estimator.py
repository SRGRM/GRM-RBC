"""
Opponent-skill estimator: a bank of autoencoders, one per skill class.

Each autoencoder is trained only on belief-size traces from games against one
opponent class. During a game the bot feeds its trace so far to every
autoencoder; the class whose autoencoder reconstructs the trace best (lowest
reconstruction error) is the estimated opponent class. That estimate is the
state of the Generative Reward Machine.

Written against the PyTorch API available since 1.8 so the same module runs
on both the CUDA 11.4 and the CUDA 12.2 machines.
"""

import json
import math
from typing import Dict, List, Optional, Sequence

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.rnn import pack_padded_sequence

from grm_rbc.belief import EncodingSpec, encode_trace

ARCHITECTURES = ("mlp", "gru", "conv1d")


# ---------------------------------------------------------------------------
# Single-class autoencoders. All take x: (B, T, F), mask: (B, T), lengths: (B,)
# and return a reconstruction of shape (B, T, F).
# ---------------------------------------------------------------------------

class MLPAutoencoder(nn.Module):
    """Fully connected autoencoder over the whole (masked) trace.

    The mask is given to the encoder as an extra channel so that a short
    prefix and a long game with small counts are not confused.
    """

    def __init__(self, max_turns: int, n_features: int, hidden_dims: Sequence[int] = (256, 128),
                 latent_dim: int = 16, dropout: float = 0.0):
        """Build encoder and decoder.

        :param max_turns: sequence length T
        :param n_features: features per turn F
        :param hidden_dims: widths of the hidden layers (mirrored in the decoder)
        :param latent_dim: size of the bottleneck
        :param dropout: dropout after each encoder layer (0 disables)
        """
        super().__init__()
        self.max_turns = max_turns
        self.n_features = n_features
        in_dim = max_turns * (n_features + 1)  # features plus the mask channel
        enc, prev = [], in_dim
        for h in hidden_dims:
            enc += [nn.Linear(prev, h), nn.ReLU(inplace=True)]
            if dropout > 0:
                enc.append(nn.Dropout(dropout))
            prev = h
        enc.append(nn.Linear(prev, latent_dim))
        self.encoder = nn.Sequential(*enc)
        dec, prev = [], latent_dim
        for h in reversed(hidden_dims):
            dec += [nn.Linear(prev, h), nn.ReLU(inplace=True)]
            prev = h
        dec.append(nn.Linear(prev, max_turns * n_features))
        self.decoder = nn.Sequential(*dec)

    def forward(self, x, mask, lengths):
        """Reconstruct ``x``; ``lengths`` is unused by this architecture."""
        b = x.shape[0]
        inp = torch.cat([x * mask.unsqueeze(-1), mask.unsqueeze(-1)], dim=-1).reshape(b, -1)
        z = self.encoder(inp)
        return self.decoder(z).reshape(b, self.max_turns, self.n_features)


class GRUAutoencoder(nn.Module):
    """Sequence-to-sequence GRU autoencoder.

    The encoder reads only the valid turns (packed sequences); the decoder
    rebuilds the full sequence from the latent code and the turn position.
    """

    def __init__(self, max_turns: int, n_features: int, hidden_size: int = 64, latent_dim: int = 16,
                 num_layers: int = 1, dropout: float = 0.0):
        """Build the recurrent encoder and decoder.

        :param max_turns: sequence length T
        :param n_features: features per turn F
        :param hidden_size: GRU hidden units
        :param latent_dim: size of the bottleneck
        :param num_layers: stacked GRU layers
        :param dropout: dropout between stacked layers (only used when num_layers > 1)
        """
        super().__init__()
        self.max_turns = max_turns
        self.encoder = nn.GRU(n_features, hidden_size, num_layers=num_layers, batch_first=True,
                              dropout=dropout if num_layers > 1 else 0.0)
        self.to_latent = nn.Linear(hidden_size, latent_dim)
        # The decoder sees the latent code plus the normalised turn index at every step.
        self.decoder = nn.GRU(latent_dim + 1, hidden_size, num_layers=num_layers, batch_first=True,
                              dropout=dropout if num_layers > 1 else 0.0)
        self.out = nn.Linear(hidden_size, n_features)
        self.register_buffer("positions", torch.linspace(0.0, 1.0, max_turns).view(1, max_turns, 1))

    def forward(self, x, mask, lengths):
        """Encode the valid part of each sequence and decode all T steps."""
        b, t, _ = x.shape
        # DataParallel replicas need the RNN weights re-flattened into one block.
        self.encoder.flatten_parameters()
        self.decoder.flatten_parameters()
        lengths_cpu = lengths.clamp(min=1).detach().cpu()
        packed = pack_padded_sequence(x, lengths_cpu, batch_first=True, enforce_sorted=False)
        _, h = self.encoder(packed)
        z = self.to_latent(h[-1])
        dec_in = torch.cat([z.unsqueeze(1).expand(b, t, z.shape[-1]), self.positions.expand(b, t, 1)], dim=-1)
        out, _ = self.decoder(dec_in)
        return self.out(out)


class Conv1dAutoencoder(nn.Module):
    """Temporal convolutional autoencoder (local patterns along the game)."""

    def __init__(self, max_turns: int, n_features: int, channels: int = 32, latent_dim: int = 16,
                 kernel_size: int = 5):
        """Build convolution layers and the linear bottleneck.

        :param max_turns: sequence length T
        :param n_features: features per turn F
        :param channels: convolution channels
        :param latent_dim: size of the bottleneck
        :param kernel_size: temporal kernel width (odd)
        """
        super().__init__()
        pad = kernel_size // 2
        self.max_turns = max_turns
        self.channels = channels
        self.encoder = nn.Sequential(
            nn.Conv1d(n_features + 1, channels, kernel_size, padding=pad), nn.ReLU(inplace=True),
            nn.Conv1d(channels, channels, kernel_size, padding=pad, stride=2), nn.ReLU(inplace=True),
        )
        reduced = math.ceil(max_turns / 2)
        self.to_latent = nn.Linear(channels * reduced, latent_dim)
        self.from_latent = nn.Linear(latent_dim, channels * max_turns)
        self.decoder = nn.Sequential(
            nn.ReLU(inplace=True),
            nn.Conv1d(channels, channels, kernel_size, padding=pad), nn.ReLU(inplace=True),
            nn.Conv1d(channels, n_features, kernel_size, padding=pad),
        )

    def forward(self, x, mask, lengths):
        """Reconstruct ``x``; ``lengths`` is unused by this architecture."""
        b = x.shape[0]
        inp = torch.cat([x * mask.unsqueeze(-1), mask.unsqueeze(-1)], dim=-1).transpose(1, 2)
        h = self.encoder(inp).reshape(b, -1)
        z = self.to_latent(h)
        h = self.from_latent(z).reshape(b, self.channels, self.max_turns)
        return self.decoder(h).transpose(1, 2)


def build_autoencoder(arch: str, max_turns: int, n_features: int, arch_kwargs: Optional[Dict] = None) -> nn.Module:
    """Create one autoencoder of type ``arch`` ("mlp", "gru" or "conv1d")."""
    arch_kwargs = dict(arch_kwargs or {})
    if arch == "mlp":
        if "hidden_dims" in arch_kwargs:
            arch_kwargs["hidden_dims"] = tuple(arch_kwargs["hidden_dims"])
        return MLPAutoencoder(max_turns, n_features, **arch_kwargs)
    if arch == "gru":
        return GRUAutoencoder(max_turns, n_features, **arch_kwargs)
    if arch == "conv1d":
        return Conv1dAutoencoder(max_turns, n_features, **arch_kwargs)
    raise ValueError(f"Unknown architecture '{arch}'. Options: {ARCHITECTURES}")


class AutoencoderBank(nn.Module):
    """K independent autoencoders evaluated together.

    ``forward`` returns reconstructions from every member, shape (B, K, T, F),
    which lets one DataParallel call train all class models at once while each
    sample only contributes to the loss of its own class model.
    """

    def __init__(self, n_classes: int, arch: str, max_turns: int, n_features: int,
                 arch_kwargs: Optional[Dict] = None):
        """Create ``n_classes`` autoencoders with identical architecture."""
        super().__init__()
        self.members = nn.ModuleList(
            [build_autoencoder(arch, max_turns, n_features, arch_kwargs) for _ in range(n_classes)]
        )

    def forward(self, x, mask, lengths):
        """Run every member on the batch and stack the outputs on dimension 1."""
        return torch.stack([m(x, mask, lengths) for m in self.members], dim=1)


# ---------------------------------------------------------------------------
# Errors and losses
# ---------------------------------------------------------------------------

def reconstruction_errors(recon: torch.Tensor, x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    """Masked mean squared error for every (sample, class model) pair -> (B, K)."""
    sq = (recon - x.unsqueeze(1)) ** 2                      # (B, K, T, F)
    sq = sq.mean(dim=-1) * mask.unsqueeze(1)                 # (B, K, T)
    denom = mask.sum(dim=-1).clamp(min=1.0).unsqueeze(1)     # (B, 1)
    return sq.sum(dim=-1) / denom


def bank_loss(errors: torch.Tensor, labels: torch.Tensor, loss_type: str = "own", margin: float = 0.05,
              margin_weight: float = 0.1) -> torch.Tensor:
    """Training loss for the bank.

    own              each autoencoder minimises error on its own class only
    own_plus_margin  additionally asks the other autoencoders to reconstruct
                     a sample at least ``margin`` worse than its own model
    """
    own = errors.gather(1, labels.view(-1, 1)).squeeze(1)
    loss = own.mean()
    if loss_type == "own":
        return loss
    if loss_type == "own_plus_margin":
        k = errors.shape[1]
        other_mask = torch.ones_like(errors)
        other_mask.scatter_(1, labels.view(-1, 1), 0.0)
        hinge = F.relu(margin - (errors - own.unsqueeze(1))) * other_mask
        return loss + margin_weight * hinge.sum(dim=1).mean() / max(k - 1, 1)
    raise ValueError(f"Unknown loss_type '{loss_type}'")


def decide(errors: np.ndarray, rule: str = "raw", calibration: Optional[Dict] = None) -> np.ndarray:
    """Convert an error matrix (N, K) into class indices.

    raw     lowest reconstruction error (the rule used in the thesis)
    zscore  errors standardised per class model with statistics measured on
            that model's own training data, then lowest score
    """
    if rule == "raw":
        return errors.argmin(axis=1)
    if rule == "zscore":
        if not calibration:
            raise ValueError("Decision rule 'zscore' needs calibration statistics")
        mu = np.asarray(calibration["mean"], dtype=np.float64)
        sd = np.asarray(calibration["std"], dtype=np.float64)
        return ((errors - mu) / np.maximum(sd, 1e-8)).argmin(axis=1)
    raise ValueError(f"Unknown decision rule '{rule}'")


# ---------------------------------------------------------------------------
# Checkpoints
# ---------------------------------------------------------------------------

def unwrap(model: nn.Module) -> nn.Module:
    """Strip DataParallel and torch.compile wrappers before saving."""
    if isinstance(model, nn.DataParallel):
        model = model.module
    return getattr(model, "_orig_mod", model)


def _plain(obj):
    """Convert metadata to plain JSON types (str, int, float, list, dict, None).

    Recent PyTorch releases load checkpoints with ``weights_only=True`` by
    default, which rejects anything else (numpy scalars, version objects, ...).
    """
    return json.loads(json.dumps(obj, default=lambda o: o.item() if hasattr(o, "item") else str(o)))


def save_checkpoint(path: str, model: nn.Module, meta: Dict) -> None:
    """Save the bank weights together with everything needed to use them.

    ``meta`` holds the architecture, classes, trace encoding, decision rule
    and calibration statistics, so a checkpoint is self-describing.
    """
    payload = _plain(meta)
    payload["state_dict"] = {k: v.detach().cpu() for k, v in unwrap(model).state_dict().items()}
    torch.save(payload, path)


def load_checkpoint(path: str, map_location="cpu") -> Dict:
    # The checkpoint only holds tensors and plain Python types, so it loads on
    # old releases and under the stricter default of recent releases.
    """Load a checkpoint written by :func:`save_checkpoint`."""
    return torch.load(path, map_location=map_location)


def bank_from_checkpoint(ckpt: Dict) -> AutoencoderBank:
    """Rebuild the autoencoder bank from a loaded checkpoint, in eval mode."""
    spec = EncodingSpec.from_dict(ckpt["encoding"])
    bank = AutoencoderBank(len(ckpt["levels"]), ckpt["arch"], spec.max_turns, spec.n_features, ckpt["arch_kwargs"])
    bank.load_state_dict(ckpt["state_dict"])
    bank.eval()
    return bank


# ---------------------------------------------------------------------------
# Inference wrapper used by the bot
# ---------------------------------------------------------------------------

class SkillEstimator:
    """Estimate the opponent class from a (partial) belief trace."""

    def __init__(self, checkpoint_path: str, decision_rule: Optional[str] = None, device: str = "cpu",
                 torch_threads: int = 1):
        """Load a trained estimator.

        :param checkpoint_path: estimator.pt written by the training scripts
        :param decision_rule: override of the rule stored in the checkpoint
        :param device: "cpu" during games; a GPU gives no benefit for one trace
        :param torch_threads: CPU threads for inference (1 keeps parallel games independent)
        """
        if torch_threads:
            torch.set_num_threads(torch_threads)
        ckpt = load_checkpoint(checkpoint_path, map_location=device)
        self.levels: List[int] = list(ckpt["levels"])
        self.spec = EncodingSpec.from_dict(ckpt["encoding"])
        self.calibration = ckpt.get("calibration")
        self.decision_rule = decision_rule or ckpt.get("decision_rule", "raw")
        self.device = torch.device(device)
        self.bank = bank_from_checkpoint(ckpt).to(self.device)

    @property
    def n_classes(self) -> int:
        """Number of opponent classes."""
        return len(self.levels)

    def errors(self, turns: List[Dict], color: bool) -> np.ndarray:
        """Reconstruction error of every class model for one (partial) trace."""
        x, mask, length = encode_trace(turns, color, self.spec)
        with torch.no_grad():
            xt = torch.from_numpy(x).unsqueeze(0).to(self.device)
            mt = torch.from_numpy(mask).unsqueeze(0).to(self.device)
            lt = torch.tensor([max(length, 1)], dtype=torch.long, device=self.device)
            err = reconstruction_errors(self.bank(xt, mt, lt), xt, mt)
        return err.squeeze(0).cpu().numpy()

    def estimate(self, turns: List[Dict], color: bool) -> Dict:
        """Classify the opponent from the trace so far.

        Returns the class index, its level, all errors and the margin between
        the best and second-best error (a simple confidence measure).
        """
        err = self.errors(turns, color)
        idx = int(decide(err[None, :], self.decision_rule, self.calibration)[0])
        ordered = np.sort(err)
        margin = float(ordered[1] - ordered[0]) if len(ordered) > 1 else 0.0
        return {"class_index": idx, "level": self.levels[idx], "errors": err.tolist(), "margin": margin}
