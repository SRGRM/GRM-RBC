"""
Parallel execution of local RBC games.

A game is described by a plain dictionary (a *task*) so that it can be sent to
a worker process and written to disk unchanged:

    {
      "game_id": "ep0003_g017",
      "our_color": "white",                     # or "black"
      "our_bot": {                              # keyword arguments for GRMStrangeFish
          "mode": "fixed",
          "personality": "cautious",            # resolved through "action_space"
          "forced_opening": None,
          "policy": None, "estimator": None,    # file paths
          "runtime_config": {...},              # RuntimeGRMConfig fields
          "track_estimates": False,
          "base_overrides": {"score": {"search_depth": 4}},
          "engine_threads": 1, "engine_hash_mb": 64,
      },
      "action_space": {"kind": "named", "grid_options": None, "subset": None},
      "opponent": {"type": "skill_trout", "level": 7},
      "opponent_defaults": {"move_time": 0.1, "threads": 1, "hash_mb": 16},
      "game": {"seconds_per_player": 120, "seconds_increment": 2,
               "reversible_moves_limit": 100, "full_turn_limit": 200},
      "meta": {...},                            # copied to the result as-is
      "save_history_path": None                 # optional: write the reconchess game history here
    }

Every game runs in a fresh process (``maxtasksperchild=1``) so Stockfish
processes, log handlers and caches never leak from one game to the next.
"""

import logging
import multiprocessing as mp
import time
import traceback
from typing import Callable, Dict, Iterable, List, Optional

import chess

from grm_rbc.common import log


def _build_our_bot(task: Dict):
    """Create the GRMStrangeFish instance described by ``task['our_bot']``."""
    from grm_rbc.grm import RuntimeGRMConfig
    from grm_rbc.grm_bot import GRMStrangeFish
    from grm_rbc.personalities import build_action_space, personality_index

    cfg = dict(task["our_bot"])
    space_cfg = task.get("action_space") or {"kind": "named"}
    space = build_action_space(space_cfg.get("kind", "named"), space_cfg.get("grid_options"),
                               space_cfg.get("subset"))
    by_name = personality_index(space)
    name = cfg.pop("personality", None)
    if name is not None and name not in by_name:
        raise ValueError(f"Personality '{name}' is not in the action space")
    runtime_cfg = cfg.pop("runtime_config", None)
    return GRMStrangeFish(
        fixed_personality=by_name.get(name) if name else by_name.get("default"),
        action_space=space,
        runtime_config=RuntimeGRMConfig(**runtime_cfg) if runtime_cfg else None,
        game_id=task["game_id"],
        **cfg,
    )


def run_game(task: Dict) -> Dict:
    """Play one game and return a result record. Never raises."""
    from reconchess import LocalGame, play_local_game
    from grm_rbc.opponents import make_opponent, opponent_label

    # TroutBot-style opponents often hand Stockfish inconsistent boards; python-chess
    # logs the resulting ponder parse errors at ERROR level and carries on.
    logging.getLogger("chess.engine").setLevel(logging.CRITICAL)
    started = time.time()
    result = {
        "game_id": task["game_id"],
        "our_color": task["our_color"],
        "opponent": opponent_label(task["opponent"]),
        "opponent_spec": task["opponent"],
        "meta": task.get("meta", {}),
        "error": None,
    }
    ours = theirs = None
    try:
        ours = _build_our_bot(task)
        theirs = make_opponent(task["opponent"], task.get("opponent_defaults"))
        game_cfg = task.get("game", {})
        game = LocalGame(
            seconds_per_player=game_cfg.get("seconds_per_player", 900),
            seconds_increment=game_cfg.get("seconds_increment", 5),
            reversible_moves_limit=game_cfg.get("reversible_moves_limit", 100),
            full_turn_limit=game_cfg.get("full_turn_limit"),
        )
        we_are_white = task["our_color"] == "white"
        white, black = (ours, theirs) if we_are_white else (theirs, ours)
        winner, win_reason, history = play_local_game(white, black, game=game)

        our_color = chess.WHITE if we_are_white else chess.BLACK
        if winner is None:
            outcome = 0
        else:
            outcome = 1 if winner == our_color else -1
        result.update({
            "outcome": outcome,
            "winner": None if winner is None else chess.COLOR_NAMES[winner],
            "win_reason": getattr(win_reason, "name", str(win_reason)),
            "n_turns": len(ours.trace),
        })
        result.update(ours.summary)
        result["color"] = we_are_white
        if task.get("save_history_path"):
            history.save(task["save_history_path"])
            result["history_path"] = task["save_history_path"]
    except Exception as exc:
        result.update({"outcome": None, "error": f"{type(exc).__name__}: {exc}",
                       "traceback": traceback.format_exc()})
        for bot in (ours, theirs):
            engine = getattr(bot, "engine", None)
            if engine is not None:
                try:
                    engine.quit()
                except Exception:
                    pass
    result["duration_sec"] = round(time.time() - started, 2)
    return result


def outcome_char(result: Dict) -> str:
    """One-letter result for progress lines: W, D, L or E (error)."""
    if result.get("error"):
        return "E"
    return {1: "W", 0: "D", -1: "L"}.get(result.get("outcome"), "?")


def run_games(tasks: List[Dict], workers: int = 1, start_method: str = "spawn",
              on_result: Optional[Callable[[Dict], None]] = None, label: str = "games") -> List[Dict]:
    """Run ``tasks`` with ``workers`` processes and print one line per finished game."""
    results: List[Dict] = []
    total = len(tasks)
    if total == 0:
        return results
    t0 = time.time()

    def report(res: Dict) -> None:
        """Store one result, print its progress line and pass it to ``on_result``."""
        results.append(res)
        wins = sum(1 for r in results if r.get("outcome") == 1)
        errs = sum(1 for r in results if r.get("error"))
        extra = f" error={res['error']}" if res.get("error") else ""
        log(f"  {label} {len(results)}/{total}  {res['game_id']}  {res['our_color']:5s} vs {res['opponent']:<14s} "
            f"{outcome_char(res)}  turns={res.get('n_turns', '-')}  {res['duration_sec']:.0f}s  "
            f"(wins {wins}, errors {errs}, elapsed {time.time() - t0:.0f}s){extra}")
        if on_result:
            on_result(res)

    if workers <= 1:
        for task in tasks:
            report(run_game(task))
        return results

    ctx = mp.get_context(start_method)
    with ctx.Pool(processes=workers, maxtasksperchild=1) as pool:
        for res in pool.imap_unordered(run_game, tasks):
            report(res)
    return results


def alternate_colors(n: int, first: str = "white") -> Iterable[str]:
    """Yield ``n`` colours alternating between white and black."""
    other = "black" if first == "white" else "white"
    for i in range(n):
        yield first if i % 2 == 0 else other
