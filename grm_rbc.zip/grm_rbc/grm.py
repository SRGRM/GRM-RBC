"""
Generative Reward Machine (GRM) for Reconnaissance Blind Chess.

A standard reward machine reads high-level events from the true environment
state. In RBC the true state is hidden, so the GRM works on an *estimated*
state produced by an estimator (here: the opponent-skill autoencoder bank):

    true state ts  ->  observation os  ->  estimator  ->  estimated state es

On every transition es -> es' a labelling function emits propositional
symbols, the machine's finite state u moves to u', and the reward function
attached to u produces the reward. Because the reward is defined on the
estimated space (and averaged over a batch of games), the learning signal
stays stationary even though single RBC games are very noisy.

This module holds:

    LabellingFunction   symbols for game-level and turn-level transitions
    BatchRewardMachine  FSM that turns N game outcomes into one batch reward
    GRMPolicy           tabular learner of Algorithm 3 (Q(s, a) = mean batch reward)
    RuntimeGRM          FSM used during play to switch personality when the
                        estimated opponent class becomes reliable
"""

import math
import random
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, FrozenSet, List, Optional, Sequence

import numpy as np

# Outcome symbols reported by the labelling function at game end.
WIN, DRAW, LOSS, FORFEIT = "win", "draw", "loss", "forfeit"
# Turn-level symbols for transitions in the estimated state space.
SAME_CLASS, CLASS_SHIFT, NO_ESTIMATE = "same_class", "class_shift", "no_estimate"


class LabellingFunction:
    """Maps transitions in the estimated space to sets of symbols."""

    def label_turn(self, es: Optional[int], es_next: Optional[int]) -> FrozenSet[str]:
        """Symbol for a turn-level transition es -> es' in the estimated space."""
        if es_next is None:
            return frozenset({NO_ESTIMATE})
        if es is None or es == es_next:
            return frozenset({SAME_CLASS})
        return frozenset({CLASS_SHIFT})

    def label_game(self, result: Dict) -> FrozenSet[str]:
        """``result`` is a game record from :mod:`grm_rbc.game_runner`."""
        if result.get("error"):
            return frozenset({FORFEIT})
        outcome = result.get("outcome")
        if outcome == 1:
            return frozenset({WIN})
        if outcome == -1:
            return frozenset({LOSS})
        return frozenset({DRAW})


# ---------------------------------------------------------------------------
# Training-time reward machine
# ---------------------------------------------------------------------------

@dataclass
class BatchRewardMachine:
    """Reward machine with states {collecting, emit}.

    While collecting, each game-end symbol is stored and the reward is zero.
    When ``batch_size`` games have been seen the machine moves to *emit*, the
    reward function of that state returns the mean scored outcome of the batch,
    and the machine resets to collecting.

    forfeit_policy
        "exclude"  games that crashed or lost connection are not counted, as
                   in the tournament ratings computed without forfeits
        "as_loss"  a forfeit counts as a loss
    """

    batch_size: int = 100
    win_score: float = 1.0
    draw_score: float = 0.0
    loss_score: float = -1.0
    forfeit_policy: str = "exclude"
    state: str = "collecting"
    outcomes: List[float] = field(default_factory=list)
    symbol_counts: Counter = field(default_factory=Counter)

    def reset(self) -> None:
        """Return to the collecting state with an empty batch."""
        self.state = "collecting"
        self.outcomes = []
        self.symbol_counts = Counter()

    def _score(self, symbols: FrozenSet[str]) -> Optional[float]:
        """Numeric value of a game-end symbol set, or None if the game is excluded."""
        if WIN in symbols:
            return self.win_score
        if LOSS in symbols:
            return self.loss_score
        if DRAW in symbols:
            return self.draw_score
        if FORFEIT in symbols:
            if self.forfeit_policy == "exclude":
                return None
            if self.forfeit_policy == "as_loss":
                return self.loss_score
            raise ValueError(f"Unknown forfeit_policy '{self.forfeit_policy}'")
        raise ValueError(f"No outcome symbol in {set(symbols)}")

    def step(self, symbols: FrozenSet[str], games_in_batch: Optional[int] = None) -> float:
        """Consume one game's symbols. Returns the reward of the resulting state."""
        if self.state == "emit":
            self.reset()
        for s in symbols:
            self.symbol_counts[s] += 1
        score = self._score(symbols)
        if score is not None:
            self.outcomes.append(score)
        target = games_in_batch or self.batch_size
        seen = sum(self.symbol_counts[s] for s in (WIN, DRAW, LOSS, FORFEIT))
        if seen >= target:
            self.state = "emit"
            return self.batch_reward()
        return 0.0

    def batch_reward(self) -> float:
        """Mean scored outcome of the current batch (NaN if every game was excluded)."""
        return float(np.mean(self.outcomes)) if self.outcomes else float("nan")

    def run(self, symbol_sets: Sequence[FrozenSet[str]]) -> float:
        """Feed a whole batch and return the emitted reward."""
        self.reset()
        reward = float("nan")
        for symbols in symbol_sets:
            reward = self.step(symbols, games_in_batch=len(symbol_sets))
        return reward if self.state == "emit" else float("nan")


# ---------------------------------------------------------------------------
# Algorithm 3: tabular GRM policy learning
# ---------------------------------------------------------------------------

class GRMPolicy:
    """Q(s, a) is the mean of all batch rewards observed for (s, a).

    States are opponent classes (indices into ``levels``), actions are
    personality names.
    """

    def __init__(self, levels: Sequence[int], actions: Sequence[str], default_action: str = "default",
                 initial_q: float = 0.0):
        """Create an empty table over ``levels`` x ``actions``.

        :param levels: opponent classes (the GRM states)
        :param actions: personality names (the GRM actions)
        :param default_action: personality used for classes that were never trained
        :param initial_q: value reported before any batch has been seen
        """
        self.levels = list(levels)
        self.actions = list(actions)
        self.default_action = default_action if default_action in self.actions else self.actions[0]
        self.initial_q = initial_q
        n_s, n_a = len(self.levels), len(self.actions)
        self.q = np.full((n_s, n_a), initial_q, dtype=np.float64)
        self.n = np.zeros((n_s, n_a), dtype=np.int64)
        self.history: List[List[List[float]]] = [[[] for _ in range(n_a)] for _ in range(n_s)]

    # -- indices -------------------------------------------------------------
    def a_index(self, action: str) -> int:
        """Column of the table for a personality name."""
        return self.actions.index(action)

    def s_index(self, level: int) -> int:
        """Row of the table for an opponent level."""
        return self.levels.index(level)

    # -- learning --------------------------------------------------------------
    def update(self, s: int, a: int, batch_reward: float) -> float:
        """Record one batch reward for (s, a) and set Q(s, a) to the mean of its history.

        NaN rewards (batches in which every game was excluded) are ignored.
        """
        if math.isnan(batch_reward):
            return float(self.q[s, a])
        self.history[s][a].append(float(batch_reward))
        self.n[s, a] += 1
        self.q[s, a] = float(np.mean(self.history[s][a]))
        return float(self.q[s, a])

    def select_state(self, rule: str, rng: random.Random, episode: int) -> int:
        """Which opponent class to train on next.

        cycle          classes in turn
        uniform        uniformly at random
        least_visited  class with the fewest batches so far (ties at random)
        """
        n_s = len(self.levels)
        if rule == "cycle":
            return episode % n_s
        if rule == "uniform":
            return rng.randrange(n_s)
        if rule == "least_visited":
            visits = self.n.sum(axis=1)
            best = np.flatnonzero(visits == visits.min())
            return int(rng.choice(list(best)))
        raise ValueError(f"Unknown state selection rule '{rule}'")

    def select_action(self, s: int, rule: str, rng: random.Random, epsilon: float = 0.1,
                      ucb_c: float = 1.0) -> int:
        """Which personality to evaluate in class ``s``.

        epsilon_greedy  random with probability epsilon, else best Q
        ucb1            Q plus an exploration bonus; untried actions first
        round_robin     least-tried action (systematic sweep)
        """
        n_a = len(self.actions)
        counts = self.n[s]
        if rule == "round_robin":
            best = np.flatnonzero(counts == counts.min())
            return int(rng.choice(list(best)))
        if rule == "ucb1":
            untried = np.flatnonzero(counts == 0)
            if len(untried):
                return int(rng.choice(list(untried)))
            total = counts.sum()
            scores = self.q[s] + ucb_c * np.sqrt(np.log(total) / counts)
            best = np.flatnonzero(np.isclose(scores, scores.max()))
            return int(rng.choice(list(best)))
        if rule == "epsilon_greedy":
            untried = np.flatnonzero(counts == 0)
            if rng.random() < epsilon:
                return rng.randrange(n_a)
            if len(untried):
                return int(rng.choice(list(untried)))
            best = np.flatnonzero(np.isclose(self.q[s], self.q[s].max()))
            return int(rng.choice(list(best)))
        raise ValueError(f"Unknown action selection rule '{rule}'")

    # -- policy -----------------------------------------------------------------
    def greedy_action(self, s: int) -> str:
        """Best personality for class ``s``; the default personality if untried."""
        if self.n[s].sum() == 0:
            return self.default_action
        q = np.where(self.n[s] > 0, self.q[s], -np.inf)
        return self.actions[int(np.argmax(q))]

    def q_value(self, s: int, action: str) -> float:
        """Learned value of ``action`` in class ``s``; NaN if the pair was never tried."""
        a = self.a_index(action)
        return float(self.q[s, a]) if self.n[s, a] > 0 else float("nan")

    def greedy_policy(self) -> Dict[str, str]:
        """Mapping level -> best personality, as saved in greedy_policy.json."""
        return {str(level): self.greedy_action(i) for i, level in enumerate(self.levels)}

    def to_dict(self) -> Dict:
        """Serialisable state: table, visit counts, reward history and greedy policy."""
        return {
            "kind": "grm",
            "levels": self.levels,
            "actions": self.actions,
            "default_action": self.default_action,
            "initial_q": self.initial_q,
            "q": self.q.tolist(),
            "n": self.n.tolist(),
            "history": self.history,
            "greedy_policy": self.greedy_policy(),
        }

    @staticmethod
    def from_dict(d: Dict) -> "GRMPolicy":
        """Rebuild a policy saved with :meth:`to_dict` (extra keys are ignored)."""
        p = GRMPolicy(d["levels"], d["actions"], d.get("default_action", "default"), d.get("initial_q", 0.0))
        p.q = np.asarray(d["q"], dtype=np.float64)
        p.n = np.asarray(d["n"], dtype=np.int64)
        p.history = d["history"]
        return p

    def table_rows(self) -> List[Dict]:
        """One row per (level, personality) with visits, Q, spread and greedy flag."""
        rows = []
        for i, level in enumerate(self.levels):
            for j, action in enumerate(self.actions):
                h = self.history[i][j]
                rows.append({
                    "level": level, "personality": action, "visits": int(self.n[i, j]),
                    "q": float(self.q[i, j]) if self.n[i, j] else "",
                    "std": float(np.std(h)) if len(h) > 1 else "",
                    "greedy": action == self.greedy_action(i),
                })
        return rows


# ---------------------------------------------------------------------------
# Run-time GRM inside the bot
# ---------------------------------------------------------------------------

CALIBRATING, TRACKING, COMMITTED, FROZEN = "calibrating", "tracking", "committed", "frozen"


@dataclass
class RuntimeGRMConfig:
    """Switching rules of the run-time GRM."""

    warmup_turns: int = 6         # turns played with the default personality before estimating
    estimate_every: int = 1       # run the estimator every k turns after warm-up
    confirm_turns: int = 2        # consecutive identical estimates required to commit to a class
    switch_margin: float = 0.0    # minimum Q gain over the current personality to switch
    allow_reswitch: bool = True   # keep tracking after the first commitment
    min_estimator_margin: float = 0.0  # ignore estimates whose best/second-best error gap is smaller


class RuntimeGRM:
    """Finite-state controller that runs inside one game.

    States
        calibrating  before ``warmup_turns``: play the default personality
        tracking     a candidate class is being confirmed
        committed    a personality chosen by the learned policy is in use
        frozen       StrangeFish2 has switched to its time-pressure plan;
                     estimates are still logged but personalities are no
                     longer changed

    The reward generated on each estimated transition is the learned value
    Q(es', current personality): the expected batch outcome of the current
    behaviour against the class the opponent now appears to belong to. It is
    logged for analysis and drives the switch decision.
    """

    def __init__(self, policy: GRMPolicy, config: RuntimeGRMConfig, labeller: Optional[LabellingFunction] = None):
        """Start a new game in the calibrating state with the default personality."""
        self.policy = policy
        self.cfg = config
        self.labeller = labeller or LabellingFunction()
        self.state = CALIBRATING
        self.current_action = policy.default_action
        self.es: Optional[int] = None
        self.candidate: Optional[int] = None
        self.candidate_count = 0
        self.log: List[Dict] = []

    def freeze(self) -> None:
        """Stop changing personality (StrangeFish2 is in its time-pressure plan)."""
        self.state = FROZEN

    def step(self, turn: int, estimate: Optional[Dict]) -> Optional[str]:
        """Advance the machine with this turn's estimate.

        Returns the name of a personality to switch to, or None to keep the
        current one (always None once frozen).
        """
        es_next = None
        if estimate is not None and estimate.get("margin", 0.0) >= self.cfg.min_estimator_margin:
            es_next = int(estimate["class_index"])
        symbols = self.labeller.label_turn(self.es, es_next)

        reward = float("nan")
        if es_next is not None:
            reward = self.policy.q_value(es_next, self.current_action)

        switch_to = None
        if es_next is not None and self.state != FROZEN:
            if self.candidate == es_next:
                self.candidate_count += 1
            else:
                self.candidate, self.candidate_count = es_next, 1
            if self.state == CALIBRATING:
                self.state = TRACKING
            if self.candidate_count >= self.cfg.confirm_turns and (
                self.state == TRACKING or (self.state == COMMITTED and self.cfg.allow_reswitch)
            ):
                proposal = self.policy.greedy_action(es_next)
                gain = self._gain(es_next, proposal)
                if proposal != self.current_action and (math.isnan(gain) or gain >= self.cfg.switch_margin):
                    switch_to = proposal
                    self.current_action = proposal
                self.state = COMMITTED
        if es_next is not None:
            self.es = es_next

        self.log.append({
            "turn": turn,
            "state": self.state,
            "estimated_level": None if es_next is None else self.policy.levels[es_next],
            "symbols": sorted(symbols),
            "generated_reward": None if math.isnan(reward) else reward,
            "personality": self.current_action,
            "switched": switch_to is not None,
        })
        return switch_to

    def _gain(self, s: int, proposal: str) -> float:
        """Learned improvement of ``proposal`` over the current personality in class ``s``."""
        q_new = self.policy.q_value(s, proposal)
        q_cur = self.policy.q_value(s, self.current_action)
        if math.isnan(q_cur):
            return float("nan")
        return q_new - q_cur

    def wants_estimate(self, turn: int) -> bool:
        # Estimates are still produced (and logged) when frozen; they just no
        # longer change the personality.
        """Whether the estimator should run on this turn."""
        if turn < self.cfg.warmup_turns:
            return False
        return (turn - self.cfg.warmup_turns) % max(self.cfg.estimate_every, 1) == 0
