"""
Play on the public RBC server (https://rbc.jhuapl.edu) with the GRM bot.

Adapted from ``scripts/modified_rc_connect.py`` of StrangeFish2: each accepted
invitation runs in its own process, server calls are retried on transient
errors, and the bot keeps expanding its board set while the opponent thinks.
"""

import json
import logging
import multiprocessing
import signal
import time
import traceback
from typing import Callable

import chess
import requests
from reconchess import ChessJSONDecoder, ChessJSONEncoder, Player, RemoteGame, play_turn
from reconchess.scripts.rc_connect import RBCServer

logger = logging.getLogger("grm-connect")


class RetryingRemoteGame(RemoteGame):
    """RemoteGame that retries on server errors and dropped connections."""

    def __init__(self, server_url, game_id, auth, retry_wait: float = 0.5):
        """Connect to game ``game_id`` on ``server_url`` with HTTP basic ``auth``."""
        self.retry_wait = retry_wait
        super().__init__(server_url, game_id, auth)

    def is_op_turn(self) -> bool:
        """True while the game is running and it is the opponent's turn."""
        status = self._get("game_status")
        return not status["is_over"] and not status["is_my_turn"]

    def _request(self, method: str, endpoint: str, data=None, decoder_cls=ChessJSONDecoder):
        """Send a GET or POST, retrying on 5xx responses and connection errors.

        Client errors (4xx) raise ValueError with the server's message.
        """
        url = f"{self.game_url}/{endpoint}"
        while True:
            try:
                if method == "get":
                    response = self.session.get(url)
                else:
                    response = self.session.post(url, data=data)
                if response.status_code == 200:
                    return response.json(cls=decoder_cls)
                if response.status_code >= 500:
                    time.sleep(self.retry_wait)
                    continue
                raise ValueError(response.text)
            except requests.RequestException as exc:
                logger.warning(f"Request to {endpoint} failed ({exc}); retrying")
                time.sleep(self.retry_wait)

    def _get(self, endpoint, decoder_cls=ChessJSONDecoder):
        """GET ``endpoint`` and decode the JSON response."""
        return self._request("get", endpoint, decoder_cls=decoder_cls)

    def _post(self, endpoint, obj):
        """POST ``obj`` as JSON to ``endpoint`` and decode the response."""
        return self._request("post", endpoint, data=json.dumps(obj, cls=ChessJSONEncoder))


def play_remote_game(server_url, game_id, auth, player: Player):
    """Play one server game with ``player`` and return (winner, reason, history)."""
    game = RetryingRemoteGame(server_url, game_id, auth)
    opponent = game.get_opponent_name()
    color = game.get_player_color()
    logger.info(f"Game {game_id}: playing {chess.COLOR_NAMES[color]} against {opponent}")

    player.handle_game_start(color, game.get_starting_board(), opponent)
    game.start()
    while not game.is_over():
        play_turn(game, player, end_turn_last=False)
        # Use the opponent's thinking time to expand the board set for next turn.
        while game.is_op_turn():
            player.while_we_wait()

    winner, reason, history = game.get_winner_color(), game.get_win_reason(), game.get_game_history()
    player.handle_game_end(winner, reason, history)
    return winner, reason, history


def _ignore_one_sigint():
    """Let a game process survive the first Ctrl+C so running games can finish."""
    def handler(signum, frame):
        """Restore the default handler; a second Ctrl+C stops the process."""
        signal.signal(signal.SIGINT, signal.SIG_DFL)
    signal.signal(signal.SIGINT, handler)


def _accept_and_play(server_url, auth, invitation_id, finished, bot_factory: Callable[[int], Player]):
    """Worker process: accept one invitation, play the game, always close the invitation."""
    _ignore_one_sigint()
    server = RBCServer(server_url, auth)
    game_id = server.accept_invitation(invitation_id)
    logger.info(f"Invitation {invitation_id} accepted, game {game_id}")
    player = bot_factory(game_id)
    try:
        play_remote_game(server_url, game_id, auth, player)
    except Exception:
        traceback.print_exc()
        server.error_resign(game_id)
        try:
            player.handle_game_end(None, None, None)
        except Exception:
            pass
        logger.error(f"Game {game_id} closed after an error")
    finally:
        server.finish_invitation(invitation_id)
        finished.value = True


def listen_for_invitations(server_url: str, auth, bot_factory: Callable[[int], Player],
                           max_concurrent_games: int = 1, ranked: bool = False,
                           limit_games: int = None, poll_seconds: float = 5.0):
    """Accept invitations until interrupted (or until ``limit_games`` have been joined)."""
    server = RBCServer(server_url, auth)
    server.set_ranked(ranked)
    server.set_max_games(max_concurrent_games)
    logger.info(f"Connected to {server_url} (ranked={ranked}, max games={max_concurrent_games})")

    def stop(signum, frame):
        """Stop accepting games and leave the ranked pool before exiting."""
        signal.signal(signal.SIGINT, signal.SIG_DFL)
        logger.warning("Stopping: no new games will be accepted")
        server.set_ranked(False)
        server.set_max_games(0)
        raise SystemExit(0)

    signal.signal(signal.SIGINT, stop)

    processes, flags, joined = {}, {}, 0
    while True:
        try:
            invitations = server.get_invitations()
            for inv in [i for i, p in processes.items() if not p.is_alive() or flags[i].value]:
                processes.pop(inv).join(timeout=1)
                flags.pop(inv)
            if limit_games is not None and joined >= limit_games:
                server.set_max_games(0)
                if not processes:
                    return
            else:
                for inv in invitations:
                    if inv in processes or len(processes) >= max_concurrent_games:
                        continue
                    flag = multiprocessing.Value("b", False)
                    proc = multiprocessing.Process(target=_accept_and_play,
                                                   args=(server_url, auth, inv, flag, bot_factory))
                    proc.start()
                    processes[inv], flags[inv] = proc, flag
                    joined += 1
        except requests.RequestException as exc:
            logger.warning(f"Server unreachable: {exc}")
        time.sleep(poll_seconds)
