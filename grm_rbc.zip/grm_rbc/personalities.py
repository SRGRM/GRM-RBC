"""
Strategic personalities: the discrete action space of the GRM.

A personality is a named set of overrides applied on top of the StrangeFish2
defaults (SenseConfig, MoveConfig, TimeConfig and ScoreConfig). Choosing an
action in the GRM therefore means choosing how aggressive, cautious,
unpredictable or exploratory the bot plays.

The three hyperparameters that shape behaviour most strongly are
``max_score_factor`` (aggression), ``threshold_score`` (unpredictability)
and ``sampling_exploration_coef`` (exploration of rarely evaluated moves).
Both action-space builders below are centred on them.
"""

import copy
import itertools
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional

SECTIONS = ("sense", "move", "time", "score")

# Valid field names for every section; overrides are checked against these so
# that a typo in a personality fails loudly instead of being ignored.
VALID_FIELDS = {
    "sense": {
        "boards_per_centipawn", "expected_outcome_coef", "worst_outcome_coef",
        "outcome_variance_coef", "score_variance_coef",
    },
    "move": {
        "mean_score_factor", "min_score_factor", "max_score_factor", "threshold_score",
        "sense_by_move", "force_promotion_queen", "sampling_exploration_coef", "move_sample_rep_limit",
    },
    "time": {
        "turns_to_plan_for", "min_time_for_turn", "max_time_for_turn",
        "time_for_sense", "time_for_move", "calc_time_per_move",
    },
    "score": {
        "capture_king_score", "checkmate_score", "points_per_move_to_mate", "into_check_score",
        "remain_in_check_penalty", "op_into_check_score", "search_depth", "reward_attacker",
        "reward_check_threats", "require_sneak", "unsafe_attacker_penalty", "hanging_material_penalty_ratio",
        "capture_penalty", "passing_reward", "safe_pawn_pressure_reward", "unsafe_pawn_pressure_reward",
        "passed_pawn_reward", "castling_rights_bonus", "use_absolute_score", "weak_squares_score",
        "skip_bonus_evals", "reduce_heuristic_when_equal",
    },
}


@dataclass
class Personality:
    """A named set of overrides for the four StrangeFish2 config sections."""

    name: str
    sense: Dict[str, float] = field(default_factory=dict)
    move: Dict[str, float] = field(default_factory=dict)
    time: Dict[str, float] = field(default_factory=dict)
    score: Dict[str, float] = field(default_factory=dict)
    description: str = ""

    def validate(self) -> None:
        """Reject unknown field names and score weights that do not sum to one."""
        for section in SECTIONS:
            unknown = set(getattr(self, section)) - VALID_FIELDS[section]
            if unknown:
                raise ValueError(f"Personality '{self.name}': unknown {section} fields {sorted(unknown)}")
        weights = [self.move.get(k) for k in ("mean_score_factor", "min_score_factor", "max_score_factor")]
        if all(w is not None for w in weights) and abs(sum(weights) - 1.0) > 1e-6:
            raise ValueError(f"Personality '{self.name}': mean/min/max score factors must sum to 1 (got {sum(weights)})")

    def to_dict(self) -> Dict:
        """Plain dictionary form (used in policy files and the tournament config)."""
        return asdict(self)

    @staticmethod
    def from_dict(d: Dict) -> "Personality":
        """Build and validate a personality from :meth:`to_dict` output."""
        p = Personality(
            name=d["name"],
            sense=dict(d.get("sense", {})),
            move=dict(d.get("move", {})),
            time=dict(d.get("time", {})),
            score=dict(d.get("score", {})),
            description=d.get("description", ""),
        )
        p.validate()
        return p


# ---------------------------------------------------------------------------
# Action-space builders
# ---------------------------------------------------------------------------

def named_personalities() -> List[Personality]:
    """A small, interpretable action space.

    Every entry keeps mean + min + max score factors equal to one so that the
    compound move score stays on the centipawn scale used by StrangeFish2.
    """
    return [
        Personality(
            "default",
            description="StrangeFish2 tournament settings.",
        ),
        Personality(
            "aggressive",
            move={"mean_score_factor": 0.6, "min_score_factor": 0.1, "max_score_factor": 0.3},
            sense={"worst_outcome_coef": 0.1},
            score={"reward_attacker": 40, "reward_check_threats": 25},
            description="Chases high-upside moves and king attacks.",
        ),
        Personality(
            "gambler",
            move={"mean_score_factor": 0.5, "min_score_factor": 0.0, "max_score_factor": 0.5,
                  "threshold_score": 20},
            sense={"worst_outcome_coef": 0.0, "outcome_variance_coef": -0.1},
            description="Bets on best-case outcomes; ignores worst cases.",
        ),
        Personality(
            "cautious",
            move={"mean_score_factor": 0.5, "min_score_factor": 0.5, "max_score_factor": 0.0,
                  "threshold_score": 5},
            sense={"worst_outcome_coef": 0.4, "outcome_variance_coef": -0.5},
            description="Protects against the worst board in the belief set.",
        ),
        Personality(
            "unpredictable",
            move={"threshold_score": 40},
            description="Picks among a wide band of near-best moves.",
        ),
        Personality(
            "explorer",
            move={"sampling_exploration_coef": 5_000.0},
            description="Evaluates rarely sampled moves more often (larger UCT bonus).",
        ),
        Personality(
            "focused",
            move={"sampling_exploration_coef": 200.0, "threshold_score": 2},
            description="Concentrates evaluation time on the current best moves.",
        ),
        Personality(
            "info_seeker",
            sense={"boards_per_centipawn": 200, "score_variance_coef": 0.3},
            time={"time_for_sense": 0.8, "time_for_move": 0.2},
            description="Spends more effort shrinking the belief set.",
        ),
    ]


def grid_personalities(
    max_score_factors=(0.0, 0.2, 0.4),
    threshold_scores=(5.0, 10.0, 30.0),
    exploration_coefs=(300.0, 1_000.0, 3_000.0),
    min_score_factor: float = 0.3,
) -> List[Personality]:
    """Cartesian grid over the three most influential move hyperparameters.

    The mean factor is set so that mean + min + max = 1. The StrangeFish2
    defaults are always included as "default", which the bot plays before it
    has an estimate of the opponent.
    """
    out = [Personality("default", description="StrangeFish2 tournament settings.")]
    for mx, th, ex in itertools.product(max_score_factors, threshold_scores, exploration_coefs):
        mean = 1.0 - min_score_factor - mx
        if mean < 0:
            raise ValueError(f"max_score_factor={mx} with min_score_factor={min_score_factor} leaves a negative mean")
        name = f"max{mx:g}_thr{th:g}_exp{ex:g}"
        out.append(Personality(
            name,
            move={"mean_score_factor": round(mean, 6), "min_score_factor": min_score_factor,
                  "max_score_factor": mx, "threshold_score": th, "sampling_exploration_coef": ex},
            description="grid point",
        ))
    return out


def build_action_space(kind: str, grid_options: Optional[Dict] = None,
                       subset: Optional[List[str]] = None) -> List[Personality]:
    """Return the list of personalities for ``kind`` in {"named", "grid"}."""
    if kind == "named":
        space = named_personalities()
    elif kind == "grid":
        space = grid_personalities(**(grid_options or {}))
    else:
        raise ValueError(f"Unknown action space '{kind}' (use 'named' or 'grid')")
    if subset:
        by_name = {p.name: p for p in space}
        missing = [n for n in subset if n not in by_name]
        if missing:
            raise ValueError(f"Personalities not found in '{kind}' space: {missing}")
        space = [by_name[n] for n in subset]
    names = [p.name for p in space]
    if len(set(names)) != len(names):
        raise ValueError("Personality names must be unique")
    for p in space:
        p.validate()
    return space


# ---------------------------------------------------------------------------
# Turning a personality into StrangeFish2 config objects
# ---------------------------------------------------------------------------

def make_configs(personality: Optional[Personality], base_overrides: Optional[Dict[str, Dict]] = None):
    """Create fresh SenseConfig, MoveConfig, TimeConfig and ScoreConfig objects.

    New instances are built on every call. StrangeFish2 mutates its config
    objects in ``last_ditch_plan``, so sharing them between games would leak
    the emergency settings of one game into the next.

    ``base_overrides`` are applied first (e.g. a lower search depth used for
    fast training games) and the personality is applied on top.
    """
    from strangefish.strangefish_strategy import SenseConfig, MoveConfig, TimeConfig
    from strangefish.utilities.rbc_move_score import ScoreConfig

    configs = {
        "sense": SenseConfig(),
        "move": MoveConfig(),
        "time": TimeConfig(),
        "score": ScoreConfig(),
    }
    layers = []
    if base_overrides:
        layers.append(base_overrides)
    if personality is not None:
        layers.append({s: getattr(personality, s) for s in SECTIONS})
    for layer in layers:
        for section, values in layer.items():
            if section not in configs:
                raise ValueError(f"Unknown config section '{section}'")
            for key, value in (values or {}).items():
                if key not in VALID_FIELDS[section]:
                    raise ValueError(f"Unknown {section} field '{key}'")
                setattr(configs[section], key, copy.deepcopy(value))
    return configs["sense"], configs["move"], configs["time"], configs["score"]


def personality_index(space: List[Personality]) -> Dict[str, Personality]:
    """Mapping name -> personality."""
    return {p.name: p for p in space}
