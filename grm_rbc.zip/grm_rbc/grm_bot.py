"""
GRM-driven StrangeFish2 agent.

The agent keeps the StrangeFish2 multiple-hypothesis tracker and decision
logic unchanged and adds three things:

1. It records the size of its belief state at every stage of every turn.
2. It can run the opponent-skill estimator on that record during the game.
3. It can change its strategic personality while playing.

Modes
-----
fixed      play one personality for the whole game (used to generate
           estimator data, to play training batches and as an opponent)
grm        start with the default personality, estimate the opponent class
           after a warm-up, and switch to the personality that the learned
           GRM policy prefers for that class
opening_q  Q-learning baseline: choose an opening line and a personality
           from the colour-based Q-table before the game starts

Must be imported after the Stockfish path has been configured, because
StrangeFish2 checks ``STOCKFISH_EXECUTABLE`` on import.
"""

import logging
from typing import Dict, List, Optional, Union

import chess
import chess.engine

import strangefish.strangefish_strategy as sf_strategy
from strangefish.strangefish_strategy import StrangeFish2
from strangefish.utilities.stockfish import STOCKFISH_EXECUTABLE

from grm_rbc.baseline import OpeningQLearner
from grm_rbc.belief import BeliefTrace
from grm_rbc.common import load_json
from grm_rbc.estimator import SkillEstimator
from grm_rbc.grm import GRMPolicy, RuntimeGRM, RuntimeGRMConfig
from grm_rbc.openings import opening_moves
from grm_rbc.personalities import (Personality, build_action_space, make_configs, named_personalities,
                                   personality_index)

MODES = ("fixed", "grm", "opening_q")


def action_space_for_policy(path_or_obj) -> Optional[List[Personality]]:
    """Rebuild the personalities a policy was trained with (stored in policy.json)."""
    if isinstance(path_or_obj, str):
        data = load_json(path_or_obj)
    elif isinstance(path_or_obj, dict):
        data = path_or_obj
    else:
        return None
    spec = data.get("action_space")
    if not spec:
        return None
    return build_action_space(spec.get("kind", "named"), spec.get("grid_options"), spec.get("subset"))


def load_policy(path_or_obj: Union[str, Dict, GRMPolicy, OpeningQLearner, None]):
    """Load a GRM policy or Q-learning baseline from a JSON file or dict."""
    if path_or_obj is None or isinstance(path_or_obj, (GRMPolicy, OpeningQLearner)):
        return path_or_obj
    data = load_json(path_or_obj) if isinstance(path_or_obj, str) else path_or_obj
    kind = data.get("kind")
    if kind == "grm":
        return GRMPolicy.from_dict(data)
    if kind == "qlearning":
        return OpeningQLearner.from_dict(data)
    raise ValueError(f"Unknown policy kind '{kind}'")


class GRMStrangeFish(StrangeFish2):

    """StrangeFish2 with belief recording, opponent estimation and personality switching.

    The board-set tracking (expansion, filtering, stored backlog) and the
    sense/move decision logic are inherited unchanged from StrangeFish2; this
    class only decides which hyperparameters those decisions use.
    """

    def __init__(
        self,
        mode: str = "fixed",
        fixed_personality: Optional[Personality] = None,
        action_space: Optional[List[Personality]] = None,
        policy: Union[str, Dict, GRMPolicy, OpeningQLearner, None] = None,
        estimator: Union[str, SkillEstimator, None] = None,
        runtime_config: Optional[RuntimeGRMConfig] = None,
        track_estimates: bool = False,
        forced_opening: Optional[str] = None,
        base_overrides: Optional[Dict[str, Dict]] = None,
        engine_threads: int = 1,
        engine_hash_mb: int = 64,
        quiet: bool = True,
        engine_log: bool = False,
        game_id=None,
        log_to_file: bool = False,
        load_score_cache: bool = False,
        load_opening_book: bool = False,
        rc_disable_pbar: bool = True,
        **strangefish_kwargs,
    ):
        """
        :param mode: one of ``fixed``, ``grm`` or ``opening_q``
        :param fixed_personality: personality for ``fixed`` mode (StrangeFish2 defaults if None)
        :param action_space: personalities the policy may choose from (named set if None)
        :param policy: GRMPolicy for ``grm`` mode or OpeningQLearner for ``opening_q`` mode
        :param estimator: SkillEstimator or checkpoint path; required in ``grm`` mode
        :param runtime_config: switching rules of the run-time GRM
        :param track_estimates: in ``fixed`` mode, still run the estimator and log its output
        :param forced_opening: opening line to play (``fixed`` mode, used by baseline training)
        :param base_overrides: config overrides applied under every personality (e.g. search depth)
        :param engine_threads: Stockfish threads per game (StrangeFish2 itself uses 3)
        :param engine_hash_mb: Stockfish hash size per game (StrangeFish2 itself uses 2048)
        :param quiet: remove the per-game console log handler
        :param engine_log: keep StrangeFish2's verbose engine log file
        """
        if mode not in MODES:
            raise ValueError(f"mode must be one of {MODES}, got '{mode}'")
        self.mode = mode
        self.action_space = action_space or action_space_for_policy(policy) or named_personalities()
        self.personalities = personality_index(self.action_space)
        self.base_overrides = base_overrides or {}
        self.engine_threads = engine_threads
        self.engine_hash_mb = engine_hash_mb

        start = fixed_personality if mode == "fixed" else self.personalities.get("default")
        self.current_personality: Optional[Personality] = start
        sense, move, time_cfg, score = make_configs(start, self.base_overrides)

        super().__init__(
            log_to_file=log_to_file,
            game_id=game_id,
            rc_disable_pbar=rc_disable_pbar,
            load_score_cache=load_score_cache,
            load_opening_book=load_opening_book,
            sense_config=sense,
            move_config=move,
            score_config=score,
            time_config=time_cfg,
            **strangefish_kwargs,
        )
        self._configure_logging(game_id, quiet, engine_log)

        self.policy = load_policy(policy)
        if isinstance(estimator, str):
            estimator = SkillEstimator(estimator)
        self.estimator: Optional[SkillEstimator] = estimator
        self.track_estimates = track_estimates
        self.runtime_config = runtime_config or RuntimeGRMConfig()

        if mode == "grm":
            if not isinstance(self.policy, GRMPolicy):
                raise ValueError("grm mode needs a GRMPolicy (policy=...)")
            if self.estimator is None:
                raise ValueError("grm mode needs an estimator checkpoint (estimator=...)")
            if self.estimator.levels != self.policy.levels:
                raise ValueError(f"Estimator classes {self.estimator.levels} differ from policy states "
                                 f"{self.policy.levels}")
            unknown = [a for a in self.policy.actions if a not in self.personalities]
            if unknown:
                raise ValueError(f"Policy actions missing from the action space: {unknown}")
        if mode == "opening_q":
            if not isinstance(self.policy, OpeningQLearner):
                raise ValueError("opening_q mode needs an OpeningQLearner policy")

        self.forced_opening_name = forced_opening
        self._opening_line: List[chess.Move] = []
        self._opening_pos = 0
        self.opening_followed_plies = 0
        self.opening_deviation_turn: Optional[int] = None

        self.trace = BeliefTrace()
        self.runtime: Optional[RuntimeGRM] = None
        self.estimates: List[Dict] = []
        self.personality_history: List[Dict] = []
        self.summary: Dict = {}

    # ------------------------------------------------------------------
    # Setup
    # ------------------------------------------------------------------
    def _configure_logging(self, game_id, quiet: bool, engine_log: bool) -> None:
        """Drop console output and the verbose engine log when running many games."""
        if quiet:
            game_logger = logging.getLogger(f"game-{game_id}")
            for h in list(game_logger.handlers):
                if isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler):
                    game_logger.removeHandler(h)
            game_logger.propagate = False
        if not engine_log:
            engine_logger = logging.getLogger("chess.engine")
            for h in list(engine_logger.handlers):
                if isinstance(h, logging.FileHandler) and f"game_{game_id}_engine.log" in getattr(h, "baseFilename", ""):
                    engine_logger.removeHandler(h)
                    h.close()
            # python-chess logs (and recovers from) malformed ponder moves at
            # ERROR level; real engine failures still raise exceptions.
            engine_logger.setLevel(logging.CRITICAL)

    def _create_engine(self):
        """Start Stockfish with this bot's thread and hash settings."""
        engine = chess.engine.SimpleEngine.popen_uci(STOCKFISH_EXECUTABLE, setpgrp=True)
        engine.configure({"Hash": self.engine_hash_mb, "Threads": self.engine_threads})
        return engine

    def handle_game_start(self, color: chess.Color, board: chess.Board, opponent_name: str):
        # StrangeFish2 creates its engine with 3 threads and a 2 GB hash, which is
        # far too heavy when many training games run side by side. The engine
        # factory it calls is swapped for one using this bot's settings; games
        # run one per process, so the swap cannot affect another game.
        """Set up a new game: engine, belief trace, run-time GRM and opening line.

        In ``opening_q`` mode the opening and personality are taken from the
        Q-table for our colour before the first move.
        """
        original = sf_strategy.stockfish

        class _EngineFactory:
            """Stand-in for StrangeFish2's stockfish module during engine creation."""

            create_engine = staticmethod(self._create_engine)

        sf_strategy.stockfish = _EngineFactory
        try:
            super().handle_game_start(color, board, opponent_name)
        finally:
            sf_strategy.stockfish = original

        self.trace = BeliefTrace(color=color)
        self.estimates = []
        self.opponent_name = opponent_name

        self.personality_history = [{"turn": 0, "personality": self._personality_name(), "reason": "start"}]
        if self.mode == "grm":
            self.runtime = RuntimeGRM(self.policy, self.runtime_config)
        elif self.mode == "opening_q":
            opening, personality = self.policy.best_for_color(color)
            self.forced_opening_name = opening
            if personality != self._personality_name():
                self._switch_personality(personality, reason="q-table")

        self._opening_line = opening_moves(color, self.forced_opening_name) if self.forced_opening_name else []
        self._opening_pos = 0

    # ------------------------------------------------------------------
    # Personality switching
    # ------------------------------------------------------------------
    def _personality_name(self) -> str:
        """Name of the personality currently in use."""
        return self.current_personality.name if self.current_personality else "default"

    def _switch_personality(self, name: str, reason: str, turn: int = 0) -> None:
        """Replace the active hyperparameters with those of personality ``name``.

        Sense, move and time settings are rebuilt from scratch; score settings
        are patched in place (see the comment below).
        """
        if name not in self.personalities:
            raise ValueError(f"Unknown personality '{name}'")
        p = self.personalities[name]
        sense, move, time_cfg, _ = make_configs(p, self.base_overrides)
        self.sense_config, self.move_config, self.time_config = sense, move, time_cfg
        # Score settings are patched in place so that opponent-specific changes
        # made by StrangeFish2 at game start are kept.
        for section in (self.base_overrides.get("score", {}), p.score):
            for key, value in section.items():
                setattr(self.score_config, key, value)
        self.current_personality = p
        self.personality_history.append({"turn": turn, "personality": name, "reason": reason})
        self.logger.info(f"Personality -> {name} ({reason})")

    def _time_pressure_active(self) -> bool:
        # StrangeFish2 sets time_switch_aggro to -100 once it has run last_ditch_plan.
        """True once StrangeFish2 has switched to its emergency time-pressure plan."""
        return self.time_switch_aggro < 0

    # ------------------------------------------------------------------
    # Observation hooks: record the belief size and run the GRM
    # ------------------------------------------------------------------
    def handle_opponent_move_result(self, captured_my_piece: bool, capture_square: Optional[chess.Square]):
        """Update the board set (StrangeFish2), record its size and run the GRM step."""
        super().handle_opponent_move_result(captured_my_piece, capture_square)
        backlog = 0.0
        if self.stored_old_boards is not None and not self.stored_old_boards.is_empty:
            backlog = float(self.stored_old_boards.expected_size)
        self.trace.start_turn(self.turn_num, len(self.boards), backlog)
        self._estimate_and_act()

    def _estimate_and_act(self) -> None:
        """Run the estimator when due and let the run-time GRM decide on a switch.

        In ``fixed`` mode with ``track_estimates`` the estimate is only logged.
        Any estimator failure is logged and the game continues unchanged.
        """
        turn = self.turn_num
        need = (self.mode == "grm") or (self.track_estimates and self.estimator is not None)
        if not need or self.estimator is None:
            return
        warmup = self.runtime_config.warmup_turns
        if self.mode == "grm":
            if self._time_pressure_active():
                self.runtime.freeze()
            if not self.runtime.wants_estimate(turn):
                return
        elif turn < warmup:
            return
        try:
            est = self.estimator.estimate(self.trace.to_list(), self.color)
        except Exception as exc:  # the game must go on even if inference fails
            self.logger.warning(f"Estimator failed on turn {turn}: {exc}")
            est = None
        if est is not None:
            self.estimates.append({"turn": turn, "level": est["level"], "class_index": est["class_index"],
                                   "margin": est["margin"]})
        if self.mode == "grm":
            switch_to = self.runtime.step(turn, est)
            if switch_to:
                self._switch_personality(switch_to, reason=f"estimated level {est['level']}", turn=turn)

    def handle_sense_result(self, sense_result):
        """Filter the board set by the sense result and record its new size."""
        super().handle_sense_result(sense_result)
        self.trace.record_sense(len(self.boards))

    def handle_move_result(self, requested_move, taken_move, captured_opponent_piece, capture_square):
        """Filter the board set by our move result, record its size, track the opening."""
        super().handle_move_result(requested_move, taken_move, captured_opponent_piece, capture_square)
        self.trace.record_move(len(self.boards))
        if self._opening_line and requested_move is not None and self._opening_pos > 0:
            # Leave the opening line as soon as one of its moves is not executed as requested.
            if taken_move != requested_move:
                self._end_opening(self.turn_num)

    # ------------------------------------------------------------------
    # Forced opening lines (Q-learning baseline)
    # ------------------------------------------------------------------
    def _end_opening(self, turn: int) -> None:
        """Leave the forced opening line, remembering the turn of the first deviation."""
        if self._opening_pos < len(self._opening_line) and self.opening_deviation_turn is None:
            self.opening_deviation_turn = turn
        self._opening_line = []

    def _ensure_board_priorities(self) -> None:
        """Give every current board a sampling priority.

        StrangeFish2 assigns priorities while expanding the board set. Boards
        that never went through an expansion (the starting position on White's
        first turn when no opening book is loaded) have none, and its move
        sampler then fails an internal assertion. Such boards get the lowest
        existing priority.
        """
        tracked = set()
        for boards in self.board_sample_priority.values():
            tracked |= boards
        missing = self.boards - tracked
        if missing:
            lowest = min(self.board_sample_priority.keys(), default=0)
            self.board_sample_priority[lowest] |= missing

    def sense_strategy(self, sense_actions, moves, seconds_left: float):
        """Choose a sense square with StrangeFish2's strategy (after fixing priorities)."""
        self._ensure_board_priorities()
        return super().sense_strategy(sense_actions, moves, seconds_left)

    def move_strategy(self, moves: List[chess.Move], seconds_left: float):
        """Play the next move of the forced opening if possible, else StrangeFish2's move."""
        self._ensure_board_priorities()
        if self._opening_line and self._opening_pos < len(self._opening_line):
            planned = self._opening_line[self._opening_pos]
            if planned in moves:
                self._opening_pos += 1
                self.opening_followed_plies = self._opening_pos
                return planned
            self._end_opening(self.turn_num)
        return super().move_strategy(moves, seconds_left)

    # ------------------------------------------------------------------
    # Game end
    # ------------------------------------------------------------------
    def handle_game_end(self, winner_color, win_reason, game_history):
        """Collect the per-game summary (trace, estimates, switches) and stop the engine."""
        self.summary = {
            "mode": self.mode,
            "color": self.color,
            "opponent_name": getattr(self, "opponent_name", None),
            "turns": self.trace.to_list(),
            "estimates": self.estimates,
            "final_estimate": self.estimates[-1] if self.estimates else None,
            "personality_history": self.personality_history,
            "final_personality": self._personality_name(),
            "runtime_log": self.runtime.log if self.runtime else [],
            "opening": self.forced_opening_name,
            "opening_followed_plies": self.opening_followed_plies,
            "opening_deviation_turn": self.opening_deviation_turn,
            "time_pressure_plan": self._time_pressure_active(),
        }
        try:
            super().handle_game_end(winner_color, win_reason, game_history)
        except chess.engine.EngineTerminatedError:
            pass
