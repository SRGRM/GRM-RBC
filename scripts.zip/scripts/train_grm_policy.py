"""
Learn which personality to play against each opponent class.

algorithm = "grm"        Algorithm 3 of the thesis (bot "uccchess").
    Every episode picks an opponent class s and a personality a, plays a
    batch of games against an opponent of class s, and feeds the game
    outcomes through the batch reward machine. The machine emits the mean
    batch outcome R and Q(s, a) is set to the mean of all R seen for (s, a).
    With state_source = "estimated" the outcome of each game is credited to
    the class the estimator saw at the end of that game, so the table is
    learnt in the same estimated state space that the bot uses when playing.

algorithm = "qlearning"  Algorithm 2 of the thesis (bot "srcork").
    State = (colour, opening), reward = outcome of a single game,
    Q(s, a) <- Q(s, a) + alpha (R - Q(s, a)).

Both write, after every episode, the learner state ("model"), the greedy
policy ("submission") and the game records into one episode folder, plus a
running training report. The final ``policy.json`` is what the bot loads.

CPU only (Stockfish); the estimator, when used, runs on CPU inside each game.

    python scripts/train_grm_policy.py
"""

# =============================================================================
# CONFIG - every option of this script. Alternatives are listed in comments.
# =============================================================================
CONFIG = {
    # ---- algorithm --------------------------------------------------------------
    "algorithm": "grm",                # "grm" (Algorithm 3, batch reward machine) | "qlearning" (Algorithm 2)

    # ---- engine -----------------------------------------------------------------
    "stockfish_path": "/path/to/stockfish",   # "" = use $STOCKFISH_EXECUTABLE

    # ---- action space (personalities) --------------------------------------------
    "action_space": "named",           # "named" (8 interpretable personalities) | "grid" (27 grid points + default)
    "grid_options": None,              # None = default grid | dict of grid_personalities() arguments
    "personality_subset": None,        # None = all | list of names, e.g. ["default", "cautious", "aggressive"]

    # ---- GRM (algorithm = "grm") -----------------------------------------------------
    "levels": list(range(1, 21)),      # opponent classes = Stockfish skill levels (must match the estimator)
    "state_source": "true_level",      # "true_level" = credit the batch to the class played (thesis Algorithm 3)
                                       # "estimated" = credit each game to the estimator's class at game end
    "estimator_checkpoint": "runs/estimator_cuda122_YYYYmmdd_HHMMSS/estimator.pt",  # needed for "estimated"
    "min_group_games": 10,             # "estimated": smallest group of games that yields a batch reward
    "episodes": 320,                   # number of batches (e.g. 160 = one batch per (class, personality) for 20 x 8)
    "games_per_batch": 100,            # thesis: 100
    "state_selection": "cycle",        # "cycle" | "uniform" | "least_visited"
    "action_selection": "ucb1",        # "ucb1" | "epsilon_greedy" | "round_robin"
    "epsilon": 0.1,                    # epsilon_greedy exploration rate
    "ucb_c": 0.5,                      # ucb1 exploration constant (rewards lie in [-1, 1])

    # ---- reward machine (both algorithms) ---------------------------------------------
    "reward": {
        "win": 1.0, "draw": 0.0, "loss": -1.0,   # thesis scoring
        "forfeit_policy": "exclude",             # "exclude" (crashes/timeouts of the harness ignored) | "as_loss"
    },

    # ---- Q-learning baseline (algorithm = "qlearning") ----------------------------------
    "q_rounds": 200,                   # rounds; each round plays games_per_round games in parallel
    "games_per_round": 8,              # e.g. equal to workers
    "q_alpha": 0.1,                    # learning rate in (0, 1]
    "q_epsilon": 0.2,                  # exploration rate
    "opening_selection": "uniform",    # "uniform" | "cycle"
    "q_opponent_levels": list(range(1, 21)),  # opponents are drawn uniformly from these skill levels

    # ---- estimator use inside games -------------------------------------------------------
    "runtime": {                       # fields of RuntimeGRMConfig (also used when tracking estimates)
        "warmup_turns": 6, "estimate_every": 1, "confirm_turns": 2,
        "switch_margin": 0.0, "allow_reswitch": True, "min_estimator_margin": 0.0,
    },

    # ---- opponents and our engine ------------------------------------------------------------
    "opponent": {"move_time": 0.1, "threads": 1, "hash_mb": 16},
    "base_overrides": {"score": {"search_depth": 6}},   # under every personality; tournament depth is 7
    "engine_threads": 1,
    "engine_hash_mb": 64,

    # ---- game rules ------------------------------------------------------------------------------
    "game": {
        "seconds_per_player": 180,     # tournament: 900
        "seconds_increment": 2,        # tournament: 5
        "reversible_moves_limit": 100,
        "full_turn_limit": 150,        # None = no limit
    },

    # ---- execution and output -------------------------------------------------------------------
    "workers": 8,
    "start_method": "spawn",           # "spawn" | "fork"
    "seed": 0,
    "save_game_traces": False,         # True = keep belief traces in games.jsonl (larger files)
    "resume_from": None,               # None | path to a policy_state.json saved by an earlier run
    "output_dir": "runs",
    "run_name": "policy",
}
# =============================================================================

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import random
from collections import Counter, defaultdict

import numpy as np

from grm_rbc.common import (Stopwatch, Tee, append_csv_row, append_jsonl, configure_stockfish, fail, load_json, log,
                            make_run_dir, save_json, set_seed, write_csv)


def game_task(cfg, game_id, color, personality, opponent_level, forced_opening=None, track=False, meta=None):
    """Task dictionary for one training game of our bot (fixed personality)."""
    our_bot = {
        "mode": "fixed",
        "personality": personality,
        "forced_opening": forced_opening,
        "base_overrides": cfg["base_overrides"],
        "engine_threads": cfg["engine_threads"],
        "engine_hash_mb": cfg["engine_hash_mb"],
    }
    if track:
        our_bot.update({"estimator": cfg["estimator_checkpoint"], "track_estimates": True,
                        "runtime_config": cfg["runtime"]})
    return {
        "game_id": game_id,
        "our_color": color,
        "our_bot": our_bot,
        "action_space": {"kind": cfg["action_space"], "grid_options": cfg["grid_options"],
                         "subset": cfg["personality_subset"]},
        "opponent": {"type": "skill_trout", "level": opponent_level},
        "opponent_defaults": cfg["opponent"],
        "game": cfg["game"],
        "meta": meta or {},
    }


def space_spec(cfg):
    """Stored with the policy so the bot can rebuild the same personalities."""
    return {"kind": cfg["action_space"], "grid_options": cfg["grid_options"], "subset": cfg["personality_subset"]}


def compact(res, keep_traces):
    """Game record without the large fields, for the per-episode reports."""
    out = {k: v for k, v in res.items() if k not in ("turns", "traceback", "runtime_log")}
    if keep_traces:
        out["turns"] = res.get("turns")
    return out


def outcome_counts(results):
    """Counts of wins, draws, losses and errors in a list of results."""
    c = Counter("error" if r.get("error") else r.get("outcome") for r in results)
    return c.get(1, 0), c.get(0, 0), c.get(-1, 0), c.get("error", 0)


# ---------------------------------------------------------------------------
# Algorithm 3: GRM
# ---------------------------------------------------------------------------

def train_grm(cfg, run_dir, actions, run_games):
    """Algorithm 3: batch-reward GRM training over (opponent class, personality)."""
    from grm_rbc.grm import BatchRewardMachine, GRMPolicy, LabellingFunction

    rng = random.Random(cfg["seed"])
    levels = list(cfg["levels"])
    track = cfg["state_source"] == "estimated"
    if cfg["state_source"] not in ("true_level", "estimated"):
        fail(f"Unknown state_source '{cfg['state_source']}'")
    if track:
        from grm_rbc.estimator import load_checkpoint
        path = cfg["estimator_checkpoint"]
        if not os.path.isfile(path):
            fail(f"Estimator checkpoint not found: {path}")
        try:
            est_levels = list(load_checkpoint(path)["levels"])
        except Exception as exc:
            fail(f"Could not load estimator checkpoint {path}: {exc}")
        if est_levels != levels:
            fail(f"Estimator classes {est_levels} differ from CONFIG['levels'] {levels}")
        log(f"Estimator loaded: {path} ({len(est_levels)} classes)")

    if cfg["resume_from"]:
        if not os.path.isfile(cfg["resume_from"]):
            fail(f"resume_from not found: {cfg['resume_from']}")
        state = load_json(cfg["resume_from"])
        policy = GRMPolicy.from_dict(state)
        if policy.levels != levels or policy.actions != actions:
            fail("Saved policy does not match the configured levels/personalities.")
        start_episode = int(state.get("episode", 0))
        log(f"Resumed from {cfg['resume_from']} at episode {start_episode}")
    else:
        policy = GRMPolicy(levels, actions, default_action="default")
        start_episode = 0

    machine = BatchRewardMachine(batch_size=cfg["games_per_batch"], win_score=cfg["reward"]["win"],
                                 draw_score=cfg["reward"]["draw"], loss_score=cfg["reward"]["loss"],
                                 forfeit_policy=cfg["reward"]["forfeit_policy"])
    labeller = LabellingFunction()
    report_csv = os.path.join(run_dir, "training_report.csv")
    games_path = os.path.join(run_dir, "games.jsonl")
    clock = Stopwatch()

    for episode in range(start_episode, cfg["episodes"]):
        s = policy.select_state(cfg["state_selection"], rng, episode)
        a = policy.select_action(s, cfg["action_selection"], rng, cfg["epsilon"], cfg["ucb_c"])
        level, personality = levels[s], actions[a]
        log(f"Episode {episode + 1}/{cfg['episodes']}: opponent level {level}, personality '{personality}', "
            f"{cfg['games_per_batch']} games")

        tasks = [
            game_task(cfg, f"ep{episode + 1:04d}_g{g:03d}", "white" if g % 2 == 0 else "black", personality,
                      level, track=track, meta={"episode": episode + 1, "level": level, "personality": personality})
            for g in range(cfg["games_per_batch"])
        ]
        results = run_games(tasks, workers=cfg["workers"], start_method=cfg["start_method"], label="game")

        # ---- reward machine and Q update ----------------------------------------------
        credited = []
        if not track:
            r_batch = machine.run([labeller.label_game(r) for r in results])
            q_new = policy.update(s, a, r_batch)
            credited.append({"level": level, "games": len(results), "batch_reward": r_batch, "q": q_new})
        else:
            groups = defaultdict(list)
            for r in results:
                fe = r.get("final_estimate")
                if fe is not None and not r.get("error"):
                    groups[int(fe["class_index"])].append(r)
            for est_s, group in sorted(groups.items()):
                if len(group) < cfg["min_group_games"]:
                    continue
                r_batch = machine.run([labeller.label_game(r) for r in group])
                q_new = policy.update(est_s, a, r_batch)
                credited.append({"level": levels[est_s], "games": len(group), "batch_reward": r_batch, "q": q_new})

        est_hits = [r["final_estimate"]["level"] == level for r in results if r.get("final_estimate")]
        wins, draws, losses, errors = outcome_counts(results)

        # ---- save episode: learner state (model) + greedy policy (submission) ----------
        ep_dir = os.path.join(run_dir, f"episode_{episode + 1:04d}")
        os.makedirs(ep_dir, exist_ok=True)
        state = policy.to_dict()
        state["episode"] = episode + 1
        state["action_space"] = space_spec(cfg)
        save_json(state, os.path.join(ep_dir, "policy_state.json"))
        save_json(policy.greedy_policy(), os.path.join(ep_dir, "greedy_policy.json"))
        write_csv(policy.table_rows(), os.path.join(ep_dir, "q_table.csv"))
        write_csv([compact(r, False) for r in results], os.path.join(ep_dir, "games.csv"))
        append_jsonl([compact(r, cfg["save_game_traces"]) for r in results], games_path)
        save_json(state, os.path.join(run_dir, "policy.json"))

        main_credit = credited[0] if credited else {"batch_reward": float("nan"), "q": float("nan")}
        row = {
            "episode": episode + 1, "level": level, "personality": personality,
            "games": len(results), "wins": wins, "draws": draws, "losses": losses, "errors": errors,
            "batch_reward": main_credit["batch_reward"], "q_after": main_credit["q"],
            "credited": ";".join(f"L{c['level']}:{c['games']}g:{c['batch_reward']:.3f}" for c in credited),
            "visits_pair": int(policy.n[s, a]),
            "estimator_acc": float(np.mean(est_hits)) if est_hits else "",
            "elapsed": clock.fmt(),
        }
        append_csv_row(row, report_csv)
        credit_txt = (f"Q({level}, {personality}) = {row['q_after']:.3f}" if not track
                      else f"credited to estimated classes [{row['credited'] or 'none'}]")
        log(f"  -> W/D/L/E {wins}/{draws}/{losses}/{errors}  batch reward {row['batch_reward']:.3f}  {credit_txt}  "
            f"{'estimator acc ' + format(row['estimator_acc'], '.2f') if est_hits else ''}  [{clock.fmt()}]")
        log(f"  greedy policy: {policy.greedy_policy()}")
    return policy


# ---------------------------------------------------------------------------
# Algorithm 2: Q-learning baseline
# ---------------------------------------------------------------------------

def train_qlearning(cfg, run_dir, actions, run_games):
    """Algorithm 2: single-game Q-learning over (colour, opening) states."""
    import chess
    from grm_rbc.baseline import OpeningQLearner
    from grm_rbc.grm import LabellingFunction, BatchRewardMachine

    rng = random.Random(cfg["seed"])
    if cfg["resume_from"]:
        if not os.path.isfile(cfg["resume_from"]):
            fail(f"resume_from not found: {cfg['resume_from']}")
        state = load_json(cfg["resume_from"])
        learner = OpeningQLearner.from_dict(state)
        if learner.actions != actions:
            fail("Saved Q-table does not match the configured personalities.")
        start_round = int(state.get("round", 0))
    else:
        learner = OpeningQLearner(actions, alpha=cfg["q_alpha"], default_action="default")
        start_round = 0

    labeller = LabellingFunction()
    scorer = BatchRewardMachine(batch_size=1, win_score=cfg["reward"]["win"], draw_score=cfg["reward"]["draw"],
                                loss_score=cfg["reward"]["loss"], forfeit_policy=cfg["reward"]["forfeit_policy"])
    report_csv = os.path.join(run_dir, "training_report.csv")
    games_path = os.path.join(run_dir, "games.jsonl")
    clock = Stopwatch()
    game_counter = start_round * cfg["games_per_round"]

    for rnd in range(start_round, cfg["q_rounds"]):
        tasks, chosen = [], {}
        for g in range(cfg["games_per_round"]):
            color_name = "white" if (game_counter + g) % 2 == 0 else "black"
            color = chess.WHITE if color_name == "white" else chess.BLACK
            opening = learner.choose_opening(color, cfg["opening_selection"], rng, game_counter + g)
            s = learner.s_index(color, opening)
            a = learner.choose_action(s, rng, cfg["q_epsilon"])
            level = rng.choice(cfg["q_opponent_levels"])
            gid = f"r{rnd + 1:04d}_g{g:03d}"
            chosen[gid] = (s, a)
            tasks.append(game_task(cfg, gid, color_name, actions[a], level,
                                   forced_opening=None if opening == "other" else opening,
                                   meta={"round": rnd + 1, "state": learner.states[s], "personality": actions[a],
                                         "level": level}))
        game_counter += cfg["games_per_round"]
        log(f"Round {rnd + 1}/{cfg['q_rounds']}: {len(tasks)} games")
        results = run_games(tasks, workers=cfg["workers"], start_method=cfg["start_method"], label="game")

        updates = []
        for r in results:
            s, a = chosen[r["game_id"]]
            reward = scorer.run([labeller.label_game(r)])
            if np.isnan(reward):
                continue
            q = learner.update(s, a, reward)
            updates.append((learner.states[s], actions[a], reward, q))

        rd_dir = os.path.join(run_dir, f"round_{rnd + 1:04d}")
        os.makedirs(rd_dir, exist_ok=True)
        state = learner.to_dict()
        state["round"] = rnd + 1
        state["action_space"] = space_spec(cfg)
        save_json(state, os.path.join(rd_dir, "policy_state.json"))
        save_json(state["greedy_policy"], os.path.join(rd_dir, "greedy_policy.json"))
        write_csv(learner.table_rows(), os.path.join(rd_dir, "q_table.csv"))
        write_csv([compact(r, False) for r in results], os.path.join(rd_dir, "games.csv"))
        append_jsonl([compact(r, cfg["save_game_traces"]) for r in results], games_path)
        save_json(state, os.path.join(run_dir, "policy.json"))

        wins, draws, losses, errors = outcome_counts(results)
        row = {"round": rnd + 1, "games": len(results), "wins": wins, "draws": draws, "losses": losses,
               "errors": errors, "mean_reward": float(np.mean([u[2] for u in updates])) if updates else "",
               "updates": len(updates), "greedy_white": str(state["greedy_policy"]["white"]),
               "greedy_black": str(state["greedy_policy"]["black"]), "elapsed": clock.fmt()}
        append_csv_row(row, report_csv)
        log(f"  -> W/D/L/E {wins}/{draws}/{losses}/{errors}  greedy white {state['greedy_policy']['white']}  "
            f"black {state['greedy_policy']['black']}  [{clock.fmt()}]")
    return learner


def main():
    """Build the action space and run the selected training algorithm."""
    cfg = CONFIG
    configure_stockfish(cfg["stockfish_path"])
    from grm_rbc.game_runner import run_games
    from grm_rbc.personalities import build_action_space

    run_dir = make_run_dir(cfg["output_dir"], f"{cfg['run_name']}_{cfg['algorithm']}")
    sys.stdout = Tee(os.path.join(run_dir, "log.txt"))
    save_json(cfg, os.path.join(run_dir, "config.json"))
    set_seed(cfg["seed"])
    log(f"Run folder: {run_dir}")

    try:
        space = build_action_space(cfg["action_space"], cfg["grid_options"], cfg["personality_subset"])
    except ValueError as exc:
        fail(str(exc))
    actions = [p.name for p in space]
    if "default" not in actions:
        fail("The action space must contain the 'default' personality (played before the opponent is estimated).")
    save_json([p.to_dict() for p in space], os.path.join(run_dir, "action_space.json"))
    log(f"Algorithm: {cfg['algorithm']}  |  {len(actions)} personalities: {actions}")

    if cfg["algorithm"] == "grm":
        train_grm(cfg, run_dir, actions, run_games)
    elif cfg["algorithm"] == "qlearning":
        train_qlearning(cfg, run_dir, actions, run_games)
    else:
        fail(f"Unknown algorithm '{cfg['algorithm']}'")
    log(f"Finished. Policy for the bot: {os.path.join(run_dir, 'policy.json')}")


if __name__ == "__main__":
    main()
