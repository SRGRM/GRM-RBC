"""
Play on the public RBC server (https://rbc.jhuapl.edu) with the GRM bot.

Credentials are read from the environment variables RBC_USERNAME and
RBC_PASSWORD when the CONFIG fields are empty, so they do not have to be
stored in the repository.

    export RBC_USERNAME=... RBC_PASSWORD=...
    python scripts/connect_server.py
"""

# =============================================================================
# CONFIG - every option of this script. Alternatives are listed in comments.
# =============================================================================
CONFIG = {
    "stockfish_path": "/path/to/stockfish",   # "" = use $STOCKFISH_EXECUTABLE
    "server_url": "https://rbc.jhuapl.edu",
    "username": "",                    # "" = read $RBC_USERNAME
    "password": "",                    # "" = read $RBC_PASSWORD
    "ranked": False,                   # True = play for leaderboard Elo | False = unranked games only
    "max_concurrent_games": 1,         # games played at the same time (each uses its own process)
    "limit_games": None,               # None = run until interrupted | int = stop after this many games

    "bot": {
        "mode": "grm",                 # "grm" | "fixed" | "opening_q"
        "policy": "runs/policy_grm_YYYYmmdd_HHMMSS/policy.json",
        "estimator": "runs/estimator_cuda122_YYYYmmdd_HHMMSS/estimator.pt",
        "personality": "default",      # "fixed" mode only
    },
    "action_space": "named",           # used when the policy file does not define it
    "runtime": {"warmup_turns": 6, "estimate_every": 1, "confirm_turns": 2,
                "switch_margin": 0.0, "allow_reswitch": True, "min_estimator_margin": 0.0},
    "engine_threads": 3,               # StrangeFish2 tournament setting
    "engine_hash_mb": 2048,            # StrangeFish2 tournament setting
    "log_to_file": True,               # per-game log files under game_logs/
}
# =============================================================================

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import functools
import logging

from grm_rbc.common import configure_stockfish, fail, load_json


def make_bot(game_id, settings):
    """Top-level factory so it can be passed to worker processes."""
    from grm_rbc.grm import RuntimeGRMConfig
    from grm_rbc.grm_bot import GRMStrangeFish
    from grm_rbc.personalities import build_action_space, personality_index

    bot = settings["bot"]
    space_spec = settings["space"]
    space = build_action_space(space_spec.get("kind", "named"), space_spec.get("grid_options"),
                               space_spec.get("subset"))
    kwargs = dict(
        mode=bot["mode"],
        action_space=space,
        runtime_config=RuntimeGRMConfig(**settings["runtime"]),
        engine_threads=settings["engine_threads"],
        engine_hash_mb=settings["engine_hash_mb"],
        game_id=game_id,
        log_to_file=settings["log_to_file"],
        quiet=False,
        rc_disable_pbar=True,
    )
    if bot["mode"] in ("grm", "opening_q"):
        kwargs["policy"] = bot["policy"]
    if bot["mode"] == "grm":
        kwargs["estimator"] = bot["estimator"]
    if bot["mode"] == "fixed":
        kwargs["fixed_personality"] = personality_index(space)[bot["personality"]]
    return GRMStrangeFish(**kwargs)


def main():
    """Check the configuration, then accept server invitations until stopped."""
    cfg = CONFIG
    configure_stockfish(cfg["stockfish_path"])
    from grm_rbc.remote import listen_for_invitations

    username = cfg["username"] or os.environ.get("RBC_USERNAME", "")
    password = cfg["password"] or os.environ.get("RBC_PASSWORD", "")
    if not username or not password:
        fail("Server credentials missing: fill CONFIG or set RBC_USERNAME / RBC_PASSWORD.")

    bot = cfg["bot"]
    space = {"kind": cfg["action_space"], "grid_options": None, "subset": None}
    for key in ("policy", "estimator"):
        needed = (key == "policy" and bot["mode"] in ("grm", "opening_q")) or (key == "estimator" and bot["mode"] == "grm")
        if needed and not os.path.isfile(bot.get(key) or ""):
            fail(f"{key} file not found: {bot.get(key)}")
    if bot["mode"] in ("grm", "opening_q"):
        space = load_json(bot["policy"]).get("action_space", space)

    # Fail now, not inside the first game, if anything is misconfigured.
    make_bot("config-check", {"bot": bot, "space": space, "runtime": cfg["runtime"],
                              "engine_threads": 1, "engine_hash_mb": 16, "log_to_file": False})

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    settings = {"bot": bot, "space": space, "runtime": cfg["runtime"], "engine_threads": cfg["engine_threads"],
                "engine_hash_mb": cfg["engine_hash_mb"], "log_to_file": cfg["log_to_file"]}
    listen_for_invitations(
        cfg["server_url"], (username, password), functools.partial(make_bot, settings=settings),
        max_concurrent_games=cfg["max_concurrent_games"], ranked=cfg["ranked"], limit_games=cfg["limit_games"],
    )


if __name__ == "__main__":
    main()
