"""
Play one local game and show what the GRM did during it.

Useful for checking a trained policy and estimator before a long evaluation
or before connecting to the server. Optionally opens the reconchess replay
window at the end (needs pygame and a display).

    python scripts/play_local.py
"""

# =============================================================================
# CONFIG - every option of this script. Alternatives are listed in comments.
# =============================================================================
CONFIG = {
    "stockfish_path": "/path/to/stockfish",   # "" = use $STOCKFISH_EXECUTABLE

    "bot": {
        "mode": "grm",                 # "grm" | "fixed" | "opening_q"
        "policy": "runs/policy_grm_YYYYmmdd_HHMMSS/policy.json",           # "grm" and "opening_q"
        "estimator": "runs/estimator_cuda122_YYYYmmdd_HHMMSS/estimator.pt",  # "grm" (optional for "fixed")
        "personality": "default",      # "fixed" mode only
        "track_estimates": True,       # "fixed" mode: still log estimator output if an estimator is given
    },
    "action_space": "named",           # used when the policy file does not define it: "named" | "grid"
    "runtime": {"warmup_turns": 6, "estimate_every": 1, "confirm_turns": 2,
                "switch_margin": 0.0, "allow_reswitch": True, "min_estimator_margin": 0.0},
    "opponent": {"type": "skill_trout", "level": 8},   # or {"type": "trout"} | {"type": "random"} | ...
    "opponent_defaults": {"move_time": 0.1, "threads": 1, "hash_mb": 16},
    "our_color": "white",              # "white" | "black"
    "base_overrides": {},              # e.g. {"score": {"search_depth": 6}} for a faster game
    "engine_threads": 2,
    "engine_hash_mb": 256,
    "game": {"seconds_per_player": 900, "seconds_increment": 5, "reversible_moves_limit": 100,
             "full_turn_limit": None},
    "history_file": "local_game_history.json",   # reconchess game history (open later with rc-replay)
    "show_replay": False,              # True = open the reconchess replay window afterwards (pygame + display)
    "seed": 0,
}
# =============================================================================

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from grm_rbc.common import configure_stockfish, fail, load_json, log, set_seed


def main():
    """Play one game and print the belief sizes and every GRM decision."""
    cfg = CONFIG
    configure_stockfish(cfg["stockfish_path"])
    set_seed(cfg["seed"])
    from grm_rbc.game_runner import run_game

    bot = dict(cfg["bot"])
    mode = bot["mode"]
    our = {"mode": mode, "base_overrides": cfg["base_overrides"], "engine_threads": cfg["engine_threads"],
           "engine_hash_mb": cfg["engine_hash_mb"], "runtime_config": cfg["runtime"]}
    space = {"kind": cfg["action_space"], "grid_options": None, "subset": None}
    if mode in ("grm", "opening_q"):
        if not os.path.isfile(bot["policy"]):
            fail(f"Policy file not found: {bot['policy']}")
        our["policy"] = bot["policy"]
        space = load_json(bot["policy"]).get("action_space", space)
    if mode == "grm" or (mode == "fixed" and bot.get("track_estimates") and bot.get("estimator")):
        if not os.path.isfile(bot["estimator"]):
            fail(f"Estimator checkpoint not found: {bot['estimator']}")
        our["estimator"] = bot["estimator"]
        our["track_estimates"] = mode == "fixed"
    if mode == "fixed":
        our["personality"] = bot["personality"]

    task = {"game_id": "local", "our_color": cfg["our_color"], "our_bot": our, "action_space": space,
            "opponent": cfg["opponent"], "opponent_defaults": cfg["opponent_defaults"], "game": cfg["game"],
            "meta": {}, "save_history_path": cfg["history_file"]}
    log(f"Playing {mode} bot as {cfg['our_color']} against {cfg['opponent']}")
    res = run_game(task)
    if res.get("error"):
        print(res.get("traceback", ""))
        fail(f"Game failed: {res['error']}")

    result_word = {1: "won", 0: "drew", -1: "lost"}[res["outcome"]]
    log(f"Our bot {result_word} ({res['win_reason']}) after {res['n_turns']} turns in {res['duration_sec']:.0f}s")
    log("Belief-state size per turn (start / after sense / after move):")
    for t in res["turns"]:
        log(f"  turn {t['turn']:3d}: {t['start']:>8.0f} / {t['after_sense'] or 0:>8.0f} / "
            f"{t['after_move'] or 0:>8.0f}   stored {t['backlog']:.0f}")
    if res.get("runtime_log"):
        log("GRM decisions:")
        for e in res["runtime_log"]:
            r = "-" if e["generated_reward"] is None else f"{e['generated_reward']:.3f}"
            log(f"  turn {e['turn']:3d}: state {e['state']:<10s} estimated level {e['estimated_level']}  "
                f"symbols {e['symbols']}  reward {r}  personality {e['personality']}"
                f"{'  <- switched' if e['switched'] else ''}")
    elif res.get("estimates"):
        log("Estimator output:")
        for e in res["estimates"]:
            log(f"  turn {e['turn']:3d}: level {e['level']}  margin {e['margin']:.5f}")
    log(f"Personality history: {res['personality_history']}")

    log(f"Game history saved to {cfg['history_file']}")

    if cfg["show_replay"]:
        from reconchess import GameHistory
        from reconchess.scripts.rc_replay import ReplayWindow
        window = ReplayWindow(GameHistory.from_file(cfg["history_file"]))
        while True:  # the window exits the program when it is closed
            window.update()
            window.draw()


if __name__ == "__main__":
    main()
