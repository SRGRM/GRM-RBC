"""
Check that the environment can run every part of the repository.

Reports the Python and package versions, whether PyTorch sees the GPUs
(and which training script fits this PyTorch), whether Stockfish starts and
answers, and whether the bot and the tournament configuration load.
Exits with status 1 if anything required is missing.

    python scripts/check_installation.py
    python scripts/check_installation.py --stockfish /path/to/stockfish
"""

import argparse
import importlib
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

PACKAGES = ("reconchess", "chess", "numpy", "tqdm", "requests", "click", "torch")


class Checker:
    """Collects check results and prints them as aligned OK / FAIL lines."""

    def __init__(self):
        """Start with no failures."""
        self.failures = 0

    def ok(self, label: str, detail: str = "") -> None:
        """Report a passed check."""
        print(f"  [ OK ] {label:<28s} {detail}")

    def fail(self, label: str, detail: str = "") -> None:
        """Report a failed check and remember it for the exit status."""
        self.failures += 1
        print(f"  [FAIL] {label:<28s} {detail}")

    def note(self, label: str, detail: str = "") -> None:
        """Report information that is neither a pass nor a failure."""
        print(f"  [INFO] {label:<28s} {detail}")


def check_python(c: Checker) -> None:
    """Python 3.8 or newer is required."""
    v = sys.version_info
    text = f"{v.major}.{v.minor}.{v.micro}"
    (c.ok if v >= (3, 8) else c.fail)("Python", text)


def check_packages(c: Checker) -> None:
    """Every runtime dependency must import."""
    from importlib import metadata
    for name in PACKAGES:
        try:
            importlib.import_module(name)
            try:
                version = metadata.version(name)
            except metadata.PackageNotFoundError:
                version = ""
            c.ok(name, version)
        except Exception as exc:
            c.fail(name, f"not importable ({exc})")


def check_torch(c: Checker) -> None:
    """Report CUDA availability and the matching estimator training script."""
    try:
        import torch
    except ImportError:
        return
    major_minor = tuple(int(x) for x in torch.__version__.split("+")[0].split(".")[:2])
    script = "train_estimator_cuda114.py" if major_minor < (1, 10) else "train_estimator_cuda122.py"
    if major_minor < (1, 8):
        c.fail("PyTorch version", f"{torch.__version__} (1.8 or newer required)")
    else:
        c.ok("PyTorch version", f"{torch.__version__} -> use scripts/{script}")
    if torch.cuda.is_available():
        names = [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
        c.ok("CUDA", f"{torch.version.cuda}, {len(names)} GPU(s): {', '.join(names)}")
    else:
        c.note("CUDA", "not available (CPU training only)")


def check_stockfish(c: Checker, path: str) -> bool:
    """Start Stockfish through python-chess and confirm it accepts the Skill Level option."""
    path = path or os.environ.get("STOCKFISH_EXECUTABLE", "")
    if not path:
        c.fail("Stockfish", "STOCKFISH_EXECUTABLE is not set (see scripts/install_stockfish.sh)")
        return False
    if not os.path.isfile(path):
        c.fail("Stockfish", f"no file at {path}")
        return False
    try:
        import chess.engine
        engine = chess.engine.SimpleEngine.popen_uci(path)
        name = engine.id.get("name", "unknown")
        has_skill = "Skill Level" in engine.options
        engine.quit()
    except Exception as exc:
        c.fail("Stockfish", f"failed to start ({exc})")
        return False
    c.ok("Stockfish", f"{name} at {path}")
    (c.ok if has_skill else c.fail)("Stockfish Skill Level", "available" if has_skill else "missing (opponents need it)")
    os.environ["STOCKFISH_EXECUTABLE"] = os.path.abspath(path)
    return True


def check_bot(c: Checker) -> None:
    """Import StrangeFish2 and the GRM bot, and load the uccchess tournament configuration."""
    try:
        importlib.import_module("grm_rbc.grm_bot")
        c.ok("StrangeFish2 + GRM bot", "import ok")
    except Exception as exc:
        c.fail("StrangeFish2 + GRM bot", f"import failed ({exc})")
        return
    try:
        from uccchess.uccchess_bot import DEFAULT_CONFIG_PATH, load_tournament_config
        cfg = load_tournament_config(DEFAULT_CONFIG_PATH)
        mode = "GRM with estimator" if cfg["estimator"] else "default personality (no estimator yet)"
        c.ok("uccchess configuration", f"{len(cfg['levels'])} classes, {mode}")
    except Exception as exc:
        c.fail("uccchess configuration", str(exc))


def main() -> None:
    """Run all checks and exit with 1 if any required check failed."""
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--stockfish", default="", help="Stockfish binary (default: $STOCKFISH_EXECUTABLE)")
    args = parser.parse_args()

    c = Checker()
    print("Checking the GRM-RBC environment\n")
    check_python(c)
    check_packages(c)
    check_torch(c)
    if check_stockfish(c, args.stockfish):
        check_bot(c)
    print()
    if c.failures:
        print(f"{c.failures} check(s) failed. See INSTALL.md.")
        sys.exit(1)
    print("All checks passed.")


if __name__ == "__main__":
    main()
