"""
Evaluate trained bots against a set of opponents.

Typical use: compare the GRM bot, the plain StrangeFish2 settings and the
Q-learning baseline on the same opponents. For skill-level opponents the
report also gives the estimator's accuracy at the end of each game.

    python scripts/evaluate.py
"""

# =============================================================================
# CONFIG - every option of this script. Alternatives are listed in comments.
# =============================================================================
CONFIG = {
    "stockfish_path": "/path/to/stockfish",   # "" = use $STOCKFISH_EXECUTABLE

    # ---- bots under test ---------------------------------------------------------
    # mode "grm"       needs "policy" (GRM policy.json) and "estimator" (estimator.pt)
    # mode "fixed"     needs "personality" (name in "action_space")
    # mode "opening_q" needs "policy" (Q-learning policy.json)
    "bots": [
        {"name": "grm", "mode": "grm",
         "policy": "runs/policy_grm_YYYYmmdd_HHMMSS/policy.json",
         "estimator": "runs/estimator_cuda122_YYYYmmdd_HHMMSS/estimator.pt"},
        {"name": "strangefish2", "mode": "fixed", "personality": "default"},
        {"name": "qlearning", "mode": "opening_q",
         "policy": "runs/policy_qlearning_YYYYmmdd_HHMMSS/policy.json"},
    ],
    "action_space": "named",           # used by "fixed" bots: "named" | "grid" (policy bots use their own)
    "grid_options": None,

    # ---- opponents ---------------------------------------------------------------------
    "opponents": [                     # any of: skill_trout (with level), trout, random, attacker, strangefish2
        {"type": "skill_trout", "level": 1},
        {"type": "skill_trout", "level": 5},
        {"type": "skill_trout", "level": 10},
        {"type": "skill_trout", "level": 15},
        {"type": "skill_trout", "level": 20},
        {"type": "trout"},
        {"type": "attacker"},
        {"type": "random"},
    ],
    "games_per_opponent": 40,          # per bot and opponent; colours alternate
    "opponent": {"move_time": 0.1, "threads": 1, "hash_mb": 16},

    # ---- GRM run-time behaviour ------------------------------------------------------------
    "runtime": {
        "warmup_turns": 6,             # turns with the default personality before the first estimate
        "estimate_every": 1,           # estimator period in turns
        "confirm_turns": 2,            # identical consecutive estimates before switching
        "switch_margin": 0.0,          # minimum Q improvement required to switch
        "allow_reswitch": True,        # True = may change personality again | False = commit once
        "min_estimator_margin": 0.0,   # ignore estimates with a smaller best/second-best error gap
    },
    "track_estimates_for_fixed": False,   # True = also log estimator output for fixed bots (needs "estimator")

    # ---- our engine and game rules ---------------------------------------------------------
    "base_overrides": {},              # {} = tournament settings | e.g. {"score": {"search_depth": 6}}
    "engine_threads": 1,
    "engine_hash_mb": 64,
    "game": {
        "seconds_per_player": 900,     # tournament settings
        "seconds_increment": 5,
        "reversible_moves_limit": 100,
        "full_turn_limit": None,
    },

    # ---- execution and output ------------------------------------------------------------------
    "workers": 8,
    "start_method": "spawn",           # "spawn" | "fork"
    "seed": 0,
    "output_dir": "runs",
    "run_name": "evaluation",
}
# =============================================================================

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from collections import Counter, defaultdict

import numpy as np

from grm_rbc.common import (Stopwatch, Tee, append_jsonl, configure_stockfish, fail, load_json, log, make_run_dir,
                            save_json, set_seed, write_csv)


def check_bot(bot):
    """Stop with a clear message if a bot entry is incomplete or a file is missing."""
    for key in ("name", "mode"):
        if key not in bot:
            fail(f"Bot entry {bot} has no '{key}'")
    needs = {"grm": ("policy", "estimator"), "opening_q": ("policy",), "fixed": ("personality",)}
    if bot["mode"] not in needs:
        fail(f"Bot '{bot['name']}': unknown mode '{bot['mode']}'")
    for key in needs[bot["mode"]]:
        if not bot.get(key):
            fail(f"Bot '{bot['name']}' (mode {bot['mode']}) needs '{key}'")
    for key in ("policy", "estimator"):
        if bot.get(key) and not os.path.isfile(bot[key]):
            fail(f"Bot '{bot['name']}': file not found for '{key}': {bot[key]}")


def bot_task_fields(cfg, bot):
    """Translate a bot entry into ``our_bot`` task fields and its action space."""
    our = {
        "mode": bot["mode"],
        "base_overrides": cfg["base_overrides"],
        "engine_threads": cfg["engine_threads"],
        "engine_hash_mb": cfg["engine_hash_mb"],
        "runtime_config": cfg["runtime"],
    }
    space = {"kind": cfg["action_space"], "grid_options": cfg["grid_options"], "subset": None}
    if bot["mode"] == "fixed":
        our["personality"] = bot["personality"]
        if cfg["track_estimates_for_fixed"] and bot.get("estimator"):
            our.update({"estimator": bot["estimator"], "track_estimates": True})
    else:
        policy = load_json(bot["policy"])
        if "action_space" in policy:
            space = policy["action_space"]
        our["policy"] = bot["policy"]
        if bot["mode"] == "grm":
            our["estimator"] = bot["estimator"]
    return our, space


def summarise(results):
    """Aggregate results per (bot, opponent): outcomes, score, estimator accuracy."""
    rows = []
    groups = defaultdict(list)
    for r in results:
        groups[(r["meta"]["bot"], r["opponent"])].append(r)
    for (bot, opp), rs in sorted(groups.items()):
        ok = [r for r in rs if not r.get("error")]
        c = Counter(r["outcome"] for r in ok)
        n = len(ok)
        level = rs[0]["opponent_spec"].get("level")
        finals = [r["final_estimate"]["level"] for r in ok if r.get("final_estimate")]
        switches = [next((h["turn"] for h in r.get("personality_history", [])[1:]), None) for r in ok]
        switches = [s for s in switches if s is not None]
        row = {
            "bot": bot, "opponent": opp, "games": len(rs), "errors": len(rs) - n,
            "wins": c.get(1, 0), "draws": c.get(0, 0), "losses": c.get(-1, 0),
            "score": round((c.get(1, 0) - c.get(-1, 0)) / n, 4) if n else "",
            "win_rate": round(c.get(1, 0) / n, 4) if n else "",
            "mean_turns": round(float(np.mean([r.get("n_turns", 0) for r in ok])), 1) if ok else "",
            "estimator_exact": "", "estimator_within1": "",
            "mean_first_switch_turn": round(float(np.mean(switches)), 1) if switches else "",
            "final_personalities": dict(Counter(r.get("final_personality") for r in ok)),
        }
        if level is not None and finals:
            row["estimator_exact"] = round(float(np.mean([f == level for f in finals])), 4)
            row["estimator_within1"] = round(float(np.mean([abs(f - level) <= 1 for f in finals])), 4)
        rows.append(row)
    return rows


def main():
    """Build all games, play them in parallel and write the result tables."""
    cfg = CONFIG
    configure_stockfish(cfg["stockfish_path"])
    from grm_rbc.game_runner import run_games
    from grm_rbc.opponents import opponent_label

    run_dir = make_run_dir(cfg["output_dir"], cfg["run_name"])
    sys.stdout = Tee(os.path.join(run_dir, "log.txt"))
    save_json(cfg, os.path.join(run_dir, "config.json"))
    set_seed(cfg["seed"])
    clock = Stopwatch()
    log(f"Run folder: {run_dir}")

    for bot in cfg["bots"]:
        check_bot(bot)
    tasks = []
    for bot in cfg["bots"]:
        our, space = bot_task_fields(cfg, bot)
        for opp in cfg["opponents"]:
            for g in range(cfg["games_per_opponent"]):
                tasks.append({
                    "game_id": f"{bot['name']}_{opponent_label(opp)}_g{g:03d}",
                    "our_color": "white" if g % 2 == 0 else "black",
                    "our_bot": dict(our),
                    "action_space": space,
                    "opponent": opp,
                    "opponent_defaults": cfg["opponent"],
                    "game": cfg["game"],
                    "meta": {"bot": bot["name"]},
                })
    log(f"{len(tasks)} games ({len(cfg['bots'])} bots x {len(cfg['opponents'])} opponents x "
        f"{cfg['games_per_opponent']}) on {cfg['workers']} workers")

    results_path = os.path.join(run_dir, "results.jsonl")
    results = run_games(tasks, workers=cfg["workers"], start_method=cfg["start_method"],
                        on_result=lambda r: append_jsonl([{k: v for k, v in r.items() if k != "traceback"}],
                                                         results_path),
                        label="game")
    summary = summarise(results)
    write_csv(summary, os.path.join(run_dir, "summary.csv"))
    save_json(summary, os.path.join(run_dir, "summary.json"))

    log("Results (score = (wins - losses) / games):")
    log(f"  {'bot':<16s} {'opponent':<16s} {'W':>4s} {'D':>4s} {'L':>4s} {'E':>3s} {'score':>7s} {'est':>6s}")
    for row in summary:
        est = row["estimator_exact"]
        log(f"  {row['bot']:<16s} {row['opponent']:<16s} {row['wins']:>4d} {row['draws']:>4d} {row['losses']:>4d} "
            f"{row['errors']:>3d} {row['score'] if row['score'] != '' else '-':>7} "
            f"{est if est != '' else '-':>6}")
    log(f"Done in {clock.fmt()}. Summary: {os.path.join(run_dir, 'summary.csv')}")


if __name__ == "__main__":
    main()
