#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# Download an official Stockfish release binary into ./engines/ and print the
# line to export STOCKFISH_EXECUTABLE.
#
#   bash scripts/install_stockfish.sh                # Stockfish 17.1, best build for this CPU
#   bash scripts/install_stockfish.sh sf_17.1 generic
#
# Arguments
#   $1  release tag on github.com/official-stockfish/Stockfish (default sf_17.1)
#   $2  build: auto | avx2 | bmi2 | sse41 | generic   (default auto; Linux only)
#
# Linux x86-64 and macOS (Intel and Apple Silicon) are supported. On Windows,
# download the binary from https://stockfishchess.org/download/ instead.
# -----------------------------------------------------------------------------
set -euo pipefail

TAG="${1:-sf_17.1}"
BUILD="${2:-auto}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="${ROOT}/engines"
BASE="https://github.com/official-stockfish/Stockfish/releases/download/${TAG}"

os="$(uname -s)"
arch="$(uname -m)"

# Pick the release asset for this platform.
if [[ "${os}" == "Linux" && "${arch}" == "x86_64" ]]; then
    if [[ "${BUILD}" == "auto" ]]; then
        flags="$(grep -m1 '^flags' /proc/cpuinfo || true)"
        if [[ "${flags}" == *" bmi2 "* && "${flags}" == *" avx2 "* ]]; then BUILD="bmi2"
        elif [[ "${flags}" == *" avx2 "* ]]; then BUILD="avx2"
        elif [[ "${flags}" == *" sse4_1 "* ]]; then BUILD="sse41"
        else BUILD="generic"; fi
    fi
    case "${BUILD}" in
        avx2)    ASSET="stockfish-ubuntu-x86-64-avx2.tar" ;;
        bmi2)    ASSET="stockfish-ubuntu-x86-64-bmi2.tar" ;;
        sse41)   ASSET="stockfish-ubuntu-x86-64-sse41-popcnt.tar" ;;
        generic) ASSET="stockfish-ubuntu-x86-64.tar" ;;
        *) echo "Unknown build '${BUILD}' (use auto, avx2, bmi2, sse41 or generic)" >&2; exit 1 ;;
    esac
elif [[ "${os}" == "Darwin" && "${arch}" == "arm64" ]]; then
    ASSET="stockfish-macos-m1-apple-silicon.tar"
elif [[ "${os}" == "Darwin" ]]; then
    ASSET="stockfish-macos-x86-64-avx2.tar"
else
    echo "No prebuilt Stockfish for ${os}/${arch} in this script; see https://stockfishchess.org/download/" >&2
    exit 1
fi

mkdir -p "${DEST}"
tmp="$(mktemp -d)"
trap 'rm -rf "${tmp}"' EXIT

echo "Downloading ${BASE}/${ASSET}"
curl -fL --retry 3 -o "${tmp}/stockfish.tar" "${BASE}/${ASSET}"
tar -xf "${tmp}/stockfish.tar" -C "${tmp}"

# The archive holds a folder with the binary named after the asset.
binary="$(find "${tmp}" -type f -name 'stockfish*' ! -name '*.tar' -perm -u+x | head -n 1 || true)"
if [[ -z "${binary}" ]]; then
    binary="$(find "${tmp}" -type f -name 'stockfish-*' ! -name '*.tar' | head -n 1 || true)"
fi
if [[ -z "${binary}" ]]; then
    echo "Could not find the Stockfish binary inside ${ASSET}" >&2
    exit 1
fi

target="${DEST}/stockfish"
cp "${binary}" "${target}"
chmod +x "${target}"

# Make sure the binary actually runs on this machine (wrong CPU build -> illegal instruction).
if ! printf 'uci\nquit\n' | "${target}" | grep -q uciok; then
    echo "The downloaded binary does not run on this CPU; try: bash scripts/install_stockfish.sh ${TAG} generic" >&2
    exit 1
fi

echo
echo "Stockfish installed at ${target}"
echo "Add this to your shell profile (or set CONFIG['stockfish_path'] in the scripts):"
echo "  export STOCKFISH_EXECUTABLE=${target}"
