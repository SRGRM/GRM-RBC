"""
Write the tournament configuration of the uccchess bot from a GRM training run.

Takes the learned GRM policy (policy.json from train_grm_policy.py) and the
opponent-skill estimator (estimator.pt from train_estimator_*.py) and writes
``uccchess/tournament_config.json`` plus a copy of the estimator into
``uccchess/models/``. After this step the bot folder is self-contained.

Every personality the bot can use is written with its full hyperparameter
vector (all sense, move and time settings, and the score settings that differ
from StrangeFish2's defaults), so the tournament behaviour can be read and
edited directly in the JSON file.

With "policy" and "estimator" set to None the script writes the untrained
configuration that ships with the repository: StrangeFish2's own tournament
settings for every opponent.

    python scripts/export_tournament_bot.py
"""

# =============================================================================
# CONFIG - every option of this script. Alternatives are listed in comments.
# =============================================================================
CONFIG = {
    "stockfish_path": "/path/to/stockfish",   # needed to load StrangeFish2's default settings; "" = $STOCKFISH_EXECUTABLE

    # ---- inputs from training --------------------------------------------------------
    "policy": "runs/policy_grm_YYYYmmdd_HHMMSS/policy.json",           # GRM policy | None = untrained defaults
    "estimator": "runs/estimator_cuda122_YYYYmmdd_HHMMSS/estimator.pt",  # estimator | None = no estimation
    "levels": list(range(1, 21)),      # only used when "policy" is None

    # ---- what to write ---------------------------------------------------------------
    "output_dir": "uccchess",          # bot folder; tournament_config.json and models/ are written here
    "config_name": "tournament_config.json",
    "copy_estimator": True,            # True = copy into <output_dir>/models/ (self-contained folder)
                                       # False = reference the training-run path directly
    "include_personalities": "used",   # "used" = only personalities in the class table (plus default) | "all"
    "untrained_class_action": "default",  # personality for classes the policy never trained on

    # ---- run-time GRM rules for tournament games ---------------------------------------
    "runtime": {
        "warmup_turns": 6,             # turns with the default personality before the first estimate
        "estimate_every": 1,           # estimator period in turns
        "confirm_turns": 2,            # identical consecutive estimates needed to switch
        "switch_margin": 0.0,          # minimum learned Q gain to switch (0 = follow the table)
        "allow_reswitch": True,        # True = may change personality again | False = commit once
        "min_estimator_margin": 0.0,   # ignore estimates whose best/second-best error gap is smaller
    },

    # ---- engine and StrangeFish2 options for tournament games -----------------------------
    "engine": {"threads": 3, "hash_mb": 2048},   # StrangeFish2 tournament values
    "strangefish": {
        "load_score_cache": False,     # True = use w_cache.pk / b_cache.pk if present in the working folder
        "load_opening_book": False,    # True = use opening_books/*.pk if present
        "while_we_wait_extension": True,
        "board_weight_90th_percentile": 3000,
        "min_board_weight": 0.02,
    },
    "base_overrides": {},              # applied under every personality; {} = tournament search depth (7)
}
# =============================================================================

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import shutil
from dataclasses import asdict

from grm_rbc.common import configure_stockfish, fail, load_json, log, save_json


def full_hyperparameters(personality, base_overrides):
    """Explicit sense/move/time values and the non-default score values of a personality.

    Score settings are written as differences from StrangeFish2's defaults
    because StrangeFish2 adjusts some of them for particular opponents at the
    start of a game, and a full score vector would undo those adjustments.
    """
    from grm_rbc.personalities import make_configs
    from strangefish.utilities.rbc_move_score import ScoreConfig

    sense, move, time_cfg, score = make_configs(personality, base_overrides)
    default_score = asdict(ScoreConfig())
    score_diff = {k: v for k, v in asdict(score).items() if default_score[k] != v}
    return {
        "description": personality.description,
        "sense": asdict(sense),
        "move": asdict(move),
        "time": asdict(time_cfg),
        "score": score_diff,
    }


def load_policy_table(cfg):
    """Return (levels, class -> personality, Q-values, personality objects, policy source info)."""
    from grm_rbc.grm import GRMPolicy
    from grm_rbc.personalities import build_action_space, personality_index

    if cfg["policy"] is None:
        space = build_action_space("named", subset=["default"])
        levels = list(cfg["levels"])
        return levels, {str(lv): "default" for lv in levels}, {}, personality_index(space), {"policy": None}

    if not os.path.isfile(cfg["policy"]):
        fail(f"Policy file not found: {cfg['policy']}")
    data = load_json(cfg["policy"])
    if data.get("kind") != "grm":
        fail(f"{cfg['policy']} is not a GRM policy (kind={data.get('kind')!r}); "
             "the tournament bot uses the GRM, not the Q-learning baseline.")
    policy = GRMPolicy.from_dict(data)
    spec = data.get("action_space") or {"kind": "named"}
    space = build_action_space(spec.get("kind", "named"), spec.get("grid_options"), spec.get("subset"))
    by_name = personality_index(space)
    missing = [a for a in policy.actions if a not in by_name]
    if missing:
        fail(f"Policy uses personalities that are not in its action space: {missing}")
    if cfg["untrained_class_action"] not in by_name:
        fail(f"untrained_class_action '{cfg['untrained_class_action']}' is not in the action space")

    table, q_values = {}, {}
    for s, level in enumerate(policy.levels):
        trained = policy.n[s].sum() > 0
        table[str(level)] = policy.greedy_action(s) if trained else cfg["untrained_class_action"]
        q_values[str(level)] = {a: (float(policy.q[s, j]) if policy.n[s, j] > 0 else None)
                                for j, a in enumerate(policy.actions)}
    info = {"policy": os.path.abspath(cfg["policy"]), "episodes": data.get("episode"),
            "batches_per_class": {str(lv): int(policy.n[s].sum()) for s, lv in enumerate(policy.levels)}}
    return policy.levels, table, q_values, by_name, info


def main():
    """Resolve the learned table into explicit hyperparameters and write the bot configuration."""
    cfg = CONFIG
    configure_stockfish(cfg["stockfish_path"])
    from grm_rbc.estimator import load_checkpoint

    levels, table, q_values, by_name, info = load_policy_table(cfg)
    log(f"Opponent classes: {levels}")

    # ---- estimator ------------------------------------------------------------------
    os.makedirs(cfg["output_dir"], exist_ok=True)
    estimator_entry = None
    if cfg["estimator"]:
        if not os.path.isfile(cfg["estimator"]):
            fail(f"Estimator checkpoint not found: {cfg['estimator']}")
        try:
            est_levels = list(load_checkpoint(cfg["estimator"])["levels"])
        except Exception as exc:
            fail(f"Could not read estimator checkpoint {cfg['estimator']}: {exc}")
        if est_levels != list(levels):
            fail(f"Estimator classes {est_levels} differ from the policy classes {levels}")
        if cfg["copy_estimator"]:
            models_dir = os.path.join(cfg["output_dir"], "models")
            os.makedirs(models_dir, exist_ok=True)
            shutil.copyfile(cfg["estimator"], os.path.join(models_dir, "estimator.pt"))
            estimator_entry = "models/estimator.pt"
            log(f"Estimator copied to {os.path.join(models_dir, 'estimator.pt')}")
        else:
            estimator_entry = os.path.abspath(cfg["estimator"])
        info["estimator"] = os.path.abspath(cfg["estimator"])
    elif cfg["policy"] is not None:
        log("No estimator given: the bot will play the default personality only.")

    # ---- personalities with explicit hyperparameters ----------------------------------
    names = ["default"] + sorted({n for n in table.values() if n != "default"})
    if cfg["include_personalities"] == "all":
        names += [n for n in by_name if n not in names]
    elif cfg["include_personalities"] != "used":
        fail(f"Unknown include_personalities '{cfg['include_personalities']}'")
    personalities = {n: full_hyperparameters(by_name[n], cfg["base_overrides"]) for n in names}

    out = {
        "format_version": 1,
        "bot_name": "uccchess",
        "description": ("Tournament configuration of the uccchess Reconnaissance Blind Chess bot: "
                        "StrangeFish2 whose hyperparameters are selected by a Generative Reward Machine."),
        "source": info,
        "estimator": estimator_entry,
        "levels": list(levels),
        "default_personality": "default",
        "class_policy": table,
        "q_values": q_values,
        "runtime": cfg["runtime"],
        "engine": cfg["engine"],
        "strangefish": cfg["strangefish"],
        "base_overrides": cfg["base_overrides"],
        "personalities": personalities,
    }
    path = os.path.join(cfg["output_dir"], cfg["config_name"])
    save_json(out, path)

    log("Class -> personality used in tournament games:")
    for level in levels:
        p = personalities[table[str(level)]]["move"]
        log(f"  level {level:>2}: {table[str(level)]:<14s} max_score_factor={p['max_score_factor']:<5g} "
            f"threshold_score={p['threshold_score']:<5g} sampling_exploration_coef={p['sampling_exploration_coef']:g}")
    log(f"Written {path}")


if __name__ == "__main__":
    main()
