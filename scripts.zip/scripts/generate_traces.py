"""
Generate training data for the opponent-skill estimator.

Plays the StrangeFish2-based bot against Stockfish skill-level opponents and
records, for every game, the size of the bot's belief state at each stage of
each turn. Each finished game is appended to ``traces.jsonl`` immediately, so
an interrupted run loses at most the games in progress and can be resumed.

CPU only: the cost is Stockfish search inside both bots.

    python scripts/generate_traces.py
"""

# =============================================================================
# CONFIG - every option of this script. Alternatives are listed in comments.
# =============================================================================
CONFIG = {
    # ---- engine ---------------------------------------------------------------
    "stockfish_path": "/path/to/stockfish",   # Stockfish binary; "" = use $STOCKFISH_EXECUTABLE

    # ---- opponents ------------------------------------------------------------
    "levels": list(range(1, 21)),      # opponent classes = Stockfish "Skill Level" values (any subset of 0..20)
    "games_per_level": 60,             # games recorded against each level (e.g. 30, 60, 200)
    "opponent": {                      # engine settings of the skill-level opponents
        "move_time": 0.1,              # seconds of Stockfish search per opponent move (e.g. 0.05 - 0.5)
        "threads": 1,
        "hash_mb": 16,
    },

    # ---- our bot while recording ----------------------------------------------
    "action_space": "named",           # "named" | "grid" (see grm_rbc/personalities.py)
    "grid_options": None,              # None = default grid, or dict of grid_personalities() arguments
    "our_personalities": ["default"],  # personalities played while recording, e.g. ["default"] |
                                       # ["default", "cautious", "aggressive"] | "all" = whole action space
    "colors": "alternate",             # "alternate" | "white" | "black" | "random"
    "base_overrides": {                # applied under every personality; lower depth = faster games
        "score": {"search_depth": 6},  # StrangeFish2 tournament value is 7
    },
    "engine_threads": 1,               # Stockfish threads for our bot per game
    "engine_hash_mb": 64,              # Stockfish hash for our bot per game

    # ---- game rules -------------------------------------------------------------
    "game": {
        "seconds_per_player": 180,     # tournament: 900
        "seconds_increment": 2,        # tournament: 5
        "reversible_moves_limit": 100, # moves without capture or pawn move before a draw
        "full_turn_limit": 150,        # None = no limit
    },

    # ---- execution and output ----------------------------------------------------
    "workers": 4,                      # parallel games; roughly (CPU cores) / 2 since both bots run Stockfish
    "start_method": "spawn",           # "spawn" | "fork"
    "seed": 0,
    "output_dir": "runs",
    "run_name": "traces",
    "resume_dir": None,                # None = new run | path of an earlier traces run to continue
}
# =============================================================================

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import random
from collections import Counter, defaultdict

import numpy as np

from grm_rbc.common import (Stopwatch, Tee, append_jsonl, configure_stockfish, fail, log, make_run_dir,
                            read_jsonl, save_json, set_seed)


def choose_colors(n: int, mode: str, rng: random.Random):
    """Colours of our bot for ``n`` games according to ``mode``."""
    if mode == "alternate":
        return ["white" if i % 2 == 0 else "black" for i in range(n)]
    if mode in ("white", "black"):
        return [mode] * n
    if mode == "random":
        return [rng.choice(["white", "black"]) for _ in range(n)]
    raise ValueError(f"Unknown colors mode '{mode}'")


def trace_record(res):
    """Keep only what the estimator needs from a game result."""
    return {
        "game_id": res["game_id"],
        "level": res["meta"]["level"],
        "personality": res["meta"]["personality"],
        "color": res.get("color", res["our_color"] == "white"),
        "outcome": res.get("outcome"),
        "win_reason": res.get("win_reason"),
        "n_turns": res.get("n_turns"),
        "turns": res.get("turns", []),
        "duration_sec": res["duration_sec"],
        "error": res.get("error"),
    }


def main():
    """Plan the games, play them and write traces plus a per-level summary."""
    cfg = CONFIG
    configure_stockfish(cfg["stockfish_path"])
    from grm_rbc.game_runner import run_games
    from grm_rbc.personalities import build_action_space

    if cfg["resume_dir"]:
        run_dir = cfg["resume_dir"]
        if not os.path.isdir(run_dir):
            fail(f"resume_dir does not exist: {run_dir}")
    else:
        run_dir = make_run_dir(cfg["output_dir"], cfg["run_name"])
    sys.stdout = Tee(os.path.join(run_dir, "log.txt"))
    save_json(cfg, os.path.join(run_dir, "config.json"))
    set_seed(cfg["seed"])
    rng = random.Random(cfg["seed"])
    clock = Stopwatch()
    log(f"Run folder: {run_dir}")

    space = build_action_space(cfg["action_space"], cfg["grid_options"])
    names = [p.name for p in space] if cfg["our_personalities"] == "all" else list(cfg["our_personalities"])
    unknown = [n for n in names if n not in {p.name for p in space}]
    if unknown:
        fail(f"Personalities {unknown} are not in the '{cfg['action_space']}' action space.")
    log(f"Recording with personalities: {names}")

    traces_path = os.path.join(run_dir, "traces.jsonl")
    done = set()
    if os.path.exists(traces_path):
        done = {r["game_id"] for r in read_jsonl(traces_path) if not r.get("error")}
        log(f"Resuming: {len(done)} completed games found")

    tasks = []
    for level in cfg["levels"]:
        colors = choose_colors(cfg["games_per_level"], cfg["colors"], rng)
        for g in range(cfg["games_per_level"]):
            personality = names[g % len(names)]
            game_id = f"L{level:02d}_g{g:04d}"
            if game_id in done:
                continue
            tasks.append({
                "game_id": game_id,
                "our_color": colors[g],
                "our_bot": {
                    "mode": "fixed",
                    "personality": personality,
                    "base_overrides": cfg["base_overrides"],
                    "engine_threads": cfg["engine_threads"],
                    "engine_hash_mb": cfg["engine_hash_mb"],
                },
                "action_space": {"kind": cfg["action_space"], "grid_options": cfg["grid_options"]},
                "opponent": {"type": "skill_trout", "level": level},
                "opponent_defaults": cfg["opponent"],
                "game": cfg["game"],
                "meta": {"level": level, "personality": personality},
            })
    rng.shuffle(tasks)  # mix levels so partial runs stay balanced
    log(f"{len(tasks)} games to play on {cfg['workers']} workers")

    def store(res):
        """Append one finished game to traces.jsonl."""
        append_jsonl([trace_record(res)], traces_path)

    results = run_games(tasks, workers=cfg["workers"], start_method=cfg["start_method"], on_result=store,
                        label="game")

    # ---- summary over everything recorded so far --------------------------------
    all_rows = read_jsonl(traces_path) if os.path.exists(traces_path) else []
    per_level = defaultdict(list)
    for r in all_rows:
        per_level[r["level"]].append(r)
    summary = {"total_games": len(all_rows), "this_session": len(results), "levels": {}}
    log("Summary per opponent level:")
    for level in sorted(per_level):
        rows = per_level[level]
        ok = [r for r in rows if not r.get("error")]
        outcomes = Counter(r["outcome"] for r in ok)
        turns = [len(r["turns"]) for r in ok]
        peak = [max((t.get("start") or 0) for t in r["turns"]) for r in ok if r["turns"]]
        s = {
            "games": len(rows), "errors": len(rows) - len(ok),
            "wins": outcomes.get(1, 0), "draws": outcomes.get(0, 0), "losses": outcomes.get(-1, 0),
            "mean_turns": float(np.mean(turns)) if turns else 0.0,
            "median_peak_boards": float(np.median(peak)) if peak else 0.0,
        }
        summary["levels"][str(level)] = s
        log(f"  level {level:2d}: {s['games']} games ({s['errors']} errors)  W/D/L {s['wins']}/{s['draws']}/"
            f"{s['losses']}  mean turns {s['mean_turns']:.1f}  median peak boards {s['median_peak_boards']:.0f}")
    save_json(summary, os.path.join(run_dir, "summary.json"))
    log(f"Done in {clock.fmt()}. Traces: {traces_path}")


if __name__ == "__main__":
    main()
