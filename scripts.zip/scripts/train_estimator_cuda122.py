"""
Train the opponent-skill estimator (one autoencoder per opponent class).

Variant for the CUDA 12.2 machine (PyTorch 2.x): mixed precision through
``torch.autocast`` with a selectable dtype (bfloat16 or float16), optional
TF32 matmuls and optional ``torch.compile``.

Input   trace files written by scripts/generate_traces.py
Output  one run folder containing, for every epoch, the model checkpoint and
        the validation predictions, plus a training report and the selected
        final estimator (estimator.pt) for the bot.

    python scripts/train_estimator_cuda122.py
"""

# =============================================================================
# CONFIG - every option of this script. Alternatives are listed in comments.
# =============================================================================
CONFIG = {
    # ---- hardware -----------------------------------------------------------
    "gpu_ids": [0],                    # [] = CPU only | [0] = one GPU | [0, 1, 2, 3] = DataParallel on four GPUs
    "seed": 42,                        # any integer

    # ---- data ---------------------------------------------------------------
    "trace_files": [                   # one or more traces.jsonl files from generate_traces.py
        "runs/traces_YYYYmmdd_HHMMSS/traces.jsonl",
    ],
    "levels": "auto",                  # "auto" = every level found in the data | explicit list, e.g. list(range(1, 21))
    "min_turns": 4,                    # games shorter than this are discarded (any int >= 1)
    "drop_errors": True,               # True = skip games that ended with an error | False = keep them
    "val_fraction": 0.2,               # fraction of games held out for validation (0.0 - 0.5)
    "split": "stratified",             # "stratified" = same class mix in both parts | "random"

    # ---- trace encoding (stored in the checkpoint and reused by the bot) ----
    "encoding": {
        "feature_mode": "start_sense_move",  # "start" | "start_sense" | "start_sense_move"
        "max_turns": 40,                     # sequence length seen by the autoencoders (e.g. 30, 40, 60)
        "include_backlog": True,             # True = add StrangeFish2's stored-board estimate | False
        "include_color": True,               # True = add a colour channel | False
        "norm_boards": 100000.0,             # board count mapped to 1.0 after log1p scaling
    },

    # ---- data loading -------------------------------------------------------
    "loader": "tensor",                # "tensor" = in-memory batching | "torch_dataloader" = torch DataLoader
    "sampler": "balanced",             # "balanced" = equal class frequency | "shuffle" = natural frequency
    "batch_size": 256,                 # e.g. 64, 128, 256, 512
    "num_workers": 0,                  # DataLoader workers (only for "torch_dataloader"), e.g. 0, 2, 4
    "pin_memory": True,                # True | False (only for "torch_dataloader" on GPU)
    "prefix_augmentation": True,       # True = train on random game prefixes too | False = full games only
    "min_prefix": 4,                   # shortest prefix used by the augmentation (turns)

    # ---- model --------------------------------------------------------------
    "arch": "gru",                     # "gru" | "mlp" | "conv1d"
    "arch_options": {                  # hyperparameters of each architecture; only the selected one is used
        "gru": {"hidden_size": 64, "latent_dim": 16, "num_layers": 1, "dropout": 0.0},
        "mlp": {"hidden_dims": [256, 128], "latent_dim": 16, "dropout": 0.0},
        "conv1d": {"channels": 32, "latent_dim": 16, "kernel_size": 5},
    },

    # ---- objective ----------------------------------------------------------
    "loss_type": "own",                # "own" = each autoencoder fits its own class only (thesis setting)
                                       # "own_plus_margin" = also push other classes' errors up by a margin
    "margin": 0.05,                    # hinge margin for "own_plus_margin"
    "margin_weight": 0.1,              # weight of the hinge term
    "decision_rule": "raw",            # "raw" = lowest reconstruction error | "zscore" = per-model standardised error

    # ---- optimisation -------------------------------------------------------
    "epochs": 60,                      # e.g. 30 - 200
    "optimizer": "adamw",              # "adamw" | "adam" | "sgd"
    "lr": 1e-3,                        # e.g. 3e-4 - 3e-3
    "weight_decay": 1e-4,              # e.g. 0, 1e-5, 1e-4
    "momentum": 0.9,                   # only for "sgd"
    "scheduler": "cosine",             # "cosine" | "step" | "plateau" | "none"
    "step_size": 20,                   # "step": epochs between decays
    "gamma": 0.5,                      # "step"/"plateau": decay factor
    "plateau_patience": 5,             # "plateau": epochs without improvement before decay
    "grad_clip": 1.0,                  # 0 disables clipping
    "amp": True,                       # True = mixed precision on GPU | False = float32
    "amp_dtype": "fp16",               # "fp16" (gradient scaler, works for every arch) | "bf16" (Ampere or newer)
    "tf32": True,                      # True = allow TF32 matmuls/convolutions | False
    "cudnn_benchmark": True,           # True = let cuDNN pick the fastest kernels | False
    "compile": False,                  # True = torch.compile the bank (PyTorch >= 2.0) | False

    # ---- evaluation, selection, output ---------------------------------------
    "eval_prefixes": [4, 8, 12, 16, 24, None],   # prefix lengths to evaluate; None = full game
    "select_metric": "acc_full",       # "acc_full" | "acc_p8" (any evaluated prefix) | "loss"
    "early_stopping_patience": 0,      # 0 disables; otherwise epochs without improvement before stopping
    "eval_batch_size": 512,
    "print_batches_per_epoch": 4,      # progress lines per epoch
    "output_dir": "runs",
    "run_name": "estimator_cuda122",
}
# =============================================================================

import os
import sys

if CONFIG["gpu_ids"]:
    os.environ["CUDA_VISIBLE_DEVICES"] = ",".join(str(g) for g in CONFIG["gpu_ids"])
else:
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import contextlib
import shutil
import time

import torch
import torch.nn as nn

from grm_rbc.belief import EncodingSpec
from grm_rbc.common import Stopwatch, Tee, append_csv_row, fail, log, make_run_dir, save_json, set_seed, write_csv
from grm_rbc.estimator import AutoencoderBank, save_checkpoint
from grm_rbc import estimator_training as et


AMP_DTYPES = {"bf16": torch.bfloat16, "fp16": torch.float16}


def make_autocast(enabled: bool, dtype_name: str):
    """Context-manager factory for autocast in the selected dtype (no-op when disabled)."""
    if dtype_name not in AMP_DTYPES:
        raise ValueError(f"amp_dtype must be one of {list(AMP_DTYPES)}")
    if enabled:
        dtype = AMP_DTYPES[dtype_name]
        return lambda: torch.autocast(device_type="cuda", dtype=dtype)
    return contextlib.nullcontext


def make_scaler(enabled: bool, dtype_name: str):
    """bfloat16 has the float32 exponent range and needs no loss scaling."""
    if not enabled or dtype_name != "fp16":
        return None
    try:
        return torch.amp.GradScaler("cuda")
    except (AttributeError, TypeError):
        return torch.cuda.amp.GradScaler()


def build_optimizer(params, cfg):
    """Optimizer selected by CONFIG['optimizer']."""
    if cfg["optimizer"] == "adamw":
        return torch.optim.AdamW(params, lr=cfg["lr"], weight_decay=cfg["weight_decay"])
    if cfg["optimizer"] == "adam":
        return torch.optim.Adam(params, lr=cfg["lr"], weight_decay=cfg["weight_decay"])
    if cfg["optimizer"] == "sgd":
        return torch.optim.SGD(params, lr=cfg["lr"], momentum=cfg["momentum"], weight_decay=cfg["weight_decay"])
    raise ValueError(f"Unknown optimizer '{cfg['optimizer']}'")


def build_scheduler(optimizer, cfg):
    """Learning-rate scheduler selected by CONFIG['scheduler'] (None for "none")."""
    if cfg["scheduler"] == "cosine":
        return torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=cfg["epochs"])
    if cfg["scheduler"] == "step":
        return torch.optim.lr_scheduler.StepLR(optimizer, step_size=cfg["step_size"], gamma=cfg["gamma"])
    if cfg["scheduler"] == "plateau":
        return torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="min", factor=cfg["gamma"],
                                                          patience=cfg["plateau_patience"])
    if cfg["scheduler"] == "none":
        return None
    raise ValueError(f"Unknown scheduler '{cfg['scheduler']}'")


def is_better(metric: str, value: float, best: float) -> bool:
    """Whether ``value`` improves on ``best`` (lower for loss, higher for accuracy)."""
    if best is None:
        return True
    return value < best if metric == "loss" else value > best


def main():
    """Load data, train the autoencoder bank and save every epoch."""
    cfg = CONFIG
    run_dir = make_run_dir(cfg["output_dir"], cfg["run_name"])
    sys.stdout = Tee(os.path.join(run_dir, "log.txt"))
    save_json(cfg, os.path.join(run_dir, "config.json"))
    set_seed(cfg["seed"])
    clock = Stopwatch()
    log(f"Run folder: {run_dir}")
    log(f"PyTorch {torch.__version__}, CUDA available: {torch.cuda.is_available()}")

    # ---- device -------------------------------------------------------------
    if cfg["gpu_ids"]:
        if not torch.cuda.is_available():
            fail(f"gpu_ids={cfg['gpu_ids']} requested but CUDA is not available.")
        device = torch.device("cuda:0")
        n_gpus = torch.cuda.device_count()
        log(f"Using {n_gpus} GPU(s): physical ids {cfg['gpu_ids']}")
    else:
        device = torch.device("cpu")
        n_gpus = 0
        log("Using CPU")
    use_amp = bool(cfg["amp"]) and device.type == "cuda"
    if device.type == "cuda":
        torch.backends.cuda.matmul.allow_tf32 = bool(cfg["tf32"])
        torch.backends.cudnn.allow_tf32 = bool(cfg["tf32"])
        torch.backends.cudnn.benchmark = bool(cfg["cudnn_benchmark"])
    if use_amp and cfg["amp_dtype"] == "bf16" and not torch.cuda.is_bf16_supported():
        log("bfloat16 is not supported on this GPU; falling back to float16")
        cfg["amp_dtype"] = "fp16"

    # ---- data -----------------------------------------------------------------
    log("Loading data")
    records = et.load_trace_records(cfg["trace_files"], cfg["min_turns"], cfg["drop_errors"])
    levels = et.resolve_levels(records, cfg["levels"])
    log(f"Opponent classes ({len(levels)}): {levels}")
    train_recs, val_recs = et.split_records(records, levels, cfg["val_fraction"], cfg["split"], cfg["seed"])
    if not train_recs:
        fail("Training split is empty.")
    if not val_recs:
        fail("Validation split is empty; increase val_fraction or generate more games.")
    spec = EncodingSpec.from_dict(cfg["encoding"])
    log(f"Encoding: {spec.to_dict()} -> {spec.n_features} features x {spec.max_turns} turns")
    train_t = et.to_tensors(train_recs, levels, spec)
    val_t = et.to_tensors(val_recs, levels, spec)
    log(f"Train games: {len(train_recs)}, validation games: {len(val_recs)}")
    et.check_class_coverage(train_t[3], levels, "train")
    et.check_class_coverage(val_t[3], levels, "validation")

    # ---- model ----------------------------------------------------------------
    arch_kwargs = cfg["arch_options"][cfg["arch"]]
    model = AutoencoderBank(len(levels), cfg["arch"], spec.max_turns, spec.n_features, arch_kwargs)
    n_params = sum(p.numel() for p in model.parameters())
    log(f"Autoencoder bank: {len(levels)} x {cfg['arch']} {arch_kwargs}, {n_params:,} parameters")
    model = model.to(device)
    if cfg["compile"]:
        log("Compiling the model with torch.compile")
        model = torch.compile(model)
    if n_gpus > 1:
        model = nn.DataParallel(model, device_ids=list(range(n_gpus)))
        log(f"DataParallel over {n_gpus} GPUs")

    optimizer = build_optimizer(model.parameters(), cfg)
    scheduler = build_scheduler(optimizer, cfg)
    autocast_fn = make_autocast(use_amp, cfg["amp_dtype"])
    scaler = make_scaler(use_amp, cfg["amp_dtype"])
    gen = torch.Generator()
    gen.manual_seed(cfg["seed"])

    report_csv = os.path.join(run_dir, "training_report.csv")
    report = {"config": cfg, "levels": levels, "epochs": []}
    best_value, best_epoch, epochs_without_gain = None, None, 0

    log("Training")
    for epoch in range(1, cfg["epochs"] + 1):
        t0 = time.time()
        batches = et.make_loader(train_t, cfg["batch_size"], cfg["sampler"], cfg["loader"], cfg["num_workers"],
                                 cfg["pin_memory"] and device.type == "cuda", cfg["seed"] + epoch)
        n_batches = len(batches)
        lr = optimizer.param_groups[0]["lr"]
        train_loss = et.train_one_epoch(model, batches, optimizer, device, autocast_fn, scaler, cfg, gen,
                                        epoch, n_batches)

        log(f"  epoch {epoch}: evaluating")
        calibration = et.calibration_stats(model, train_recs, levels, spec, device, cfg["eval_batch_size"])
        metrics, rows, confusion = et.evaluate(model, val_recs, levels, spec, device, cfg["eval_batch_size"],
                                               cfg["eval_prefixes"], cfg["decision_rule"], calibration, cfg)

        if scheduler is not None:
            if cfg["scheduler"] == "plateau":
                scheduler.step(metrics["loss"])
            else:
                scheduler.step()

        # ---- save this epoch: model + predictions ("submission") -----------
        ep_dir = os.path.join(run_dir, f"epoch_{epoch:03d}")
        os.makedirs(ep_dir, exist_ok=True)
        meta = {
            "arch": cfg["arch"], "arch_kwargs": arch_kwargs, "levels": levels, "encoding": spec.to_dict(),
            "decision_rule": cfg["decision_rule"], "calibration": calibration, "epoch": epoch,
            "metrics": metrics, "torch_version": str(torch.__version__), "loss_type": cfg["loss_type"],
        }
        ckpt_path = os.path.join(ep_dir, "estimator.pt")
        save_checkpoint(ckpt_path, model, meta)
        write_csv(rows, os.path.join(ep_dir, "val_predictions.csv"))
        write_csv([{"true_level": levels[i], **{f"pred_{levels[j]}": int(confusion[i, j])
                                                 for j in range(len(levels))}} for i in range(len(levels))],
                  os.path.join(ep_dir, "confusion_matrix.csv"))

        row = {"epoch": epoch, "lr": lr, "train_loss": train_loss, "val_loss": metrics["loss"]}
        row.update({k: v for k, v in metrics.items() if k != "loss"})
        row["epoch_sec"] = round(time.time() - t0, 1)
        append_csv_row(row, report_csv)
        report["epochs"].append(row)
        save_json(report, os.path.join(run_dir, "training_report.json"))

        sel = metrics[cfg["select_metric"]] if cfg["select_metric"] != "loss" else metrics["loss"]
        improved = is_better(cfg["select_metric"], sel, best_value)
        if improved:
            best_value, best_epoch, epochs_without_gain = sel, epoch, 0
            shutil.copyfile(ckpt_path, os.path.join(run_dir, "estimator.pt"))
        else:
            epochs_without_gain += 1
        log(f"  epoch {epoch}/{cfg['epochs']}  train_loss {train_loss:.6f}  val_loss {metrics['loss']:.6f}  "
            f"acc_full {metrics['acc_full']:.3f}  acc_within1 {metrics['acc_within1_full']:.3f}  "
            f"{'*best*' if improved else ''}  ({row['epoch_sec']}s, total {clock.fmt()})")

        if cfg["early_stopping_patience"] and epochs_without_gain >= cfg["early_stopping_patience"]:
            log(f"Early stopping: no improvement of {cfg['select_metric']} for {epochs_without_gain} epochs")
            break

    report["best_epoch"] = best_epoch
    report["best_value"] = best_value
    report["select_metric"] = cfg["select_metric"]
    save_json(report, os.path.join(run_dir, "training_report.json"))
    log(f"Done in {clock.fmt()}. Best epoch {best_epoch} ({cfg['select_metric']} = {best_value:.4f}).")
    log(f"Estimator for the bot: {os.path.join(run_dir, 'estimator.pt')}")


if __name__ == "__main__":
    main()
