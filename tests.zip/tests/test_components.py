"""
Unit tests for the parts that do not need Stockfish.

    python -m pytest tests -q
"""

import os
import random
import sys

import numpy as np
import pytest
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from grm_rbc.baseline import OpeningQLearner
from grm_rbc.belief import BeliefTrace, EncodingSpec, encode_trace
from grm_rbc.estimator import (AutoencoderBank, bank_loss, decide, reconstruction_errors, save_checkpoint,
                               SkillEstimator)
from grm_rbc.estimator_training import random_prefix
from grm_rbc.grm import (DRAW, FORFEIT, LOSS, WIN, BatchRewardMachine, GRMPolicy, LabellingFunction, RuntimeGRM,
                         RuntimeGRMConfig)
from grm_rbc.openings import opening_moves, opening_names
from grm_rbc.personalities import build_action_space, grid_personalities


# ---------------------------------------------------------------------------
# Personalities and openings
# ---------------------------------------------------------------------------

def test_named_personalities_are_valid():
    """The named action space starts with default and has unique names."""
    space = build_action_space("named")
    assert space[0].name == "default"
    assert len({p.name for p in space}) == len(space)


def test_grid_contains_default_and_sums_to_one():
    """The grid includes default and every point keeps the score weights normalised."""
    space = grid_personalities()
    assert space[0].name == "default"
    assert len(space) == 1 + 27
    for p in space[1:]:
        total = p.move["mean_score_factor"] + p.move["min_score_factor"] + p.move["max_score_factor"]
        assert abs(total - 1.0) < 1e-9


def test_subset_and_unknown_names():
    """Subsets keep their order; unknown names are rejected."""
    assert [p.name for p in build_action_space("named", subset=["default", "cautious"])] == ["default", "cautious"]
    with pytest.raises(ValueError):
        build_action_space("named", subset=["nope"])


def test_openings():
    """Five openings plus "other" per colour, parsed into moves."""
    import chess
    assert len(opening_names(chess.WHITE)) == 6
    assert opening_moves(chess.WHITE, "other") == []
    assert opening_moves(chess.BLACK, "sicilian")[0].uci() == "c7c5"


# ---------------------------------------------------------------------------
# Reward machine and policies
# ---------------------------------------------------------------------------

def test_batch_reward_machine_mean_and_forfeits():
    """Batch reward is the mean outcome; forfeits are excluded or counted as losses."""
    m = BatchRewardMachine(batch_size=4, forfeit_policy="exclude")
    symbols = [frozenset({WIN}), frozenset({LOSS}), frozenset({WIN}), frozenset({FORFEIT})]
    assert m.run(symbols) == pytest.approx(1 / 3)
    m = BatchRewardMachine(batch_size=4, forfeit_policy="as_loss")
    assert m.run(symbols) == pytest.approx(0.0)
    assert m.run([frozenset({DRAW})] * 3) == pytest.approx(0.0)


def test_batch_reward_machine_states():
    """The machine emits only when the batch is complete, then starts a new batch."""
    m = BatchRewardMachine(batch_size=2)
    assert m.step(frozenset({WIN})) == 0.0 and m.state == "collecting"
    assert m.step(frozenset({WIN})) == 1.0 and m.state == "emit"
    m.step(frozenset({LOSS}))
    assert m.state == "collecting" and m.outcomes == [-1.0]


def test_labelling_function():
    """Game and turn transitions map to the expected symbols."""
    lab = LabellingFunction()
    assert lab.label_game({"outcome": 1}) == frozenset({WIN})
    assert lab.label_game({"outcome": None, "error": "x"}) == frozenset({FORFEIT})
    assert lab.label_turn(None, 3) == frozenset({"same_class"})
    assert lab.label_turn(2, 3) == frozenset({"class_shift"})


def test_grm_policy_mean_of_history_and_greedy():
    """Q is the mean of the batch history; untried classes fall back to default."""
    p = GRMPolicy([1, 2], ["default", "a", "b"])
    p.update(0, 1, 0.2)
    p.update(0, 1, 0.4)
    p.update(0, 2, 0.1)
    assert p.q[0, 1] == pytest.approx(0.3)
    assert p.greedy_action(0) == "a"
    assert p.greedy_action(1) == "default"     # untried class falls back to the default personality
    q = GRMPolicy.from_dict(p.to_dict())
    assert np.allclose(q.q, p.q) and q.greedy_policy() == p.greedy_policy()


def test_grm_policy_selection_rules():
    """State cycling and action selection rules behave as documented."""
    rng = random.Random(0)
    p = GRMPolicy([1, 2, 3], ["default", "a"])
    assert [p.select_state("cycle", rng, e) for e in range(4)] == [0, 1, 2, 0]
    seen = {p.select_action(0, "ucb1", rng) for _ in range(20)}
    assert seen <= {0, 1}
    p.update(0, 0, 0.0)
    assert p.select_action(0, "ucb1", rng) == 1          # untried action first
    assert p.select_action(0, "round_robin", rng) == 1


def test_runtime_grm_switches_after_confirmation():
    """The run-time GRM switches only after confirmation and never when frozen."""
    p = GRMPolicy([1, 2], ["default", "cautious"])
    p.update(1, 0, -0.5)
    p.update(1, 1, 0.5)
    rt = RuntimeGRM(p, RuntimeGRMConfig(warmup_turns=3, confirm_turns=2))
    assert not rt.wants_estimate(2) and rt.wants_estimate(3)
    assert rt.step(3, {"class_index": 1, "margin": 1.0}) is None
    assert rt.step(4, {"class_index": 1, "margin": 1.0}) == "cautious"
    assert rt.current_action == "cautious" and rt.state == "committed"
    rt.freeze()
    assert rt.wants_estimate(5)
    assert rt.step(5, {"class_index": 0, "margin": 1.0}) is None
    assert rt.step(6, {"class_index": 0, "margin": 1.0}) is None
    assert rt.log[-1]["state"] == "frozen" and rt.log[-1]["estimated_level"] == 1


def test_opening_q_learner():
    """Incremental Q update, best pair per colour and save/load round trip."""
    import chess
    q = OpeningQLearner(["default", "a"], alpha=0.5)
    s = q.s_index(chess.WHITE, "italian")
    q.update(s, 1, 1.0)
    assert q.q[s, 1] == pytest.approx(0.5)
    assert q.best_for_color(chess.WHITE) == ("italian", "a")
    assert q.best_for_color(chess.BLACK) == ("other", "default")
    assert np.allclose(OpeningQLearner.from_dict(q.to_dict()).q, q.q)


# ---------------------------------------------------------------------------
# Belief encoding and estimator
# ---------------------------------------------------------------------------

def _fake_trace(n, scale, color=True):
    """Synthetic trace whose board counts grow linearly with ``scale``."""
    t = BeliefTrace(color=color)
    for i in range(1, n + 1):
        t.start_turn(i, int(scale * i) + 1, 0)
        t.record_sense(int(scale * i / 2) + 1)
        t.record_move(int(scale * i / 3) + 1)
    return t.to_list()


def test_encode_trace_shapes_and_prefix():
    """Encoding shapes, prefix truncation, colour channel and value range."""
    spec = EncodingSpec(max_turns=10)
    x, m, n = encode_trace(_fake_trace(14, 50), True, spec)
    assert x.shape == (10, 4) and n == 10 and m.sum() == 10
    x, m, n = encode_trace(_fake_trace(14, 50), False, spec, prefix=3)
    assert n == 3 and m.sum() == 3 and x[:3, -1].sum() == 0
    assert 0.0 <= x.max() <= 1.0


@pytest.mark.parametrize("arch,kw", [("gru", {"hidden_size": 16, "latent_dim": 4}),
                                     ("mlp", {"hidden_dims": [32], "latent_dim": 4}),
                                     ("conv1d", {"channels": 8, "latent_dim": 4})])
def test_bank_trains_and_separates_two_classes(arch, kw, tmp_path):
    """Each architecture learns to tell two clearly different classes apart."""
    torch.manual_seed(0)
    spec = EncodingSpec(max_turns=12)
    xs, ms, ls, ys = [], [], [], []
    for k, scale in enumerate((5, 500)):
        for j in range(40):
            x, m, n = encode_trace(_fake_trace(12, scale * (1 + 0.05 * j)), j % 2 == 0, spec)
            xs.append(x); ms.append(m); ls.append(n); ys.append(k)
    x = torch.tensor(np.stack(xs)); m = torch.tensor(np.stack(ms))
    ln = torch.tensor(ls); y = torch.tensor(ys)
    bank = AutoencoderBank(2, arch, spec.max_turns, spec.n_features, kw)
    opt = torch.optim.Adam(bank.parameters(), lr=1e-2)
    for _ in range(150):
        opt.zero_grad()
        loss = bank_loss(reconstruction_errors(bank(x, m, ln), x, m), y)
        loss.backward()
        opt.step()
    with torch.no_grad():
        err = reconstruction_errors(bank(x, m, ln), x, m).numpy()
    assert (decide(err, "raw") == y.numpy()).mean() > 0.9

    path = str(tmp_path / "est.pt")
    save_checkpoint(path, bank, {"arch": arch, "arch_kwargs": kw, "levels": [3, 17], "encoding": spec.to_dict(),
                                 "decision_rule": "raw", "calibration": None})
    est = SkillEstimator(path)
    out = est.estimate(_fake_trace(12, 500), True)
    assert out["level"] == 17


def test_random_prefix_respects_bounds():
    """Random prefixes stay within [min(length, min_prefix), length]."""
    g = torch.Generator(); g.manual_seed(0)
    lengths = torch.tensor([10, 3, 1])
    mask = (torch.arange(12).unsqueeze(0) < lengths.unsqueeze(1)).float()
    new_mask, new_len = random_prefix(mask, lengths, 4, g)
    assert torch.all(new_len <= lengths) and torch.all(new_len >= torch.clamp(lengths, max=4))
    assert torch.equal(new_mask.sum(1).long(), new_len)
