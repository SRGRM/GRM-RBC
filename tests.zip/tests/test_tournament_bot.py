"""
Tests for the uccchess tournament configuration and its policy table.

Importing the bot imports StrangeFish2, which needs STOCKFISH_EXECUTABLE to
point at an existing file; the tests are skipped when it is not set. No game
is played and the engine is never started.
"""

import copy
import json
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

pytestmark = pytest.mark.skipif(
    not os.path.isfile(os.environ.get("STOCKFISH_EXECUTABLE", "")),
    reason="STOCKFISH_EXECUTABLE is not set",
)

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHIPPED = os.path.join(REPO, "uccchess", "tournament_config.json")


def _shipped():
    """The configuration that ships with the repository, as a dictionary."""
    with open(SHIPPED) as f:
        return json.load(f)


def test_shipped_configuration_is_untrained_strangefish2():
    """The shipped file has no estimator and uses the default personality everywhere."""
    from uccchess.uccchess_bot import load_tournament_config, personalities_from_config
    cfg = load_tournament_config(SHIPPED)
    assert cfg["estimator"] is None
    assert set(cfg["class_policy"].values()) == {"default"}
    space = personalities_from_config(cfg)
    assert space[0].name == "default"
    assert space[0].move["mean_score_factor"] == 0.7 and space[0].move["min_score_factor"] == 0.3


def test_configuration_errors_are_reported(tmp_path):
    """Undefined personalities, missing classes and missing estimators are rejected."""
    from uccchess.uccchess_bot import load_tournament_config
    bad = _shipped()
    bad["class_policy"]["3"] = "does_not_exist"
    path = tmp_path / "bad.json"
    path.write_text(json.dumps(bad))
    with pytest.raises(ValueError):
        load_tournament_config(str(path))

    bad = _shipped()
    del bad["class_policy"]["5"]
    path.write_text(json.dumps(bad))
    with pytest.raises(ValueError):
        load_tournament_config(str(path))

    bad = _shipped()
    bad["estimator"] = "models/missing.pt"
    path.write_text(json.dumps(bad))
    with pytest.raises(FileNotFoundError):
        load_tournament_config(str(path))


def test_tournament_policy_follows_the_table():
    """The class table wins over Q-values, and Q-values feed the switching rule."""
    from uccchess.uccchess_bot import TournamentPolicy
    cfg = copy.deepcopy(_shipped())
    cfg["levels"] = [1, 2]
    cfg["class_policy"] = {"1": "cautious", "2": "default"}
    cfg["q_values"] = {"1": {"default": 0.5, "cautious": 0.1}, "2": {"default": None, "cautious": None}}
    policy = TournamentPolicy(cfg, ["default", "cautious"])
    assert policy.greedy_action(0) == "cautious"      # hand-set entry is played as written
    assert policy.greedy_action(1) == "default"
    assert policy.q_value(0, "default") == 0.5
    assert policy.q_value(1, "cautious") != policy.q_value(1, "cautious")   # NaN when untrained
